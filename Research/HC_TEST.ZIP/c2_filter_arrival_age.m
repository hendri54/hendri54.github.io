function invalidV = c2_filter_arrival_age( aaV, bplV, fltS, dbg );
% Find invalid observations in variable Arrival Age
% IN:
%  aaV         Recoded PUMS variable
%  bplV        Birth place (PWT no)
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

global c2S

invalidV = find( (aaV < fltS.arrivalAgeMin  |  aaV > fltS.arrivalAgeMax) ...
      &  (bplV ~= c2S.cUSA) );

% ********  eof  ***********
