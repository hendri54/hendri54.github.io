function c2_recode_filter(year, filterNo, dbg);
% Recode and filter PUMS variables
% ---------------------------------

global c2S UNDEFINED puS

fltS = c2_filter_settings(filterNo, dbg);
varNoV = c2S.pumsVarNoV;

% For immigrant and native files
for varNo = varNoV
   disp(sprintf('Processing variable %i . . .',  varNo));

   if varNo == c2S.vWeight  &  year == 1980
      % 1980 sample is unweighted
      mi = ones(nImmigr, 1);
      mn = ones(nNative, 1);
   else
      % Load the ascii file for immigrants
      mi = load( c2_ascii_fn(year, varNo, 'i', dbg) );
      % Load native variable, unless this variable does not make
      % sense for natives
      if varNo == c2S.vBPL  |  varNo == c2S.vYearsUSA
         mn = UNDEFINED;
      else
         mn = load( c2_ascii_fn(year, varNo, 'n', dbg) );
      end
   end

   % Initialize indicator of valid observations
   if varNo == varNoV(1)
      nNative = length(mn);
      nImmigr = length(mi);
      validV = repmat(1, [nNative+nImmigr, 1]);
   end

   % Recode and filter each variable
   if varNo == c2S.vSex
      m2 = recode_sex_pu( year, [mi(:); mn(:)], c2S.male, c2S.female, dbg );
      invalidV = c2_filter_sex( m2, fltS, dbg );

   elseif varNo == c2S.vClassWkr
      abort([ mfilename, ': Class worker not implemented' ]);
      %m2 = recode_class_pu( year, [mi(:); mn(:)], dbg );
      %invalidV = c2_filter_class( m2, fltS, dbg );

   elseif varNo == c2S.vWeight
      m2 = [mi(:); mn(:)];
      % No need to recode weight
      % m2 = recode_weight_pu( year, [mi(:); mn(:)], dbg );
      invalidV = c2_filter_weight( m2, fltS, dbg );

   elseif varNo == c2S.vAge
      % m2 = recode_age_pu( year, [mi(:); mn(:)], dbg );
      m2 = [mi(:); mn(:)];
      invalidV = c2_filter_age( m2, fltS, dbg );

   elseif varNo == c2S.vEarnings
      % m2 = recode_earn_pu( year, [mi(:); mn(:)], dbg );
      m2 = [mi(:); mn(:)];
      invalidV = c2_filter_earn( m2, fltS, dbg );

   %elseif varNo == c2S.vGQ
      %abort([ mfilename, ': GQ not implemented' ]);
      %m2 = recode_gq_pu( year, [mi(:); mn(:)], dbg );
      %invalidV = c2_filter_gq( m2, fltS, dbg );

   elseif varNo == c2S.vHoursWk
      % m2 = recode_hoursweek_pu( year, [mi(:); mn(:)], dbg );
      m2 = [mi(:); mn(:)];
      invalidV = c2_filter_hoursweek( m2, fltS, dbg );

   elseif varNo == c2S.vWeeksYr
      %m2 = recode_weeksyear_pu( year, [mi(:); mn(:)], dbg );
      m2 = [mi(:); mn(:)];
      invalidV = c2_filter_weeksyear( m2, fltS, dbg );

   elseif varNo == c2S.vYrsSchool
      m2 = recode_yrs_school_pu( year, [mi(:); mn(:)], dbg );
      invalidV = c2_filter_yrs_school( m2, fltS, dbg );

   elseif varNo == c2S.vEnglish
      % No recoding needed
      m2 = [mi(:); mn(:)];
      invalidV = c2_filter_english( m2, fltS, dbg );


   elseif varNo == c2S.vOccup
      m2 = recode_occup_pu( year, [mi(:); mn(:)], dbg );
      invalidV = c2_filter_occup( m2, fltS, dbg );
      if length(invalidV) > 0
         % Do not drop observations
         m2(invalidV) = puS.indOther;
         invalidV = [];
      end

   elseif varNo == c2S.vIndustry
      m2 = recode_industry_pu( year, [mi(:); mn(:)], dbg );
      invalidV = c2_filter_industry( m2, fltS, dbg );
      if length(invalidV) > 0
         % Do not drop observations
         m2(invalidV) = puS.occOther;
         invalidV = [];
      end


   % ****** Immigrants only *******
   elseif varNo == c2S.vYearsUSA
      m2 = recode_yrs_usa_pu( year, mi(:), dbg );
      invalidV = c2_filter_yrs_usa( m2, fltS, dbg );
      m2 = [m2; zeros(nNative, 1)];

   elseif varNo == c2S.vBPL
      m2 = recode_pob_pu( year, mi(:), dbg );
      invalidV = c2_filter_pob( m2, fltS, dbg );
      m2 = [m2; repmat(c2S.cUSA, [nNative, 1])];

   %elseif varNo == c2S.vArrivalAge
      %abort([ mfilename, ': Not implemented' ]);
      %m2 = recode_arrival_age_pu( year, [mi(:); mn(:)], dbg );
      %invalidV = c2_filter_arrival_age( m2, fltS, dbg );

   else
      abort([ mfilename, ': Invalid varNo' ], sprintf('%i', varNo));
   end

   % Mark INvalid observations
   if length(invalidV) > 0
      validV(invalidV) = 0;
      disp(sprintf('  No of obs. with invalid data: %i    Still valid: %i', ...
         length(invalidV), sum(validV) ));
   end

   % Save matrix file
   c2_pums_save( m2, UNDEFINED, varNo, year, filterNo, dbg );
end % for varNo


% *********  Created variables  ***********

disp(' ');
disp('Created variables:');

createdVarNoV = c2S.vArrivalAge;

% Arrival age
ageV    = c2_pums_load( c2S.vAge, year, filterNo, dbg );
yrsUSAv = c2_pums_load( c2S.vYearsUSA, year, filterNo, dbg );
bplV    = c2_pums_load( c2S.vBPL, year, filterNo, dbg );
aaV = create_arr_age_pu(ageV, yrsUSAv, dbg);
% Filter function passes natives as valid
invalidV = c2_filter_arrival_age( aaV, bplV, fltS, dbg );
if length(invalidV) > 0
   validV(invalidV) = 0;
   disp(sprintf('  No of obs. with invalid arrival age: %i    Still valid: %i', ...
      length(invalidV), sum(validV) ));
end
c2_pums_save( aaV, UNDEFINED, c2S.vArrivalAge, year, filterNo, dbg );




% ********  Delete invalid observations  *********

disp(' ');
disp('Deleting invalid observations in all variables . . .');
validIdxV = find( validV == 1 );
for varNo = [varNoV, createdVarNoV]
   [m, infoS] = c2_pums_load( varNo, year, filterNo, dbg );
   c2_pums_save( m(validIdxV), infoS, varNo, year, filterNo, dbg );
end



% *****  Report no of observations  *******

bplV    = c2_pums_load( c2S.vBPL, year, filterNo, dbg );
nNativeN = sum( bplV == c2S.cUSA );
nImmigrN = length(bplV) - nNativeN;

disp(sprintf('Before filter: %i immigrants and %i natives', nImmigr, nNative ));
disp(sprintf('Retaining %i immigrants and %i natives', nImmigrN, nNativeN));

%disp(mfilename);
%keyboard;

% *******  eof  ********
