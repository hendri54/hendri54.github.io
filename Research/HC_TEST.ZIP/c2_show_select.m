function c2_show_select(year, filterNo, expNo, dbg);
% Show immigrant self-selection

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% -------------------------------------------------

global pwtS bl2S ca1S c2S UNDEFINED

saveFigures = c2S.saveFigures;
figOptS = struct('FontMode','fixed','FontSize',10, 'preview', 'tiff');
diaryFn = [c2S.dataDir, sprintf('Select%04i_%03i_%03i', year, filterNo, expNo)];

if nargin ~= 4
   abort([ mfilename, ': Invalid no of arguments' ]);
end

male = c2S.male;
female = c2S.female;
cUSA = c2S.cUSA;

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;
expS = c2_exp_settings(expNo, dbg);

% Load strings with country names
[cn, cnLen, cnMax] = cnames(c2S.pwtVer);
clabelM = pw_clabels(c2S.pwtVer);

% RGDPW relative to US
relRGDPWv = load2( c2_class_fn(year, c2S.vRelRGDPWv, filterNo, dbg) );

% Load result file
acctS = load2( c2_acct_fn(year, filterNo, expNo, dbg), dbg );
decEarnPerWkM = acctS.decEarnPerWkM;
[nl, nSex, nc2] = size(decEarnPerWkM);
nSex = nSex - 1;

% Source country earnings per worker (real)
% By sex, country
sourceEarnSC = load2( c2_class_fn(year, c2S.vSourceEarnSC, filterNo, dbg) );

% Source country population fractions by (sex, skill, country)
skillFracM = load2( c2_class_fn(year, c2S.vSrcSkillWt, filterNo, dbg) );

% Ratio of measured skills: immigrants / src natives
measSkillRatioSC = load2( c2_class_fn(year, c2S.vMeasSkillRatioSC, filterNo, dbg) );


% Load average years of schooling
avgSchoolM = c2_bl_var_load_yr(bl2S.vAvgYrAll, year, filterNo, dbg);


% Schooling of immigrants by (sex, country)
immSchoolAllM = load2( c2_class_fn(year, c2S.vImmSchoolSC, filterNo, dbg) );
if ~isequal(size(immSchoolAllM), [nSex+1, c2S.nCountries])
   warnmsg([ mfilename, ':  Invalid size of immSchoolAllM' ]);
   keyboard;
end

% Position of immigrants in source country school distribution
% by (sex, skill, country)
% This may be loaded from a different filter (to match Barro-Lee)
immSchoolPosM = load2( c2_class_fn(year, c2S.vImmSchoolPos, fltS.fltImmSchoolPos, dbg) );
if ~isequal(size(immSchoolPosM), [nSex, nSkill, c2S.nCountries])
   warnmsg([ mfilename, ':  Invalid size of immSchoolPosM' ]);
   keyboard;
end
% For comparison, load it again for this sample of immigrants
immSchoolPos2M = load2( c2_class_fn(year, c2S.vImmSchoolPos, filterNo, dbg) );

% Mincer regression data by (country,sex,year)
mS = c2_mincer_load(year, [male, female], dbg);
% Compute avg school for both sexes
mS.avgSchoolM(:,c2S.sexAll) = c2_sex_avg(mS.avgSchoolM', fltS.maleWt, 0, 0, dbg)';

% Quintile ratio in source country
dsQRatioV = load2( c2_class_fn(year, c2S.vQRatioDS, filterNo, dbg) );

% Std dev of log earnings matching dsQRatio
stdDevLogEarnV = load2( c2_class_fn(year, c2S.vSourceSig, filterNo, dbg) );

% Fraction of population living in USA
fracInUSAv = load2( c2_class_fn(year, c2S.vFracInUSA, 1, dbg) );





% ********  Show Self-selection  ***********
nc = min([nc2, cnMax]);

diaryon( diaryFn );
disp(' ');
disp('-------  Self-Selection  --------');
for sex = c2S.sexAll
   if sex == male
      sexStr = 'Male';
   elseif sex == female
      sexStr = 'Female';
   else
      sexStr = 'Both sexes';
   end
   disp(' ');
   disp([ '* ', sexStr, ' *' ]);
   disp('Country           QRatio  Sigma ImmPos in dist   Frac      Schooling         Selection');
   disp('                                s(c)  Full gap  in US  Mincer Src Immig  Meas. Implied');

   for c = 1 : nc
      % Average immigrant is in this top percentile of source country earnings
      % distribution
      if acctS.immSrcPosM(sex,c) > 0
         % SS that fully accounts for observed earnings gaps
         immSrcPos = 100 * (1 - acctS.immSrcPosM(sex,c));
         % SS implied by model's s(c) factors
         modelSrcPos = 100 * (1 - acctS.modelSrcPosM(sex,c));
      else
         immSrcPos = -99;
         modelSrcPos = -99;
      end
      if fracInUSAv(c) >= 0
         fracInUSA = 100 * fracInUSAv(c);
      else
         fracInUSA = UNDEFINED;
      end
      dataV = [dsQRatioV(c), stdDevLogEarnV(c), modelSrcPos, immSrcPos, fracInUSA, ...
         mS.avgSchoolM(c,sex), avgSchoolM(sex,c), immSchoolAllM(sex,c), ...
         measSkillRatioSC(sex,c), acctS.impliedSelectSC(sex,c)];
      if acctS.impliedSelectSC(sex,c) > 0
         disp([ sprintf('%15s  ', cn(c,1:15)), sprintf(' %6.1f', dataV) ]);
      end
   end % for c
end


% **** Find average self-selection for poor countries ****
if 1
   % SS implied by proxy for s(c)
   sex = c2S.sexAll;
   modelSrcPosV = 1 - acctS.modelSrcPosM(sex,:);
   % Find richest and poorest countries
   validV = (acctS.modelSrcPosM(sex,:) > 0)  &  (relRGDPWv > 0);
   N = 5;
   [idxRichV, idxPoorV] = c2_richest_poorest(N, relRGDPWv, validV, dbg);
   % Average self-selection
   disp(' ');
   disp(sprintf('Avg immigrant position implied by s(c). %i poorest countries: %5.1f', ...
      N, 100 * mean(modelSrcPosV(idxPoorV)) ));
   disp(sprintf('Measured skill ratio squared for those countries: %5.1f', ...
      mean( measSkillRatioSC(sex,idxPoorV) .^ 2 ) ));
end



if 01
   % ******  Plot: Implied pos in src country distribution  *********
   for sex = c2S.sexAll
      relSourceEarnM(sex,:) = 100 .* sourceEarnSC(sex,:) ./ sourceEarnSC(sex,cUSA);
      idxV = find( relSourceEarnM(sex,:) > 0  & acctS.immSrcPosM(sex,:) > 0 );
      idxV( find(idxV == c2S.cUSA) ) = [];
      %plot( relSourceEarnM(sex,idxV),  100 .* acctS.immSrcPosM(sex,idxV),  'bo' );
      pwlS.FontSize = 8;
      plot_w_labels_lh( relSourceEarnM(sex,idxV),  100 .* acctS.immSrcPosM(sex,idxV), ...
         clabelM(idxV,:), pwlS, dbg);
      xlabel('Relative source country earnings');
      if saveFigures == 1
         fn = c2_fig_fn(3, year, filterNo, expNo, dbg);
         exportfig(gcf, fn, figOptS, 'height', 4);
      end
      pause_print(0);
   end
end


diary off;
%disp(mfilename);
%keyboard;


% *******  eof  *********
