function fxV = c2_logn_expect(xV, mu, sig);
% Return f(x) * x for a log normal distribution with
% parameters mu, sig
% ---------------------------------------------


fxV = lognpdf( xV, mu, sig ) .* xV;

% ********  eof  *******
