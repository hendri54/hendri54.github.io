function invalidV = c2_filter_industry( xV, fltS, dbg );
% Find invalid observations in variable INDUSTRY
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

invalidV = find( xV < 1 );

% ********  eof  ***********
