function c2_process_all
% This program produces all figures and tables
% for the paper from scratch
% Warning: This takes hours to run!
% ---------------------------------------------

global UNDEFINED c2S
dbg = 1;


% ***************  IMPORT AND PROCESS ALL FILTERS  **********
if 01
   for year = [1990, 1980];
      % One-skill model
      runAll = 0;
      c2_process_year(year, 1,   1, runAll, dbg);
      c2_process_year(year, 3,   1, runAll, dbg);
      c2_process_year(year, 4,   1, runAll, dbg);
      c2_process_year(year, 10,  1, runAll, dbg);

      % Two-skill model
      c2_process_year(year, 31, 1,  runAll, dbg);
      % Only run parts that depend on expNo again
      c2_process_year(year, 31, 11, 2, dbg);
      c2_process_year(year, 31, 12, 2, dbg);

      runAll = 1;
      c2_process_year(year, 32, 1, runAll, dbg);
   end % for year
end



% ***************  RESULT TABLES AND FIGURES  ***************
if 0
   % One skill model. No SS.
   year = 1990;  filterNo = 1; expNo = 1;

   % Basic data table
   c2_show_basic_data(year, filterNo, expNo, dbg);

   c2_show_decomp(year, filterNo, expNo, dbg);
   c2_show_select(year, filterNo, expNo, dbg);

   % Two skill model.
   year = 1990;  filterNo = 31; expNo = 12;
   c2_show_decomp(year, filterNo, expNo, dbg);
   c2_show_select(year, filterNo, expNo, dbg);
end



% ***************  UNOBSERVED SKILLS  ******************
if 0
   elast = 2.5;
   c2_two_skill(elast, dbg);
end


% *************  eof  ************
