function [cSchoolV, cExpV, cExpSqV, yearV] = c2_bils_klenow_load;
% Load Bils/Klenow 2000 AER Mincer regression sample
% 54 countries

% OUT:
%     Vectors indexed by PWT5.6 number
%     cSchoolV          School coefficient
%     cExpV             Experience coefficient
%     cExpSqV           Experience squared coefficient
%     yearV             Year

% ----------------------------------------------------

global c2S UNDEFINED
nc = c2S.nCountries;

fn = [c2S.baseDir, 'BilsKlenow.txt'];
m = dlmread(fn, '\t');

pwtV = m(:,1)';

cExpV = UNDEFINED .* ones(1, nc);
cExpV(pwtV) = m(:,2)';

cExpSqV = UNDEFINED .* ones(1, nc);
cExpSqV(pwtV) = m(:,3)';

cSchoolV = UNDEFINED .* ones(1, nc);
cSchoolV(pwtV) = m(:,4)';

yearV = UNDEFINED .* ones(1, nc);
yearV(pwtV) = m(:,5)';


% *******  Self-test  *******
if 0
   disp('PwtNo Exp ExpSq School Year');
   for c = pwtV(:)'
      disp(sprintf('%4i %6.3f %6.3f %6.3f %4i', c,  ...
         cExpV(c), cExpSqV(c), cSchoolV(c), yearV(c) ));
   end
end


% *********  eof  ************
