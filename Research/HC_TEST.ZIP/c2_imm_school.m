function c2_imm_school(year, filterNo, dbg);
% Compute average years of schooling of immigrants
% by country/sex and by country/sex/skill

% OUT:
%  immSchoolM(sex,skill,c)
%  immSchoolSC(sex, skill)
%     Avg years of schooling of immigrants
%     Also for both sexes averaged

%  immSkillWtM(sex,skill,c)
%     Fraction of immigrants in each skill class
%     Sum to 1 for each (sex, c)

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------

global UNDEFINED c2S pwtS

if nargin ~= 3
   abort([ mfilename, ': Invalid nargin' ]);
end

fltS = c2_filter_settings(filterNo, dbg);
% No of imperfectly substitutable skill types
nSkill = fltS.nSkill;
% Which education classes count as skilled/unskilled?
skillIdxM = fltS.skillIdxM;


% **********  Load classified data  **********

%cntM = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );
% Enough observations in each sex/c class?
validSC = load2( c2_class_fn(year, c2S.vValidNobsSC, filterNo, dbg) );
wtM  = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );

[n1, nSex, nAge, nS, nC] = size(wtM);
nC = min(nC, c2S.nCountries);



% *******  Main  ***********

immSchoolM  = repmat( UNDEFINED, [nSex+1, nSkill, c2S.nCountries]);
immSchoolSC = UNDEFINED .* ones(nSex+1, c2S.nCountries);
immSkillWtM = repmat( UNDEFINED, [nSex+1, nSkill, c2S.nCountries]);

for c = 1 : nC
   for sex = 1 : nSex
      % Does country have enough observations?
      if validSC(sex, c) == 1
         for skill = 0 : nSkill
            % Which education classes count for this skill?
            if skill > 0
               skillIdxV = skillIdxM(skill,1) : skillIdxM(skill,2);
            else
               skillIdxV = 1 : nS;  % All classes
            end

            % Total years of schooling of (sex, skill, country) group
            school = 0;
            for s = skillIdxV
               wt = wtM(:,sex,:,s,c);
               school = school + sum(wt(:)) * fltS.educYearsV(s);
            end
            % Schooling per worker
            csWtM = wtM(:,sex,:,skillIdxV,c);
            immSchool = school / sum(csWtM(:));
            if skill > 0
               immSchoolM(sex,skill,c) = immSchool;
               % Total weight of workers in skill class
               immSkillWtM(sex,skill,c) = sum(csWtM(:));
            else
               immSchoolSC(sex,c) = immSchool;
            end
         end % for skill

         % Scale so that weights sum to one for each (sex,country)
         immSkillWtM(sex,1:nSkill,c) = immSkillWtM(sex,1:nSkill,c) ./ ...
            sum(squeeze(immSkillWtM(sex,1:nSkill,c)));
      end % if valid
   end % for sex
end


% *****  Average over sexes  *****
keepMale = 1;
keepNegative = 0;
immSchoolSC(c2S.sexAll,:) = c2_sex_avg(immSchoolSC(1:2,:), fltS.maleWt, ...
   keepMale, keepNegative, dbg);

for skill = 1 : nSkill
   immSchoolM(c2S.sexAll,skill,:) = c2_sex_avg(immSchoolM(1:2,skill,:), fltS.maleWt, ...
      keepMale, keepNegative, dbg);
   immSkillWtM(c2S.sexAll,skill,:) = c2_sex_avg(immSkillWtM(1:2,skill,:), fltS.maleWt, ...
      keepMale, keepNegative, dbg);
end


% ******  Save  *******

save2( immSchoolM,  c2_class_fn(year, c2S.vImmSchool,   filterNo, dbg) );
save2( immSchoolSC, c2_class_fn(year, c2S.vImmSchoolSC, filterNo, dbg) );
save2( immSkillWtM, c2_class_fn(year, c2S.vImmSkillFrac,  filterNo, dbg) );
disp('Saved immigrant schooling data');


% ******  Show  ******
if 0
   disp(' ');
   disp('--- Immigrant years of schooling ---');
   disp('Country       Male Female Average');
   show_table_pwt(immSchoolSC' , '  %5.1f', dbg);
end

%disp(mfilename);
%keyboard;


% ***********  eof  ****************
