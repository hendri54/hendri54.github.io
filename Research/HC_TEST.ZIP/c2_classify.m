function c2_classify(year, filterNo, dbg)
% Create variable files for census data
% Everything is categorized into bins by (dim1, sex, age, education, origin)
% Spec of dim1 varies by filter

% IN
%  year           census year
%  filterNo       filter settings

% Expects input files for all variables created by c2_recode_filter

% Generates result files (c2_filter_fn)

% The result matrices hold CLASS TOTALS for each cell. NOT per capita values!!
% To compute per capita values for a set of classes: Sum the totals in the classes.
% Then divide by total weight of classes.

% Author:         Lutz Hendricks
% Last checked:   1-25-01

% -----------------------------------------------------------

global UNDEFINED c2S pwtS
if nargin ~= 3
   abort([ mfilename, ': Invalid no of input arguments.' ]);
end

disp(' ');
disp('---- Classifying data ----');


% ********  Settings  *********

fltS = c2_filter_settings(filterNo, dbg);
% Classify by age at arrival ('a'), years in US ('y'), or nothing ('0')
dim1Type = fltS.dim1Type;


% *********  Load Data  ************

wtV    = c2_pums_load(c2S.vWeight, year, filterNo, dbg);
ageV   = c2_pums_load(c2S.vAge, year, filterNo, dbg);
bplV   = c2_pums_load(c2S.vBPL, year, filterNo, dbg);
yrsUSv = c2_pums_load(c2S.vYearsUSA, year, filterNo, dbg);
earnV  = c2_pums_load(c2S.vEarnings, year, filterNo, dbg);
hoursV = c2_pums_load(c2S.vHoursWk, year, filterNo, dbg);
sexV   = c2_pums_load(c2S.vSex, year, filterNo, dbg);
weeksYrV    = c2_pums_load(c2S.vWeeksYr, year, filterNo, dbg);
schoolYrsV  = c2_pums_load(c2S.vYrsSchool, year, filterNo, dbg);
%arrivalAgeV = c2_pums_load(c2S.vArrivalAge, year, filterNo, dbg);

% Keep at most nMax observations
nObs = length(wtV);
n    = min( nObs, fltS.nMax );

if n < nObs
   tmp = sprintf('  nObs: %i     Retained: %i', nObs, n);
   warnmsg([ mfilename, ':  Truncating observations' ], tmp);
   wtV   = wtV(1:n);
   ageV  = ageV(1:n);
   bplV  = bplV(1:n);
   yrsUSv= yrsUSv(1:n);
   earnV = earnV(1:n);     % annual earnings
   hoursV= hoursV(1:n);    % weekly hours
   sexV  = sexV(1:n);
   schoolYrsV = schoolYrsV(1:n);     % Education in years
   weeksYrV   = weeksYrV(1:n);
   %arrivalAgeV = arrivalAgeV(1:n);
else
   disp(sprintf('No of observations loaded: %i', n));
end


% *** Check vectors ***
nC = max(bplV);
idxV = find(bplV > 0);
v_check( bplV(idxV), 'i', UNDEFINED, 1, nC );
idxV = find( sexV > 0 );
v_check( sexV, 'i', UNDEFINED, c2S.male, c2S.female );
nativeFraction = sum( bplV == pwtS.cUSA ) / n;
if nativeFraction < 0.1  |  nativeFraction > 0.8
   warnmsg([ mfilename, ':  Too many or too few native observations' ]);
   disp(nativeFraction);
   %keyboard
end


% ******* FIRST DIMENSION OF CLASSIFICATION  *********
% Either arrival age or years in US
% Always code natives as class 1

if dim1Type == 'a'         % By age at arrival
   disp('  First dimension: age at arrival');
   dim1UpperV = fltS.arrAgeUpperV;
   dim1ClV = classify(arrivalAgeV, dim1UpperV, dbg);
elseif dim1Type == 'y'     % By years in US
   disp('  First dimension: years in USA');
   dim1UpperV = fltS.yrsUSAUpperV;
   dim1ClV = classify(yrsUSv, dim1UpperV, dbg);
elseif dim1Type == '0'      % First dimension omitted
   disp('  No first dimension');
   dim1UpperV = UNDEFINED;
   dim1ClV = ones(1, n);
   nDim1 = 1;
else
   abort([ mfilename, ': Invalid dim1Type' ]);
end

if dim1Type ~= '0'
   % Natives are coded 1
   dim1ClV( bplV == pwtS.cUSA ) = 1;
   nDim1 = length( dim1UpperV );
   v_check( dim1ClV, 'i', [1, n], 1, nDim1 );
end



% ***  Assign age classes, make sure the top class holds everybody
ageV = min(ageV, fltS.ageUpperV(end));
ageClV = classify(ageV, fltS.ageUpperV, dbg);
nAge = length(fltS.ageUpperV);
v_check( ageClV(:), 'i', [n,1], 1, nAge );

% Verify class assignment
if dbg > 10
   for i = 1 : 200 : n
      ageCl = ageClV(i);
      age   = ageV(i);
      if  age > fltS.ageUpperV(ageCl)
         abort([ mfilename, ': Invalid ageCl' ]);
      end
      if ageCl > 1
         if age <= fltS.ageUpperV(ageCl-1)
            abort([ mfilename, ': Invalid ageCl #2' ]);
         end
      end
   end
end


% ***  Assign education classes  ***
nS = length(fltS.educUpperV);
educV = classify(schoolYrsV, fltS.educUpperV, dbg);
v_check( educV(:), 'i', [n,1], 1, nS );


% **************  COMPUTE WEIGHTED SUMS  *******************
% Initialize result matrices
nSex = 2;
earnM    = zeros(nDim1, nSex, nAge, nS, nC);
hoursM   = zeros(nDim1, nSex, nAge, nS, nC);
weeksYrM = zeros(nDim1, nSex, nAge, nS, nC);
hoursYrM = zeros(nDim1, nSex, nAge, nS, nC);
wtM      = zeros(nDim1, nSex, nAge, nS, nC);   % Total weights
cntM     = zeros(nDim1, nSex, nAge, nS, nC);   % No of observations
% logEarnM = zeros(nDim1, nSex, nAge, nS, nC);   % Log per capita earnings
% logEarnV = log( earnV );

for i = 1 : n
   if rem(i, 50*1000) == 0
      disp(sprintf('Observation %i thousand', round(i/1000) ));
   end
   idx1  = dim1ClV(i);
   sex   = sexV(i);
   age   = ageClV(i);
   educ  = educV(i);
   iC    = bplV(i);
   wt    = wtV(i);
   cntM(idx1, sex, age, educ, iC)   = cntM(idx1, sex, age, educ, iC) + 1;
   wtM(idx1, sex, age, educ, iC)    = wtM(idx1, sex, age, educ, iC)  + wt;
   earnM(idx1, sex, age, educ, iC)  = earnM(idx1, sex, age, educ, iC)  + wt .* earnV(i);
   hoursM(idx1, sex, age, educ, iC) = hoursM(idx1, sex, age, educ, iC) + wt .* hoursV(i);
   weeksYrM(idx1, sex, age, educ, iC) = weeksYrM(idx1, sex, age, educ, iC) + wt .* weeksYrV(i);
   hoursYrM(idx1, sex, age, educ, iC) = hoursYrM(idx1, sex, age, educ, iC) ...
      + wt .* weeksYrV(i) .* hoursV(i);
   % logEarnM(idx1, sex, age, educ, iC) = logEarnM(idx1, sex, age, educ, iC) + wt .* logEarnV(i);
end



% *********  SAVE  **********

save2( wtM, c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Earnings: Total in each cell. Not per capita. Annual
save2( earnM, c2_class_fn(year, c2S.vEarnings, filterNo, dbg) );
% Hours per week. Not per capita
save2( hoursM, c2_class_fn(year, c2S.vHoursWk, filterNo, dbg) );
% Weeks per year. Not per capita
save2( weeksYrM, c2_class_fn(year, c2S.vWeeksYr, filterNo, dbg) );
% Hours per year. Not per capita
save2( hoursYrM, c2_class_fn(year, c2S.clHoursYr, filterNo, dbg) );
% Count in each cell.
save2( cntM, c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );
% Log earnings. Not per capita
% save2( logEarnM, c2_class_fn(year, c2S.vLogEarn, filterNo, dbg) );

% Save "meta-info" about data
clInfoS.dim1Type     = dim1Type;
clInfoS.educYearsV   = fltS.educYearsV;
clInfoS.ageUpperV    = fltS.ageUpperV;
clInfoS.dim1UpperV   = dim1UpperV;
save2( clInfoS, c2_class_fn(year, c2S.vClassInfo, filterNo, dbg) );


% ********  Basic checks  **********

clCntM = cntM(1,:,:,:,c2S.cUSA);
idxV = find( clCntM < 50 );
if length(idxV) > 0
   warnmsg([ mfilename, ':  Cells with < 50 observations found for natives' ]);
   disp(sprintf('No of cells: %i     Min cnt: %i', length(idxV), ...
      min(clCntM(:)) ));
end


%disp(mfilename)
%keyboard


% *** end function ***
