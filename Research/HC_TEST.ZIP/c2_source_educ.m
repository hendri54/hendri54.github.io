function c2_source_educ(year, filterNo, dbg);
% Compute fraction with each education level for source countries
% Output matrix is indexed by [sex, education, country]

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------

global UNDEFINED bl2S c2S

fltS = c2_filter_settings(filterNo, dbg);
nSex = 2;

% Fraction attending exactly each Barro/Lee level (7 levels)
% by (country, year, level, sex)
[frac7M, success] = var_load_yr_bl2(bl2S.cvAttend7, year, fltS.BLstartAge, 1, dbg);
[nc, nlBL, nsexBL] = size(frac7M);
if nsexBL ~= 3
   warnmsg([ mfilename, ':  Invalid 3rd dimension frac7M' ]);
   keyboard
end


% *****  Mapping Barro-Lee into my levels  *******

% Years of schooling for my schooling classes
educYearsV = fltS.educYearsV;
% Upper bounds for my schooling classes
educUpperV = fltS.educUpperV;

% Upper bounds for BL education classes
blUpperV = fltS.blUpperV;



% ******  Fraction in each of my classes by country  *******

bl2SexV = [bl2S.sexMale, bl2S.sexFemale];
% Fraction in each education class by country/sex
sourceEducM = UNDEFINED .* ones([nSex, length(educUpperV), c2S.nCountries]);

for c = 1 : nc
   for sex = 1 : nSex
      % Fraction in each BL class
      frac7V = squeeze(frac7M(c, :, bl2SexV(sex)));
      % Does country have data?
      if min(frac7V) >= 0
         % Cdf of schooling years from Barro-Lee
         % Ie: Fraction with schooling at most blUpperV years
         % Should process data earlier on so that fractions sum to 1 +++
         cdfV = cumsum( frac7V );
         if abs(cdfV(nlBL) - 1) > 0.1
            warnmsg([ mfilename, ':  Invalid cdf' ]);
            keyboard;
         end
         cdfV = cdfV ./ cdfV(nlBL);

         % Find cumulative fraction by my education class
         % by interpolating the cdf of BL2000
         cumFracV = interp1( blUpperV, cdfV, educUpperV, 'linear' );
         if abs(cumFracV(end) - 1) > 0.02
            warnmsg([ mfilename, ':  Invalid cumFracV' ]);
            keyboard;
         end
         cumFracV = cumFracV ./ cumFracV(end);

         % Mass by class
         sourceEducM(sex, :, c) = cumFracV - [0, cumFracV(1:end-1)];
      end
   end
end


% *********  Save  ***********

save2( sourceEducM, c2_class_fn(year, c2S.vSourceEduc, filterNo, dbg) );


% *********  Self-test  ***************
% Show my cdf and BL's cdf for some countries
if 0
   countryV = [84 125 72 80 52 3];
   sexV = [1 2 1 2 1 2 1 2];
   for i = 1 : length(countryV)
      c = countryV(i);
      sex = sexV(i);
      blCdfV = cumsum(squeeze( frac7M(c, :, bl2SexV(sex)) ));
      blCdfV = blCdfV(:)' ./ blCdfV(end);
      myCdfV = cumsum(squeeze(sourceEducM(sex, :, c)));
      myCdfV = myCdfV(:)' ./ myCdfV(end);

      plot( min(20, blUpperV), blCdfV, 'b-',  min(20, educUpperV), myCdfV, 'r-' );
      title(sprintf('Cdfs for country %i', c));
      pause_print(0);
   end
end

% *************  Compute avg years of schooling  ***********
% Compare with Barro-Lee
if 0
   disp(' ');
   disp('------  Avg years of schooling  --------');
   disp(' ');
   % Load BL avg years of schooling by (country, sex)
   [blAvgYrM, success] = var_load_yr_bl2(bl2S.vAvgYrAll, year, fltS.BLstartAge, 1, dbg);

   disp('PwtNo   M A L E   F E M A L E');
   disp('       LH    BL   LH    BL');
   for c = 1 : nc
      % Avg years of schooling by sex from my data
      avgYrsV = [0 0];
      for sex = [c2S.male, c2S.female]
         educFracV = squeeze(sourceEducM(sex,:,c));
         if min(educFracV) >= 0
            avgYrsV(sex) = sum(educFracV(:) .* educYearsV(:));
         end
      end
      dataV = [c, avgYrsV(c2S.male), blAvgYrM(c, bl2S.sexMale), ...
               avgYrsV(c2S.female), blAvgYrM(c, bl2S.sexFemale)];
      if min(dataV >= 0)
         disp(sprintf('%4i:  %5.1f  %5.1f    %5.1f  %5.1f', dataV));
      end
   end
end

%disp(mfilename);
%keyboard;

% ********  eof  ********
