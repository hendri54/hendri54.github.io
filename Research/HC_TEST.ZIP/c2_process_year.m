function c2_process_year(year, filterNo, expNo, runAll, dbg);
% Process one year completely
% Assumes that the following has been run previously
% - PUMS data have been saved as individual variables
% - PUMS variables have been recoded

% runAll
%  0           Only run what has been explicitly switched on
%  1           Run everthing except for showing results
%  2           Same as runAll=1, but only run programs that depend on expNo
%              Purpose: Run filter once with runAll=1. Then run all experiments
%              with runAll = 2

% Author: Lutz Hendricks
% Last checked: 10-11-98
% ---------------------------

global UNDEFINED c2S

if nargin ~= 5
   abort([ mfilename, ': Invalid no of arguments' ]);
end

v_check( year, 'i', [1,1], 1910, 2050 );
v_check( filterNo, 'i', [1,1], 1, 999 );

c2_iniglob;



% *******  Recode/filter the PUMS data files  **********
% There is a pair of ascii files for each variable, one
% for immigrants and one for natives.
disp(' ');
disp('-------  Recoding/Filtering PUMS data  -------');

if runAll == 1  |  0
   c2_recode_filter(year, filterNo, dbg);
else
   disp(' ');
   disp('!! Skipped !!');
   disp(' ');
end




disp(' ');
disp('-------  Sorting data into classes  -------');
if runAll == 1  |  0
   c2_classify(year, filterNo, dbg);
else
   disp(' ');
   disp('!! Skipped !!');
   disp(' ');
end


disp(' ');
disp('-------  Estimating source country std dev of log earnings  -------');
if runAll == 1  |  0
   c2_source_sig(year, filterNo, dbg);
else
   disp(' ');
   disp('!! Skipped !!');
   disp(' ');
end


disp(' ');
disp('-------  Estimating K/Y  -------');
if runAll == 1  |  0
   c2_ky(year, filterNo, dbg);
else
   disp(' ');
   disp('!! Skipped !!');
   disp(' ');
end


disp(' ');
disp('-------  Estimating source country earnings etc  -------');
if runAll == 1  |  01
   % Fraction living in USA
   c2_imm_count(year, dbg);
   % Source country education
   c2_source_educ(year, filterNo, dbg);
   % Source country age composition
   c2_source_age(year, filterNo, dbg);
   % Source country age/education composition
   c2_source_weights(year, filterNo, dbg);
   % Gender gap by country
   c2_gender_gap(year, filterNo, dbg);
   % Relative earnings by skill
   c2_src_rel_earn(year, filterNo, dbg);
   % Average source country earnings by sex
   c2_source_earn(year, filterNo, dbg);
else
   disp(' ');
   disp('!! Skipped !!');
   disp(' ');
end


disp(' ');
disp('-------  Estimating immigrant earnings  -------');
if runAll == 1  |  01
   % No of observations by sex/skill/country
   c2_nobs(year, filterNo, dbg);
   % Mark sex/skill/country combinations with sufficient number of obs
   c2_valid_nobs(year, filterNo, dbg);
   % Compute average years of schooling of immigrants
   % by country/sex
   c2_imm_school(year, filterNo, dbg);
   % Compute hours per year by (sex/skill/country)
   c2_hours_year(year, filterNo, dbg);
   % Earnings per worker and hourly wage rate
   c2_earn_per_worker(year, filterNo, dbg);
   % Earnings of immigrants and natives
   c2_imm_earn(year, filterNo, dbg);
   % Position of avg immigrant in source country skill distribution
   c2_imm_skill_pos(year, filterNo, dbg);
else
   disp(' ');
   disp('!! Skipped !!');
   disp(' ');
end


disp(' ');
disp('-------  Self-selection  -------');
if runAll == 1  |  01
   % Immigrant self-selection
   c2_imm_select(year, filterNo, dbg);
   % Relative Immigrant earnings in source countries.
   % Using Mincer regressions
   c2_mincer_imm(year, filterNo, dbg);
else
   disp(' ');
   disp('!! Skipped !!');
   disp(' ');
end


% -----------  NOTHING ABOVE HERE DEPENDS ON expNo  --------------------


% ***********  ACCOUNTING  ********************
% This creates the decomposition of Y/L differences
% Perfect or imperfect substitution of skill classes
if runAll == 1  |  runAll == 2  |  01
   % Decomposition of earnings gap
   c2_acct_run(year, filterNo, expNo, dbg);
end


% ********  Show findings  **********
if 0
   c2_show_select(year, filterNo, expNo, dbg);
end
if 0
   c2_show_earn_dist(year, filterNo, dbg);
end
if 0
   c2_host_compare(year, filterNo, dbg);
end
if 0
   % Table with basic data on source countries and immigrants
   c2_show_basic_data(year, filterNo, dbg);
end


% *** end function ***
