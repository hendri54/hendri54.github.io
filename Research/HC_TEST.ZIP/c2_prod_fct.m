function [MPLv, MPK, Y, LShareV, Kshare] = c2_prod_fct(KY, Lv,  ...
   A, LSweight, capShare, substElast, dbg);
% ----------------------------------------------------
% Production function with perfect or imperfect substitution
% of skilled and unskilled labor.

% IN:
%  KY          Capital-output ratio (not capital input!)
%  Lv          Efficiency units of unskilled and skilled labor PER WORKER:
%              l(c) * lambda(c)
%              Scalar if there is only 1 skill type
%  A           Productivity level
%  LSweight    Not used if only one skill type
%  capShare
%  substElast

% OUT:
%  MPK         marginal product of K
%  MPLv        marginal product of [LU, LS] in efficiency units
%  Y           output per worker
%  LShareV, Kshare
%              factor income shares of [LU LS K]

% TEST:  t_c2_prod_fct

% ----------------------------------------------------

global UNDEFINED


% *******  Process/check inputs  *********

if nargin ~= 7
   abort([ mfilename, ': Invalid no of inputs' ]);
end

nSkill = length(Lv);

if dbg > 10
   v_check( Lv, 'f', [1,nSkill], 1e-8, UNDEFINED );
   v_check( A,  'f', [1,1], 1e-8, UNDEFINED );
end


if nSkill == 1
   [MPLv, MPK, Y] = c2_prod_fct_1skill(KY, Lv,  A, capShare, dbg);
   LShareV = 1 - capShare;
   KShare  = capShare;

elseif nSkill == 2
   LU = Lv(1);
   LS = Lv(2);

   rho   = LSweight;
   zeta  = 1 - 1 / substElast;
   theta = capShare;



   % ********  Main section  ******

   G = (rho .* LS.^zeta + (1-rho) .* LU.^zeta) .^ (1/zeta);

   mplFactor = (1-theta)  .*  KY .^ (theta/(1-theta))  .*  G.^(1-zeta) ...
      .*  A .^ (1/(1-theta));

   MPLS = mplFactor .* rho     .*  LS.^(zeta-1);

   MPLU = mplFactor .* (1-rho) .*  LU.^(zeta-1);

   Y = A .^ (1/(1-theta))  .*  KY .^ (theta/(1-theta))  .*  G;

   MPK = theta ./ KY;


   % Factor income shares
   LSshare = MPLS .* LS ./ Y;
   LUshare = MPLU .* LU ./ Y;
   Kshare  = MPK  .* KY;


   % *** Return values ***

   MPLv = [MPLU, MPLS];
   LShareV = [LUshare, LSshare];

   if dbg > 10
      sizeV = size(LU);
      v_check( MPK,  'f', sizeV, 0, UNDEFINED );
      v_check( MPLS, 'f', sizeV, 0, UNDEFINED );
      v_check( MPLU, 'f', sizeV, 0, UNDEFINED );
      v_check( Y,    'f', sizeV, 0, UNDEFINED );

      % Factor shares should add to 1
      shareSum = LSshare + LUshare + Kshare;
      if max(abs(shareSum - 1)) > 1e-5
         warnmsg([ mfilename, ':  Factor shares do not sum to 1' ]);
         keyboard;
      end
   end

else
   abort([ mfilename, ': Invalid nSkill' ]);
end



%disp(mfilename);
%keyboard;

% **********  eof  ***********
