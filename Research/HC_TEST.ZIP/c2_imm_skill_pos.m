function c2_imm_skill_pos(year, filterNo, dbg)
% Compute percentile position of mean immigrant in the
% source country distribution of measured skills.
% For each skill, the position is in the entire distribution,
% not within a skill class!

% OUT:  Stored in variable files
%  immPosM(sex, skill, c)
%     where skill is the unskilled/skilled definition
%     of c2_filter_settings
%  immPosSC(sex, c)
%     Same across all skill classes

% AUTHOR:  Lutz Hendricks
% LAST CHECKED: 3-3-2001

% ---------------------------------------------------

global c2S UNDEFINED

disp(' ');
disp('Immigrant position in skill distribution');

cUSA = c2S.cUSA;
male = c2S.male;
female = c2S.female;


% ******  Filter settings  *******
fltS = c2_filter_settings(filterNo, dbg);
educUpperV = fltS.educUpperV;
% Must impose a reasonable value for highest class
% for interpolation
educUpperV(end) = educUpperV(end-1) + 4;

% No of imperfectly substitutable skill types
nSkill = fltS.nSkill;
% Which education classes count as skilled/unskilled?
skillIdxM = fltS.skillIdxM;



% ********  Load data  ************

% Total weight in each cell
wtM = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
[n1, nSex, nAge, nS, nC] = size(wtM);

% Count in each cell.
cntM = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );

% Avg years of schooling of immigrants, by country/skill/sex
immSchoolM = load2( c2_class_fn(year, c2S.vImmSchool, filterNo, dbg) );
if ~isequal( size(immSchoolM), [nSex+1, nSkill, nC] )
   warnmsg([ mfilename, ':  Invalid size of immSchoolM' ]);
   keyboard;
end
% Avg years of schooling of immigrants, by country/sex
immSchoolSC = load2( c2_class_fn(year, c2S.vImmSchoolSC, filterNo, dbg) );
if ~isequal( size(immSchoolSC), [nSex+1, nC] )
   warnmsg([ mfilename, ':  Invalid size of immSchoolSC' ]);
   keyboard;
end

% Source country population weights
sourceWtM = load2( c2_class_fn(year, c2S.vSourceWt, filterNo, dbg) );




% **********  Compute immigrant position in distribution  ****************

immPosM  = UNDEFINED .* ones([nSex, nSkill, nC]);
immPosSC = UNDEFINED .* ones([nSex, nC]);

% Total count and weight by country
cCntV = zeros(1, nC);
cWtV  = zeros(1, nC);

for c = 1 : nC
   % No of observations for this country
   cCntM = cntM(:,:,:,:,c);
   cCntV(c) = sum( cCntM(:) );

   % Enough observations?
   if cCntV(c) >= fltS.minObs
      for sex = 1 : nSex
         % *****  Position in skill distribution  ****
         % Skill = 0: All skill classes
         for skill = 0 : nSkill
            % Which education classes count for this skill?
            if skill > 0
               skillIdxV = skillIdxM(skill,1) : skillIdxM(skill,2);
               minObs = fltS.minObsSS;
            else
               skillIdxV = 1 : nS;
               minObs = fltS.minObsSex;
            end

            % Weights for this (sex, skill, country)
            csWtM  = wtM(:,sex,:,skillIdxV,c);
            csWt   = sum( csWtM(:) );
            csCntM = cntM(:,sex,:,skillIdxV,c);
            csCnt  = sum( csCntM(:) );
            % Source country weights
            srcWtM = squeeze(sourceWtM(:,sex,:,skillIdxV,c));

            % Enough observations?
            if csCnt >= minObs  &  csWt > 0  &  min(srcWtM(:)) >= 0  ...
               &  min(squeeze(immSchoolM(sex,:,c))) > 0

               % *** Construct cdf of schooling ***
               % across skill classes

               % Source country weights
               srcWtM = squeeze(sourceWtM(:,sex,:,:,c));
               % Sum of dim1 to get weight by (age, school)
               if n1 > 1
                  schoolWtM = squeeze(sum(srcWtM, 1));
               else
                  schoolWtM = srcWtM;
               end
               v_check( schoolWtM, 'f', [nAge, nS], 0, 1 );
               % Sum over ages to get weights by school class
               schoolWtV = sum(schoolWtM, 1);
               % Cdf
               schoolCdfV = cumsum( schoolWtV );
               schoolCdfV = schoolCdfV ./ schoolCdfV(end);
               v_check( schoolCdfV, 'f', [1,nS], 0, 1 );

               % *** Interpolate cdf to get immigrant position ***
               if skill > 0
                  if immSchoolM(sex,skill,c) < educUpperV(end)
                     immPosM(sex,skill,c) = interp1( [0, educUpperV], [0, schoolCdfV], ...
                        immSchoolM(sex,skill,c), 'linear' );
                  else
                     immPosM(sex,skill,c) = 1;
                  end
               else
                  % All skills
                  if immSchoolSC(sex,c) < educUpperV(end)
                     immPosSC(sex,c) = interp1( [0, educUpperV], [0, schoolCdfV], ...
                        immSchoolSC(sex,c), 'linear' );
                  else
                     immPosSC(sex,c) = 1;
                  end
               end
            end
         end % for skill
      end % for sex
   end
end % for c



% *******  Save  **********

save2( immPosM,  c2_class_fn(year, c2S.vImmSchoolPos,   filterNo, dbg) );
save2( immPosSC, c2_class_fn(year, c2S.vImmSchoolPosSC, filterNo, dbg) );

disp(sprintf('  No of valid observations:  %i', sum(immPosM(male,1,:) > 0) ));

%disp(mfilename);
%keyboard;


% ***********  eof  ************
