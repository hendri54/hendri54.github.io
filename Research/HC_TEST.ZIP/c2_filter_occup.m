function invalidV = c2_filter_occup( xV, fltS, dbg );
% Find invalid observations in variable OCCUPATION
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

invalidV = find( xV < 1 );

% ********  eof  ***********
