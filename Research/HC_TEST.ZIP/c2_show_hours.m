function c2_show_hours(year, filterNo, expNo, dbg);
% Show hours worked per year for immigrants and natives
% ------------------------------------------------------

global UNDEFINED c2S
male = c2S.male;
female = c2S.female;
nc = c2S.nCountries;

fltS = c2_filter_settings(filterNo, dbg);

% Load strings with country names
[cn, cnLen, cnMax] = cnames(c2S.pwtVer);

% Hours per week by (sex, skill, country)
hoursYrM = load2( c2_class_fn(year, c2S.vHoursYr, filterNo, dbg) );

disp(' ');
disp('---------------- Work hours stats:   ----------------');

disp(' ');
disp('Country          Hours per year Hours rel to US');
disp('                 Male  Female   Male  Female');

for skill = 1 : fltS.nSkill
   disp(' ');
   disp(sprintf('*** Skill %i ***', skill));
   for c = 1 : nc
      dataV = [hoursYrM(male,skill,c), hoursYrM(female,skill,c), ...
         100*(hoursYrM(male,skill,c)/hoursYrM(male,skill,c2S.cUSA)-1), ...
         100*(hoursYrM(female,skill,c)/hoursYrM(female,skill,c2S.cUSA)-1)];
      if max(dataV) > 0
         disp([ sprintf('%15s  ', cn(c,1:15)), sprintf(' %6.0f', dataV) ]);
      end
   end
end






% *********  eof  **********
