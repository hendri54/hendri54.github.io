function [idxRichV, idxPoorV] = c2_richest_poorest(N, relEarnV, validV, dbg);
% Return indices of the richest and the poorest N countries
% Countries are ranked according to relEarnV
% validV(i) = 1 indicates that country i has valid data

% TEST:  t_richest_poorest

% ------------------------------------------------------------------

global UNDEFINED

if ~isequal( size(relEarnV), size(validV) )
   abort([ mfilename, ': Size mismatch' ]);
end

if any(relEarnV <= 0)
   validV(relEarnV <= 0) = UNDEFINED;
end

% Extract valid observations
idxValidV = find( validV > 0.5 );
earnV = relEarnV(idxValidV);
nc = length(earnV);
if nc < 2 * N
   warnmsg([ mfilename, ':  Too few observations' ]);
   keyboard;
end


% Sort
sortM = sortrows( [earnV(:), idxValidV(:)], 1 );

idxRichV = sortM(nc-N+1 : nc, 2)';
idxPoorV = sortM(1:N, 2)';


% ******  Self-test  ******
if 1
   % Check that the richest are richer than the rest
   richMinEarn = min( relEarnV(idxRichV) );
   % Valid obs excluding the rich
   idxV = idxValidV;
   for i = 1 : N
      j = find( idxV == idxRichV(i) );
      if length(j) == 1
         idxV(j) = [];
      else
         warnmsg([ mfilename, ':  Not possible' ]);
         keyboard
      end
   end
   otherMaxEarn = max( relEarnV(idxV) );
   if otherMaxEarn > richMinEarn
      warnmsg([ mfilename, ':  Invalid rich earnings' ]);
   end


   % Check that the poorest are poorer than the rest
   poorMaxEarn = max( relEarnV(idxPoorV) );
   % Valid obs excluding the poor
   idxV = idxValidV;
   for i = 1 : N
      j = find( idxV == idxPoorV(i) );
      if length(j) == 1
         idxV(j) = [];
      else
         warnmsg([ mfilename, ':  Not possible' ]);
         keyboard
      end
   end
   otherMinEarn = min( relEarnV(idxV) );
   if otherMinEarn < poorMaxEarn
      warnmsg([ mfilename, ':  Invalid poor earnings' ]);
   end
end



% ********   eof   ***********
