function c2_class_earn(year, filterNo, dbg)
% Compute
% - mean earnings by (sex, skill, country) in USA
% - mean hours per year by (sex, skill, country)


% Uses data sorted into classes by c2_classify

% OUT:  Stored in variable files
%  immEarnM(sex, skill, c)
%     Mean immigrant earnings
%     Also for both sexes
%  hoursYrM(sex, skill, c)
%     Mean hours worked per year per worker
%     Also for both sexes

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  2-12-2001

% ---------------------------------------------------

global c2S UNDEFINED

cUSA = c2S.cUSA;
male = c2S.male;
female = c2S.female;


% ******  Filter settings  *******
fltS = c2_filter_settings(filterNo, dbg);

% No of imperfectly substitutable skill types
nSkill = fltS.nSkill;
% Which education classes count as skilled/unskilled?
skillIdxM = fltS.skillIdxM;

% Weight assigned to males when averaging over sexes
maleWt = fltS.maleWt;



% ********  Load data  ************

wtM = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Earnings: Total in each cell. Not per capita. Annual
earnM = load2( c2_class_fn(year, c2S.vEarnings, filterNo, dbg) );
% Hours per week. Not per capita
hoursWkM = load2( c2_class_fn(year, c2S.vHoursWk, filterNo, dbg) );
% Weeks per year
weeksYrM = load2( c2_class_fn(year, c2S.vWeeksYr, filterNo, dbg) );
% Count in each cell.
cntM = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );

[n1, nSex, nAge, nS, nC] = size(wtM);




% **********  Compute averages  ****************

% Avg earnings of immigrants
immEarnM = repmat( UNDEFINED, [nSex+1, nSkill, nC] );
% Hours per worker per year
hoursYrM = repmat( UNDEFINED, [nSex+1, nSkill, nC] );


for c = 1 : nC
   % No of observations for this country
   cCntM = cntM(:,:,:,:,c);
   cCnt = sum( cCntM(:) );

   % Enough observations?
   if cCnt >= fltS.minObs
      for sex = 1 : nSex
         for skill = 1 : nSkill
            skillIdxV = skillIdxM(skill,1) : skillIdxM(skill,2);

            % Weights for this (sex, skill, country)
            csWtM  = wtM(:,sex,:,skillIdxV,c);
            csWt   = sum( csWtM(:) );
            csCntM = cntM(:,sex,:,skillIdxV,c);

            % Enough observations?
            if sum(csCntM(:)) >= fltS.minObsSS  &  csWt > 0
               % Compute average immigrant earnings
               immEarn = earnM(:,sex,:,skillIdxV,c);
               immEarnM(sex, skill, c) = sum(immEarn(:)) / csWt;

               % *** Avg hours per year ***
               csHoursM = hoursWkM(:,sex,:,skillIdxV,c);
               hoursWk  = sum(csHoursM(:)) / csWt;
               % Avg weeks per year
               csWeeksM = weeksYrM(:,sex,:,skillIdxV,c);
               weeksYr  = sum(csWeeksM(:)) / csWt;
               % Avg Hours per year
               hoursYrM(sex, skill, c) = hoursWk * weeksYr;
            end
         end % for skill
      end % for sex
   end  % if
end % for c



% ****  Average over sexes.  *****
% Use only one sex, if the other does not have data
keepMale = 1;
keepNegative = 0;

for skill = 1 : nSkill
   immEarnM(c2S.sexAll,skill,:) = c2_sex_avg( squeeze(immEarnM(1:2,skill,:)), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
   hoursYrM(c2S.sexAll,skill,:) = c2_sex_avg( squeeze(hoursYrM(1:2,skill,:)), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
end % for skill



% *******  Save  **********

save2( immEarnM,     c2_class_fn(year, c2S.vImmEarn, filterNo, dbg) );
save2( hoursYrM,     c2_class_fn(year, c2S.vHoursYr, filterNo, dbg) );


disp('Saved relative immigrant earnings data.');


%disp(mfilename);
%keyboard;

% ***********  eof  ************
