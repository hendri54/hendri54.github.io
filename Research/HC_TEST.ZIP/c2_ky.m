function c2_ky(year, filterNo, dbg);
% Construct K/Y for all countries.
% Interpolate based on Y/L for missing values

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% --------------------------------------------

global pwtS c2S UNDEFINED
cUSA = c2S.cUSA;
% All vectors are row vectors of this length
nc = c2S.nCountries;

% Load PWT variables
kapwV  = getvar(pwtS.kapwIdx, year, year, c2S.pwtVer, dbg)';
rgdpwV = getvar(pwtS.rgdpwIdx, year, year, c2S.pwtVer, dbg)';
pwtKYv = kapwV ./ rgdpwV;
if length(pwtKYv) < nc
   pwtKYv(end+1 : nc) = UNDEFINED;
   rgdpwV(end+1 : nc) = UNDEFINED;
else
   pwtKYv = pwtKYv(1:nc);
   rgdpwV = rgdpwV(1:nc);
end

% Real gdp relative to US
relRGDPWv = rgdpwV(:)' ./ rgdpwV(cUSA);
relRGDPWv( relRGDPWv <= 0 ) = UNDEFINED;


% McGrattan/Schmitz 1998 K/Y
msKYv = load(c2S.mcgrattan_ky_fn)';
if length(msKYv) < nc
   msKYv(end+1 : nc) = UNDEFINED;
else
   msKYv = msKYv(1:nc);
end


% Which one to use?
if 0
   KYv = pwtKYv;
else
   KYv = msKYv;
end


% Drop missing RGDPW observations
missV = find( rgdpwV <= 0 );
KYv(missV) = UNDEFINED;
disp(sprintf('No of countries without RGDPW data: %i', length(missV)));

idxV = find( KYv <= 0  &  rgdpwV > 0 );
disp(sprintf('No of countries with missing KAPW data: %i', length(idxV) ));

if length(idxV) > 0
   % Fill in missing values based on regression
   validV = find( KYv > 0  &  rgdpwV > 0 );
   Kv(validV) = KYv(validV) .* rgdpwV(validV);

   xM = [ones(length(validV),1),  log(rgdpwV(validV))'];
   bV = regress( log(Kv(validV))', xM, 0.05 );

   disp(sprintf('Regression of log K on log RGDPW yields: b1 = %6.3f,  b2 = %6.3f', ...
      bV(1:2) ));

   % Fill in the predicted values
   Kv(idxV) = exp( bV(1) + bV(2) .* log(max(0.01,rgdpwV(idxV))) );
   KYv(idxV) = Kv(idxV) ./ rgdpwV(idxV);

   if 0
      msKYv = msKYv ./ msKYv(cUSA) .* KYv(cUSA);
      pwtKYv = pwtKYv ./ pwtKYv(cUSA) .* KYv(cUSA);
      % Plot actual and filled in values
      plot( max(0,rgdpwV), max(0, pwtKYv), 'bo', ...
            max(0,rgdpwV(idxV)), max(0,KYv(idxV)),   'mo', ...
            max(0,rgdpwV), max(0,msKYv), 'ro' );
      title('K/Y vs. RGDPW');
      legend('PWT', 'Imputed', 'McGrattan/Schmitz');
      pause_print(0);

      disp(sprintf('US value of K/Y: %6.3f',  KYv(pwtS.cUSA) ));
   end

end




% *******  Save  ********

save2( KYv,  c2_class_fn(year, c2S.vKY, filterNo, dbg) );
save2( relRGDPWv,  c2_class_fn(year, c2S.vRelRGDPWv, filterNo, dbg) );


% ******  Show  ******
if 0
   disp(' ');
   disp('--- Source country K/Y ---');
   disp('Country       RelGDP  Rel K/Y');
   relGDPv = rgdpwV ./ rgdpwV(cUSA);
   relKYv  = KYv ./ KYv(cUSA);
   relKYv( relKYv <= 0 ) = UNDEFINED;
   relGDPv( relGDPv <= 0 ) = UNDEFINED;
   show_table_pwt([relGDPv(:), relKYv(:)] , '  %5.2f  %5.2f', dbg);
end
%disp(mfilename);
%keyboard;


% *************  eof  *************
