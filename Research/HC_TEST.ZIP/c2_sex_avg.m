function mAvgV = c2_sex_avg(m, maleWt, keepMale, keepNegative, dbg);
% Average over sexes
% Either drops data without observations of both sexes
% or keeps male observation

% IN:
%  m(sex,c)       Data by sex, country
%  maleWt         Weight on male data
%  keepMale       1: Keep data with only male observations
%  keepNegative   1: Keep data < 0 as valid (except UNDEFINED)

% OUT:
%  mAvgV(1,c)

% -------------------------------------------------

global UNDEFINED c2S

if nargin ~= 5
   abort([ mfilename, ': Invalid nargin' ]);
end
if keepMale ~= 0  &  keepMale ~= 1
   abort([ mfilename, ': Invalid keepMale switch' ]);
end
if keepNegative ~= 0  &  keepNegative ~= 1
   abort([ mfilename, ': Invalid keepNegative switch' ]);
end

[nSex, nc] = size(m);
if nSex ~= 2
   abort([ mfilename, ': Invalid size m' ]);
end

% Mark negatives as invalid
if keepNegative ~= 1
   m( m < 0 ) = UNDEFINED;
end


mAvgV = UNDEFINED .* ones(1, nc);

% Find data with valid male and female observations
validV = find( m(c2S.male,:) ~= UNDEFINED  &  m(c2S.female,:) ~= UNDEFINED );
if length(validV) > 0
   mAvgV(validV) = maleWt .* m(c2S.male,validV) + (1-maleWt) .* m(c2S.female,validV);
end

% Keep valid male observations
if keepMale == 1
   validV = find( m(c2S.male,:) ~= UNDEFINED  &  m(c2S.female,:) == UNDEFINED );
   if length(validV) > 0
      mAvgV(validV) = m(c2S.male,validV);
   end
end

% ********  eof  ************
