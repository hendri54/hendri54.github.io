function invalidV = c2_filter_sex( sexV, fltS, dbg );
% Find invalid observations in variable sex
% IN:
%  sexV        Recoded PUMS variable sex
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

global c2S

if fltS.onlyMale == 1
   invalidV = find( sexV ~= c2S.male );
else
   invalidV = find( sexV ~= c2S.male  &  sexV ~= c2S.female );
end


% ********  eof  ***********
