function c2_show_school(year, filterNo, expNo, dbg);
% Show schooling figures from various sources

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  2-3-2001

% -------------------------------------------------

global pwtS bl2S c2S UNDEFINED

if nargin ~= 4
   abort([ mfilename, ': Invalid no of arguments' ]);
end

showPlots = 0;

male = c2S.male;
female = c2S.female;
cUSA = c2S.cUSA;

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;

% Load strings with country names
[cn, cnLen, cnMax] = cnames(c2S.pwtVer);

% Load average years of schooling
BLavgSchoolM = c2_bl_var_load_yr(bl2S.vAvgYrAll, year, filterNo, dbg);

% Mincer regression data by (country,sex,year)
mS = c2_mincer_load(year, [male, female], dbg);


% Fraction by (sex, skill, country)
skillFracM = load2( c2_class_fn(year, c2S.vSrcSkillWt, filterNo, dbg) );
[nSex, nSkill2, nc2] = size(skillFracM);

% Schooling of immigrants by (sex, country)
immSchoolAllM = load2( c2_class_fn(year, c2S.vImmSchoolSC, filterNo, dbg) );

% Position of immigrants in source country school distribution
% by (sex, skill, country)
% This may be loaded from a different filter (to match Barro-Lee)
immSchoolPosM = load2( c2_class_fn(year, c2S.vImmSchoolPos, fltS.fltImmSchoolPos, dbg) );
if ~isequal(size(immSchoolPosM), [nSex, nSkill, c2S.nCountries])
   warnmsg([ mfilename, ':  Invalid size of immSchoolPosM' ]);
end

% For comparison, load it again for this sample of immigrants
immSchoolPos2M = load2( c2_class_fn(year, c2S.vImmSchoolPos, filterNo, dbg) );



if 01
   disp(' ');
   disp('---------------- Schooling stats:   ----------------');

   nc = min([cols(BLavgSchoolM), cnMax, c2S.nCountries]);
   for sex = male
      if sex == male
         sexStr = 'Male';
      elseif sex == female
         sexStr = 'Female';
      else
         sexStr = 'Both sexes';
      end
      disp(' ');
      % Immigr Pos: Immigrant percentile pos in src country school distribution
      %     All: Sample with all immigrants
      %     Sample: This sample, filtered
      disp('Country              Avg Schooling        Immigr Pos   Immigr Pos  Skilled');
      disp('                     BL Mincer Immigr     All Sample   High skill  Fraction');

      for c = 1 : nc
         for skill = [1, nSkill]
            if immSchoolPosM(sex,skill,c) < 0
               immSchoolPosV(skill) = UNDEFINED;
            else
               immSchoolPosV(skill) = 100*(1-immSchoolPosM(sex,skill,c));
            end
            if immSchoolPos2M(sex,skill,c) < 0
               immSchoolPos2V(skill) = UNDEFINED;
            else
               immSchoolPos2V(skill) = 100*(1-immSchoolPos2M(sex,skill,c));
            end
         end
         if nSkill > 1  &  skillFracM(sex,nSkill,c) >= 0
            skillFrac = 100 * skillFracM(sex,nSkill,c) / sum( skillFracM(sex,:,c) );
         else
            skillFrac = UNDEFINED;
         end

         dataV = [BLavgSchoolM(sex,c), mS.avgSchoolM(c,sex), immSchoolAllM(sex,c), ...
            immSchoolPosV(1), immSchoolPos2V(1)];
         if nSkill > 1
            dataV = [dataV, immSchoolPosV(nSkill), immSchoolPos2V(nSkill), skillFrac];
         end
         if dataV(1) > 0  &  dataV(3) > 0
            disp([ sprintf('%15s  ', cn(c,1:15)), sprintf(' %6.1f', dataV) ]);
         end
      end
   end % for sex
end




%disp(mfilename);
%keyboard;


% *******  eof  *********
