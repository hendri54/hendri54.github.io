function c2_src_rel_earn(year, filterNo, dbg);
% Source country earnings by (sex,skill,country)
% Scaled so that earn(sex,1,country) = 1

% OUT:
%  srcRelEarnM(sex, skill, country)
%     Also avg of both sexes

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% -----------------------------------------------

global c2S UNDEFINED

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;
nSex = 2;
nC = c2S.nCountries;
male = c2S.male;
female = c2S.female;


if nSkill == 1
   % Nothing to do. Simply return a matrix of ones
   srcRelEarnM = ones(nSex, nSkill, nC);

else
   % Source country education weights by (sex, educ, c)
   sourceEducM = load2( c2_class_fn(year, c2S.vSourceEduc, filterNo, dbg) );

   % Load Mincer coefficients for nearest year by (sex, country)
   [cSchoolM, cExpM, cExpSqM] = c2_mincer_load_all(year, dbg);


   % ********  Loop over countries  ***********
   srcRelEarnM = UNDEFINED .* ones(nSex+1, nSkill, nC);
   for c = 1 : nC
      for sex = 1 : nSex
         % Source country weights
         wtV = squeeze(sourceEducM(sex,:,c));

         % Does country have data?
         if cSchoolM(sex,c) > 0  &  min(wtV) >= 0
            % Earnings by education class from Mincer regression
            % +++ should one also use experience figures?
            educEarnV = exp( cSchoolM(sex,c) .* fltS.educYearsV );

            % Compute earnings by skill from Mincer regression
            relEarnV = UNDEFINED .* ones(1, nSkill);
            for skill = 1 : nSkill
               % Which education classes belong to this skill?
               skillIdxV = fltS.skillIdxM(skill,1) : fltS.skillIdxM(skill,2);
               % Average earnings in this skill class
               relEarnV(skill) = sum(educEarnV(skillIdxV) .* wtV(skillIdxV)) ...
                  ./ sum(wtV(skillIdxV));
            end

            % Scale so that first skill class earns 1
            srcRelEarnM(sex,1:nSkill,c) = relEarnV ./ relEarnV(1);
         end
      end % for sex
   end
end


% Average over sexes
keepMale = 1;
keepNegative = 0;
for skill = 1 : nSkill
   srcRelEarnM(c2S.sexAll,skill,:) = c2_sex_avg( srcRelEarnM([c2S.male,c2S.female],skill,:), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
end


% ****  Save  *****

save2( srcRelEarnM, c2_class_fn(year, c2S.vSrcRelEarn, filterNo, dbg) );


% ******  Show  ******
if nSkill > 1  &  0
   global pwtS
   sex = c2S.male;
   RGDPWv = getvar(pwtS.rgdpwIdx, year, year, c2S.pwtVer, dbg);
   relRGDPWv = 100 .* RGDPWv ./ RGDPWv(pwtS.cUSA);

   skillPremV = squeeze(srcRelEarnM(sex,nSkill,:) ./ srcRelEarnM(sex,1,:));

   idxV = find( relRGDPWv > 0   &   squeeze(srcRelEarnM(sex,1,:)) > 0 );
   plot( relRGDPWv(idxV), skillPremV(idxV), 'bo' );
   title('Skill premium vs RGDPW');
   pause_print(0);

   disp(mfilename);
   keyboard;
end



% ***********  eof  **********
