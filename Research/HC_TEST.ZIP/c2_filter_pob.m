function invalidV = c2_filter_pob( xV, fltS, dbg );
% Find invalid observations in variable PLACE OF BIRTH
% IN:
%  xV          Recoded PUMS variable. These are PWT country numbers!
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

% Only drop missing observations
invalidV = find( xV <= 0 );


% ********  eof  ***********
