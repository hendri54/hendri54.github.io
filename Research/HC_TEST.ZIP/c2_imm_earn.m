function c2_imm_earn(year, filterNo, dbg)
% Compute various earnings concepts
% Earnings are computed from hourly wages times a standard
% number of hours per year that is common to all groups

% OUT:  Stored in variable files
%  relImmEarnM(sex, skill, c)
%     Earnings of immigrants relative to identical natives
%     where skill is the unskilled/skilled definition of c2_filter_settings
%     Also for both sexes
%  usEarnM(sex, skill, c)
%     US earnings of workers with source country skill composition
%     Uses IMMIGRANT skill prices (i.e. h(j) * eta(j))
%     Ratio of immEarnM/usEarnM is ratio of immigrant to source country h(j)
%     Also for both sexes
%  measSkillRatioM(sex, skill, c)
%     Ratio of h(j) for immigrants to source natives
%     Also for both sexes

%  Same by sex/country
%     measSkillRatioSC(sex, c)
%     usEarnSC
%     relImmEarnSC

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------

global c2S UNDEFINED

cUSA = c2S.cUSA;
male = c2S.male;
female = c2S.female;


% ******  Filter settings  *******
fltS = c2_filter_settings(filterNo, dbg);
% No of imperfectly substitutable skill types
nSkill = fltS.nSkill;
% Which education classes count as skilled/unskilled?
skillIdxM = fltS.skillIdxM;
% Weight assigned to males when averaging over sexes
maleWt = fltS.maleWt;



% ********  Load data  ************

wtM = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Valid no of obs by sex/c?
validSC = load2( c2_class_fn(year, c2S.vValidNobsSC, filterNo, dbg) );
% Per worker earnings. Computed from standard hours, if filter demands it
clEarnPerWkM = load2( c2_class_fn(year, c2S.clEarnPerWorker, filterNo, dbg) );

% Source country population weights
sourceWtM = load2( c2_class_fn(year, c2S.vSourceWt, filterNo, dbg) );

[n1, nSex, nAge, nS, nC] = size(wtM);

if n1 > 1
   abort([ mfilename, ':  Not implemented' ]);
end



% **********  Compute averages  ****************

% Ratio of measured skills: immigrants to src natives
measSkillRatioM = repmat( UNDEFINED, [nSex+1, nSkill, nC] );
% Earnings of immigrants relative to natives
relImmEarnM = repmat( UNDEFINED, [nSex+1, nSkill, nC] );
% Avg earnings of source country population at US prices
usEarnM = repmat( UNDEFINED, [nSex+1, nSkill, nC] );

% Same by sex/country
measSkillRatioSC = repmat( UNDEFINED, [nSex+1, nC] );
usEarnSC = repmat( UNDEFINED, [nSex+1, nC] );
relImmEarnSC = repmat( UNDEFINED, [nSex+1, nC] );

for c = 1 : nC
   for sex = 1 : nSex
      % Enough observations?
      if validSC(sex, c) == 1
         % The first skill index is all skills
         for skill = 0 : nSkill
            % Which education classes count for this skill?
            % How many observations are required
            if skill > 0
               skillIdxV = skillIdxM(skill,1) : skillIdxM(skill,2);
               minObs = fltS.minObsSS;
            else
               skillIdxV = 1 : nS;
               minObs = fltS.minObs;
            end

            % Weights for this (sex, skill, country)
            csWtM  = wtM(:,sex,:,skillIdxV,c);
            csWt   = sum( csWtM(:) );


            % *** Immigrant earnings relative to natives ***

            % Compute average immigrant earnings
            immEarn = clEarnPerWkM(:,sex,:,skillIdxV,c) .* csWtM;
            immEarn = sum(immEarn(:)) / csWt;

            % Compute average native earnings (using same weights)
            % Assumes that no blank observations exist for natives
            natEarn = clEarnPerWkM(:,sex,:,skillIdxV,cUSA) .* csWtM;
            if any( natEarn(:) <= 0  &  csWtM(:) > 0 )
               warnmsg([ mfilename, ':  Missing values in native earnings' ]);
               keyboard;
            end
            natEarn = sum(natEarn(:)) / csWt;

            % Relative immigrant earnings (eta)
            relImmEarn = immEarn / natEarn;
            if skill > 0
               relImmEarnM(sex, skill, c) = relImmEarn;
            else
               relImmEarnSC(sex, c) = relImmEarn;
            end


            % *** Source country earnings at US skill prices ***
            % Uses immigrant etas
            % Source country population distribution
            srcWtM = sourceWtM(:,sex,:,skillIdxV,c);
            % Are the data complete?
            if min(srcWtM(:)) >= 0
               % Aggregate earnings at US skill prices
               % This could fail if dim1 > 1 +++
               srcEarnM = clEarnPerWkM(:,sex,:,skillIdxV,cUSA) .* srcWtM;
               % Per capita earnings at US skill prices
               usEarn = sum(srcEarnM(:)) / sum(srcWtM(:));
               if any( srcEarnM(:) <= 0  &  srcWtM(:) > 0 )
                  warnmsg([ mfilename, ':  Missing values in source earnings' ]);
                  keyboard;
               end

               % Compute ratio of measured skills: immigrants vs src natives
               % Compute immigrant earnings exactly comparable to srcEarnM
               immEarn2 = clEarnPerWkM(:,sex,:,skillIdxV,cUSA) .* csWtM;
               if any( immEarn2(:) <= 0  &  csWtM(:) > 0 )
                  warnmsg([ mfilename, ':  Missing values in immEarn2' ]);
                  keyboard;
               end
               immEarn2 = sum(immEarn2(:)) / sum(csWtM(:));

               if skill > 0
                  measSkillRatioM(sex,skill,c) = immEarn2 / usEarn;
                  usEarnM(sex, skill, c) = usEarn;
               else
                  measSkillRatioSC(sex, c) = immEarn2 / usEarn;
                  usEarnSC(sex, c) = usEarn;
               end
            end % if
         end % for skill
      end % if valid
   end % for sex
end % for c



% ****  Average over sexes.  *****
% Use only one sex, if the other does not have data
keepMale = 1;
keepNegative = 0;

relImmEarnSC(c2S.sexAll,:) = c2_sex_avg( squeeze(relImmEarnSC(1:2,:)), ...
   fltS.maleWt, keepMale, keepNegative, dbg);
measSkillRatioSC(c2S.sexAll,:) = c2_sex_avg( squeeze(measSkillRatioSC(1:2,:)), ...
   fltS.maleWt, keepMale, keepNegative, dbg);
usEarnSC(c2S.sexAll,:) = c2_sex_avg( squeeze(usEarnSC(1:2,:)), ...
   fltS.maleWt, keepMale, keepNegative, dbg);

for skill = 1 : nSkill
   relImmEarnM(c2S.sexAll,skill,:) = c2_sex_avg( squeeze(relImmEarnM(1:2,skill,:)), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
   usEarnM(c2S.sexAll,skill,:) = c2_sex_avg( squeeze(usEarnM(1:2,skill,:)), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
   measSkillRatioM(c2S.sexAll,skill,:) = c2_sex_avg( squeeze(measSkillRatioM(1:2,skill,:)), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
end % for skill



% *******  Save  **********

save2( relImmEarnM,  c2_class_fn(year, c2S.vRelImmEarn,   filterNo, dbg) );
save2( usEarnM,      c2_class_fn(year, c2S.vUSSourceEarn, filterNo, dbg) );
save2( measSkillRatioM,  c2_class_fn(year, c2S.vMeasSkillRatio, filterNo, dbg) );

save2( relImmEarnSC,  c2_class_fn(year, c2S.vRelImmEarnSC,   filterNo, dbg) );
save2( usEarnSC,      c2_class_fn(year, c2S.vUSSourceEarnSC, filterNo, dbg) );
save2( measSkillRatioSC, c2_class_fn(year, c2S.vMeasSkillRatioSC, filterNo, dbg) );


disp('Saved relative immigrant earnings data.');


%disp(mfilename);
%keyboard;

% ***********  eof  ************
