function c2_industry_dist(year, filterNo, dbg);
% Show industry and occupation distribution of immigrants
% -------------------------------------------------------

global UNDEFINED c2S pwtS puS

% Load results or compute them (takes several minutes)
loadResults = 01;
% File to load from or save to
saveFn = [c2S.matDir, sprintf('ind_dist%04i_%03i', year, filterNo)];


% Load industry, occupation, birth place
wtV    = c2_pums_load(c2S.vWeight, year, filterNo, dbg);
bplV   = c2_pums_load(c2S.vBPL, year, filterNo, dbg);
occupV = c2_pums_load(c2S.vOccup, year, filterNo, dbg);
industryV = c2_pums_load(c2S.vIndustry, year, filterNo, dbg);

% Codes distinguished in my pums recode
nOcc = 14;
nInd = 20;


% Load rgdp per worker
rgdpwV = getvar(pwtS.rgdpwIdx, year, year, c2S.pwtVer, dbg)';
relGDPv = rgdpwV ./ rgdpwV(pwtS.cUSA);
relGDPv( rgdpwV <= 0 ) = UNDEFINED;
if length(relGDPv) < c2S.nCountries
   relGDPv = [relGDPv(:)', UNDEFINED .* ones(1, c2S.nCountries-length(relGDPv))];
end


% Assign one of 3 origin classes: poor, rich, native
poor = 1;
rich = 2;
native = 3;
no = 3;


if loadResults == 1
   saveS = load2( saveFn );
   indDistM = saveS.indDistM;
   occupDistM = saveS.occupDistM;


else
   % Assign origin classes
   originV = repmat( UNDEFINED, size(bplV) );
   for c = 1 : c2S.nCountries
      if relGDPv(c) > 0
         idxV = find( bplV == c );
         if length(idxV) > 10
            if c == c2S.cUSA
               originV(idxV) = native;
            elseif relGDPv(c) < 0.4
               originV(idxV) = poor;
            else
               originV(idxV) = rich;
            end
         end
      end
   end



   % ********  Calculate fraction in each industry / occupation by origin  ********

   % Total weight by origin
   originWtV = zeros(1, no);
   % Total weight in each occupation/origin class
   occupDistM = zeros(nOcc, no);
   indDistM   = zeros(nInd, no);

   for o = 1 : no
      idxV = find( originV == o );
      if length(idxV) < 10000
         warnmsg([ mfilename, ':  Few observations for origin' ]);
         keyboard;
      end

      cOccupV = occupV(idxV);
      cWtV = wtV(idxV);
      for occup = 1 : nOcc
         oIdxV = find( cOccupV == occup );
         if length(oIdxV) > 0
            % Weight in this occupation
            wt = sum(cWtV(oIdxV));
            occupDistM(occup, o) = wt;
         end
      end
      % Normalize so that weights sum to 1 for each origin
      occupDistM(:,o) = occupDistM(:,o) ./ sum(cWtV);


      cIndustryV = industryV(idxV);
      for ind = 1 : nInd
         oIdxV = find( cIndustryV == ind );
         if length(oIdxV) > 0
            % Weight in this industry
            wt = sum(cWtV(oIdxV));
            indDistM(ind, o) = wt;
         end
      end
      % Normalize so that weights sum to 1 for each origin
      indDistM(:,o) = indDistM(:,o) ./ sum(cWtV);
   end



   % *** Save ***

   saveS.indDistM = indDistM;
   saveS.occupDistM = occupDistM;
   save2( saveS, saveFn );
end



% *****  Show occupations  ********

disp(' ');
disp('----  Fraction in each occupation by origin  ----');
disp('Occ  Poor  Rich  Native');
for occup = 1 : nOcc
   disp([ sprintf(' %3i:  ', occup),  sprintf('  %6.1f', 100 .* occupDistM(occup,:)) ]);
end




% ********  Show industries  **********

indLen = min(15, size(puS.industryM, 2));

disp(' ');
disp('----  Fraction in each industry by origin  ----');
disp('Ind  Poor  Rich  Native');
for ind = 1 : nInd
   disp([ sprintf(' %3i  %15s ', ind, puS.industryM(ind,1:indLen)),  ...
      sprintf('  %6.1f', 100 .* indDistM(ind,:)) ]);
end



disp(mfilename);
keyboard;

% **********  eof  ********
