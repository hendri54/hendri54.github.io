% Initialize globals for migration data project
% ---------------------------------------------

% Directory with CPS data and programs
global sharedDir prodFctS c2S pwtS
addpath(sharedDir);


% ******   Frequently changed settings  ********

% Save figures to eps files for import into word?
c2S.saveFigures = 0;


% *******  Directories  *******
c2S.baseDir = 'c:\econ\migration\hc_test\';
% For program files
c2S.mDir = [c2S.baseDir, 'mfiles\'];
% For original data files (PUMS)
c2S.data2Dir = 'c:\data2\pums\hc_test\';
% For additional small data files
c2S.dataDir = [c2S.baseDir, 'data\'];
% For created matrix files
c2S.matDir = [c2S.baseDir, 'mat\'];
addpath(c2S.mDir);


% File with McGrattan/Schmitz K/Y figures (by PWT 5.6 number)
c2S.mcgrattan_ky_fn = [c2S.dataDir, 'mcgrattan_ky.txt'];

% Enable access to Hall/Jones 1999 data
go_hj99;

% Enable access to Deininger/Squire 1996 data
go_ds96;

% Enable access to Barro-Lee 2000 data
go_bl2;

% Enable PWT access
go_pwt;

% Enable PUMS data access
go_pums;

% Switch back to directory for this project
cd(c2S.mDir);



% **********  SETTINGS  ***************

c2S.censusYearV = [1980, 1990];  % Census years to use

c2S.pwtVer    = 5.6;            % Version of PWT to use
c2S.capShare  = 0.33;           % Capital share

[tmp,tmp,tmp, c2S.nCountries] = pwconst(c2S.pwtVer, 0);    % No of countries
c2S.cUSA = pwtS.cUSA;            % USA country number

% Sex codes
c2S.male   = 1;
c2S.female = 2;
c2S.sexAll = 3;

% Filter with all immigrants. For computation of age/sex distribution
% comparable to Barro-Lee 2000
c2S.fltAll = 50;


% Continent codes (created from mig_data.xls)
c2S.coAfrica         = 1;
c2S.coSouthAmerica   = 2;
c2S.coNorthAmerica   = 3;
c2S.coAsia           = 4;
c2S.coMiddleEast     = 5;
c2S.coEuropeWest     = 6;
c2S.coEuropeEast     = 7;
c2S.continentFn = [c2S.dataDir, 'continents.txt'];


% ********  VARIABLE NUMBERS  ************
% For PUMS variable files

c2S.vSex             = 1;
c2S.vAge             = 2;
c2S.vRace            = 3;
c2S.vGQ              = 4;
c2S.vBPL             = 5;
c2S.vHoursWk         = 6;     % Hours per week worked
c2S.vWeeksYr         = 7;     % Weeks per year
c2S.vEarnings        = 8;     % Annual earnings
c2S.vClassWkr        = 9;
c2S.vWeight          = 10;
c2S.vYrsSchool       = 11;
c2S.vYearsUSA        = 12;
c2S.vEnglish         = 13;
c2S.vOccup           = 14;
c2S.vIndustry        = 15;

% List of all PUMS variable numbers
c2S.pumsVarNoV = [1:2, 5 : 8, 10 : 15];



% ********  Additional (created) variables  **********

c2S.vCellCnt = 101;     % No of observations by (dim1, sex, age, educ, country)
% c2S.vLogEarn = 102;     % Log earnings
c2S.vClassInfo = 103;   % Structure with additional info about classified data
                        % See c2_classify for its contents
c2S.vRelImmEarn = 104;  % Relative immigrant earnings by [sex, skill, country]
                        % where skill matters only if imperfect substitutes

c2S.vImmSchool   = 109; % Avg school years by (sex, skill, country) for immigrants
c2S.vAcct        = 110; % Results from levels accounting. A structure with matrices.
c2S.vSourceEduc  = 111; % Source country population composition by education class
c2S.vSourceAge   = 112; % Source country population composition by age class
c2S.vArrivalAge  = 113;
c2S.vGenderGap   = 114; % Ratio of female to male avg earnings by country
c2S.vImmSchoolSC = 115; % Avg school years by (sex, country) for immigrants
c2S.vImmCntAll   = 116; % Total no of immigrants in US by (sex, country)
                        % No filtering. Used to compute fraction living in USA
c2S.vFracInUSA   = 117; % Fraction of source population living in USA

% Same variables by sex/country
c2S.vRelImmEarnSC = 118;


% *** Self-selection ***
% Self-selection factors s(c). Ratio of immigrant to source
% country unmeasured skills. By (sex,skill,country)
c2S.vSelfSelect  = 151;    % Assume that position in school distribution is the same
                           % as in earnings distribution
c2S.vSelfSelect2 = 152;    % Assume that h-ratio is same as s(c)

c2S.vImmSchoolPos= 153;       % Position of mean immigrant in src country school distribution
                              % by sex,skill,country
c2S.vMeasSkillRatio  = 154;   % Ratio of measured skills: immigrants/src natives
                              % Based on h(j). By (sex,skill,country)
c2S.vImmSchoolPosSC  = 155;   % Position of mean immigrant in src country school distribution
                              % by sex,country
c2S.vRelImmSrcEarn = 156;     % Ratio of source country earnings: immigrants/src natives
                              % Based on Mincer regression. By (sex, country)

% Same variables by sex/country
c2S.vMeasSkillRatioSC = 181;  % Ratio of measured skills: immigrants/src natives
                              % Based on h(j). By (sex,country)
c2S.vSelfSelect2SC    = 182;  % Same as vSelfSelect2, but by (sex,country)8


% *** Source country characteristics ***
c2S.vSourceSig   = 201;    % Source country std dev of log earnings
c2S.vQuintShares = 202;    % Source country quintile shares (implied by vSourceSig)
c2S.vQRatioDS    = 203;    % Source country quintile ratios (DS96)
c2S.vUSSourceEarn= 204;    % Avg earnings of workers with source country skill composition
c2S.vSourceEarn  = 205;    % Source country earnings per worker by sex,skill,country
c2S.vKY          = 206;    % K/Y for source countries. Interpolated where missing
c2S.vSourceWt    = 207;    % Fraction of source country workers by class
c2S.vSrcSkillWt  = 208;    % Fraction of source country workers by (sex,skill,c)
c2S.vSrcRelEarn  = 209;    % Relative source country earnings by (sex,skill,c)
                           % Levels are meaningless. srcRelEarn(sex,1,c)=1
c2S.vSourceEarnSC  = 210;  % Source country earnings by sex,country
c2S.vSrcSkillPrem  = 211;  % Source country skill premium. Earnings of nSkill / Earn of 1
c2S.vRelRGDPWv     = 215;  % RGDPW relative to USA

% Same variables by sex/country
c2S.vUSSourceEarnSC = 251;


% ***  Immigrant characteristics  ***
% All indexed by (sex, skill, country)
c2S.vHoursYr     = 301;    % Hours per year by (sex,skill,country)
c2S.vImmEarn     = 302;    % Avg immigrant earnings by (sex,skill,country)
c2S.vImmSkillFrac= 303;    % Fraction of workers in each skill class by (sex,skill,country)
c2S.vImmNobs     = 304;    % No of observations
%c2S.vValidNobs   = 305;    % Is no of observations >= required no? (by sex,skill,country)

% Same by sex/country
c2S.vImmNobsSC   = 354;
c2S.vValidNobsSC = 355;    % Is no of observations >= required no? (by sex,country)
                           % All skills have enough observ, if this is 1


% Variables indexed by (dim1,sex,age,ed,c)
c2S.clHourlyWage    = 501;    % Wage per hour
c2S.clEarnPerWorker = 502;    % Earnings per worker per year (may be computed from
                              % standard hours depending on filter)
c2S.clHoursYr       = 503;    % Hours worked per year (not per capita)


% *** eof ***
