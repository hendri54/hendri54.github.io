function [fPath, fn] = c2_acct_fn(year, filterNo, expNo, dbg);
% File name for a Matlab variable file. Contains a recoded
% PUMS ascii variable file. For immigrants and natives

% IN:
% ----------------------------------------------------

global c2S

if nargin ~= 4
   abort([ mfilename, ': Invalid no of arguments' ]);
end
v_check( year, 'i', [1,1], 1950, 2000 );

fn = sprintf('ac%04i_%03i_%03i.mat', year, filterNo, expNo);
fPath = [c2S.matDir, fn];

% **********  eof  ********
