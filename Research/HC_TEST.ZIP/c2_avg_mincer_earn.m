function mEarnM = c2_avg_mincer_earn(censusYearV, sexV, dbg);
% Compute average earnings by country/sex/year
% from Mincer regressions
% Measured in local currency units

% OUT:
%  mEarnM(pwtNo, sex, year index)
%     Missing values are undefined

% -----------------------------------------------

global UNDEFINED c2S

if c2S.male ~= 1  |  c2S.female ~= 2
   abort([ mfilename, ': Sex codes must match Mincer file' ]);
end


% Load variables by (pwtNo, sex, censusYear)
mS = c2_mincer_load(censusYearV, sexV, dbg);
[nc, nSex, nYear] = size(mS.schoolM);


% Avg earnings in local currency units
mEarnM = exp( mS.interceptM  +  mS.schoolM .* mS.avgSchoolM + ...
   mS.expM .* mS.avgExpM  +  mS.expSqM .* mS.avgExpM.^2 );


% Handle missing values
invalidM = (mS.schoolM < -1)  |  (mS.expM < -1)  |  ...
   (mS.expSqM < -1)  |  (mS.useM < 0.5)  |  (mS.avgSchoolM < 0)  | ...
   (mS.avgExpM < 0)  |  (mS.interceptM < -20);
disp(sprintf('No of valid Mincer observations:  %i',  sum(invalidM(:) == 0) ));

mEarnM(invalidM > 0.5) = UNDEFINED;


% ******  Self test  *******
if 0
   disp('Earnings for USA');
   disp(squeeze( mEarnM(c2S.cUSA,:,:) ));
end

%disp(mfilename);
%keyboard;

% ********  eof  ***********
