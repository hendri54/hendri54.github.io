function expS = c2_exp_settings(expNo, dbg);
% Experiment settings
% Nothing in here may affect sorting of observations into
% skill, age or education classes
% --------------------------------------------


% *****  Production function parameters  *******

expS.substElast = 1.67;    % Substitution elasticity between low/high skill


% ****  Self-selection  ****
% 'mincer': Rel immigrant earnings from source country Mincer regressions
% 'h':      h(j) ratio of immigrants to source country natives
%           WITHIN each skill class
% 'e':      US earnings ratio of immigrants to source country natives
%           Same for all skill classes

expS.selfSelectType = 'e';


% ---------------  INDIVIDUAL EXPERIMENTS  -------------------
if expNo == 2
   expS.selfSelectType = 'mincer';

elseif expNo == 10
   expS.substElast = 0.5;
elseif expNo == 11
   expS.substElast = 3;
elseif expNo == 12
   expS.substElast = 5;
elseif expNo == 13
   expS.substElast = 5;
   expS.selfSelectType = 'mincer';

elseif expNo == 15
   expS.substElast = 10;
   expS.selfSelectType = 'mincer';

%else
   % Default
end



% ********  eof  **********
