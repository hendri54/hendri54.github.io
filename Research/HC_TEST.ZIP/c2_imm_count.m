function c2_imm_count(year, dbg);
% Count number of immigrants.
% Compute fraction of source country population living in the USA

% OUT:
%  immCntM(sex, country)
%     Total no of immigrants in USA
%  fracInUSA(sex, country)
%     Fraction of source population in USA, by country

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% -----------------------------------------

global UNDEFINED c2S pwtS

if year == 1980
   fn = [c2S.dataDir, 'ImmigrCount1980.txt'];
elseif year == 1990
   fn = [c2S.dataDir, 'ImmigrCount1990.txt'];
else
   abort([ mfilename, ': Invalid year' ]);
end

% Load population size
popV = getvar(pwtS.pPopIdx, year,year, c2S.pwtVer, dbg);

% Load ascii file, indexed by PUMS birth place
m = dlmread(fn, '\t');
bplV = m(:,1);
disp(sprintf('Total no of immigrants:  %5.1f millions', ...
   sum(sum( m(:,2:3) )) / 1e6 ));


% Reindex by pwt number
pwtNoV = recode_pob_pu(year, bplV, dbg);


% ****  Count immigrants  *****

immCntM = zeros([2, c2S.nCountries]);
fracInUSAv = UNDEFINED .* ones([1, c2S.nCountries]);

% Loop over birth places
for i = 1 : length(pwtNoV)
   pwtNo = pwtNoV(i);
   if pwtNo > 0
      % There may be multiple entries. Add to the existing numbers
      immCntM(1:2,pwtNo) = immCntM(1:2,pwtNo) + m(i,2:3)';
      if popV(pwtNo) > 1
         fracInUSAv(pwtNo) = sum(immCntM(1:2,pwtNo)) / popV(pwtNo) / 1000;
      end
   end
end

% Mark invalid entries
immCntM( immCntM <= 0 ) = UNDEFINED;


% ****  Save  *****
save2( immCntM, c2_class_fn(year, c2S.vImmCntAll, 1, dbg) );
save2( fracInUSAv, c2_class_fn(year, c2S.vFracInUSA, 1, dbg) );


if 0
   disp(' ');
   disp('---- Fraction living in USA ----');
   disp(' ');
   disp('Country             Male    Female  Fraction');
   m = [immCntM', 100 .* fracInUSAv(:)];
   m( m <= 0 ) = UNDEFINED;
   formatStr = ['  %8.0f  %8.0f  %8.1f'];
   idxV = find( m(:,end) > 0 );
   show_table_pwt(m, formatStr, dbg);
end
%disp(mfilename);
%keyboard;


% **********  eof  ***********
