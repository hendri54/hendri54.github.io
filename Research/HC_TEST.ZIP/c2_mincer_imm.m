function c2_mincer_imm(year, filterNo, dbg);
% Compute average earnings by sex/country
% from source country Mincer regressions
% Immigrants relative to source country natives
% Use source country and immigrant population weights
% This is the ratio of measured skills of immigrants to source
% country natives, using source country relative prices.

% OUT:
%  relImmEarnM(sex, country)
%     Missing values are undefined
%     Also average over sexes

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% -----------------------------------------------

global UNDEFINED c2S

if c2S.male ~= 1  |  c2S.female ~= 2
   abort([ mfilename, ': Sex codes must match Mincer file' ]);
end
sexV = [c2S.male, c2S.female];

fltS = c2_filter_settings(filterNo, dbg);


% *****  Load Census Data  *********

% Load source country weights
sourceWtM = load2( c2_class_fn(year, c2S.vSourceWt, filterNo, dbg) );
% Weights by class
clWtM   = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Observation count by class
clCntM  = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );

[nDim1, nSex, nAge, nS, nc2] = size( clCntM );
if nDim1 > 1
   sourceWtM = sum( sourceWtM, 1 );
   clWtM  = sum( clWtM, 1 );
   clCntM = sum( clCntM, 1 );
end


% ********  Load Mincer data  ********
% by (sex, country)
[cSchoolM, cExpM, cExpSqM] = c2_mincer_load_all(year, dbg);




% **************  Loop over countries  ********************

relImmEarnM = repmat( UNDEFINED, [nSex, c2S.nCountries] );

% Mean years of schooling and experience by (age, education) class
yrsSchoolM = ones(nAge,1) * fltS.educYearsV;
yrsExpM    = fltS.ageYearsV(:) * ones(1, nS) - 6;

for c = 1 : c2S.nCountries
   for sex = 1 : nSex
      % Source country weights
      srcWtM = squeeze(sourceWtM(1,sex,:,:,c));
      % Immigrant weights
      immWtM = squeeze(clWtM(1,sex,:,:,c));
      % No of immigrant observations
      immCnt = sum_dim_lh( clCntM(1,sex,:,:,c), 0, dbg );

      % Do we have observations?
      if (cSchoolM(sex,c) > 0)  &  (min(srcWtM(:)) >= 0)  &  ...
         (min(immWtM(:)) >= 0)   & (immCnt >= fltS.minObsSex)

         % Mincer earnings by (age, education) class
         mEarnM = exp( cSchoolM(sex,c) .* yrsSchoolM + ...
            cExpM(sex,c) .* yrsExpM   +  cExpSqM(sex,c) .* yrsExpM.^2 );

         % Source earnings
         srcEarn = srcWtM .* mEarnM;
         srcEarn = sum(srcEarn(:)) ./ sum(srcWtM(:));

         % Immigrant earnings
         immEarn = immWtM .* mEarnM;
         immEarn = sum(immEarn(:)) ./ sum(immWtM(:));

         % Relative immigrant earnings
         relImmEarnM(sex, c) = immEarn / srcEarn;
      end % if
   end
end % for c

% Average over sexes
relImmEarnM(c2S.sexAll,:) = c2_sex_avg(relImmEarnM([c2S.male, c2S.female],:), ...
   fltS.maleWt, 1, 0, dbg);


% *****  Save  *****

save2( relImmEarnM, c2_class_fn(year, c2S.vRelImmSrcEarn,  filterNo, dbg) );


%disp(mfilename);
%keyboard;

% ********  eof  ***********
