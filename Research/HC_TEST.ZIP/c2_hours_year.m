function c2_hours_year(year, filterNo, dbg)
% Compute
% - mean hours per year by (sex, skill, country)


% Uses data sorted into classes by c2_classify

% OUT:  Stored in variable files
%  hoursYrM(sex, skill, c)
%     Mean hours worked per year per worker
%     Also for both sexes

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------

global c2S UNDEFINED

loadFn = c2_class_fn(year, c2S.clHoursYr, filterNo, dbg);
saveFn = c2_class_fn(year, c2S.vHoursYr, filterNo, dbg);
c2_avg_by_skill(loadFn, saveFn, year, filterNo, dbg);
disp('Saved hours per year data.');


% *** Self-test ***
hoursYrM = load2(saveFn);
idxV = find( hoursYrM > 0 );
hoursYrV = hoursYrM(idxV);
v_check( hoursYrV, 'f', UNDEFINED, 1000, 3000 );

%disp(mfilename);
%keyboard;

% ***********  eof  ************
