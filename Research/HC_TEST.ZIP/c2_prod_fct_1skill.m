function [MPL, MPK, Y] = c2_prod_fct_1skill(KY, L,  A, capShare, dbg);
% ----------------------------------------------------
% Production function with ONE skill class

% IN:
%  KY          Capital-output ratio (not capital input!)
%  L           Efficiency units of labor PER WORKER
%  A           Productivity level
%  capShare

% OUT:
%  MPK         marginal product of K
%  MPL         marginal product of L in efficiency units
%  Y           output per worker

% ----------------------------------------------------

global UNDEFINED

if nargin ~= 5
   abort([ mfilename, ': Invalid no of inputs' ]);
end


MPL = (1-capShare) .* A.^(1/(1-capShare)) .* KY.^(capShare/(1-capShare));

MPK = capShare ./ KY;

Y = MPL .* L ./ (1-capShare);


if dbg > 10
   sizeV = size(L);
   v_check( MPK,  'f', sizeV, 0, UNDEFINED );
   v_check( MPL,  'f', sizeV, 0, UNDEFINED );
   v_check( Y,    'f', sizeV, 0, UNDEFINED );
end


%disp(mfilename);
%keyboard;

% **********  eof  ***********
