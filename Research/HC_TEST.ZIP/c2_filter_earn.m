function invalidV = c2_filter_earn( xV, fltS, dbg );
% Find invalid observations in variable ANNUAL EARNINGS
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

invalidV = find( xV < fltS.minEarnYr );

% ********  eof  ***********
