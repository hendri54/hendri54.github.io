function c2_two_skill(elast, dbg);
% Calculations for a two skill extension
% IN:
%  elast       Substitution elasticity
%  dbg

% --------------------------------------

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:   3/1/01

% --------------------------------------

global UNDEFINED twoSkillS c2S

if nargin < 2
   abort([ mfilename, ': Invalid nargin' ]);
end
diaryFn = [c2S.dataDir, sprintf('TwoSkill_%2.1f', elast)];
diaryon(diaryFn);


% *****  CONSTANTS  ******
theta    = 0.33;
% Hc of US workers (high / low skill)
etaUS    = 1;
lambdaUS = 1;
% Relative hc of source country workers (high / low skill)
% This is the product of eta(s,c) * h(s,c) in new notation
etaC     = 0.6 * 0.75;     % was 0.7;
lambdaC  = etaC;
relY     = 1/20;
relKY    = 0.25;

% elast = 2.5;
zeta  = 1 - 1/elast;     % zeta = 0:  CD;  otherwise CES


twoSkillS.theta    = theta;
twoSkillS.etaUS    = etaUS;
twoSkillS.lambdaUS = lambdaUS;
twoSkillS.lambdaC  = lambdaC;
twoSkillS.etaC     = etaC;
twoSkillS.relY     = relY;
twoSkillS.relKY    = relKY;
twoSkillS.zeta     = zeta;



% *****  Values for rho, hUS to try
rhoV = [0.5, 0.75, 0.85, 0.95];
hUSv = [0.25, 0.5, 0.75, 0.85, 0.95, 0.98];

nRho = length(rhoV);
nHUS = length(hUSv);

hCM = UNDEFINED .* ones(nRho, nHUS);
spM = UNDEFINED .* ones(nRho, nHUS);
usSPM  = UNDEFINED .* ones(nRho, nHUS);
absSPM = UNDEFINED .* ones(nRho, nHUS);
earnShareM = UNDEFINED .* ones(nRho, nHUS);
earnShareUSM = UNDEFINED .* ones(nRho, nHUS);

optS = optimset('fzero');
optS = optimset(optS, 'Display', 'final');


% Loop over skilled labor weights
for r = 1 : nRho
   rho = rhoV(r);
   twoSkillS.rho = rho;
   % Loop over h(US)
   for h = 1 : nHUS
      twoSkillS.hUS = hUSv(h);
      hUS = hUSv(h);
      lUS = 1 - hUS;

      % Try the extreme values for hC
      hcLow = 1e-6;
      dev0 = c2_2skill_dev( log(hcLow) );
      dev1 = c2_2skill_dev( log(1) );

      if sign(dev0) ~= sign(dev1)
         guessV = log([hcLow, 1]);
         [soln, fVal, exitFlag] = fzero( 'c2_2skill_dev', guessV, optS );

         % Check solution
         dev = c2_2skill_dev(soln);
         if abs(dev) > 1e-4  |  exitFlag ~= 1
            % No solution
            disp(sprintf('Deviation: %f', dev ));

         else
            % Solution successful
            %hC = logistic(soln, 0, 1);
            hC = exp(soln);
            lC = 1 - hC;
            hCM(r, h) = hC;

            % Relative skill premium
            if zeta == 0
               relSP = lC/hC * hUS/lUS;
               earnShareM(r, h) = rho;
            else
               relSP = (lC/hC * hUS/lUS)^(1-zeta)  *  ...
                  (etaC / lambdaC * lambdaUS / etaUS)^zeta;
               earnShareM(r, h) = 1 / (1 + (1-rho)/rho * (lambdaC*lC / etaC/hC)^zeta);
               earnShareUSM(r, h) = 1 / (1 + (1-rho)/rho * (lambdaUS*lUS / etaUS/hUS)^zeta);
            end
            spM(r, h) = relSP;

            % Absolute skill premium
            absSPM(r, h) = (rho/(1-rho)) * (etaC/lambdaC)^zeta * (hC/lC)^(zeta-1);

            % Skill premium in US
            usSPM(r, h) = (rho/(1-rho)) * (etaUS/lambdaUS)^zeta * (hUS/lUS)^(zeta-1);
         end

      else
         warnmsg([ mfilename, ':  Solution does not exist' ]);
         disp(sprintf('  rho: %5.2f   hUS: %5.2f',  rho, hUS));
      end
   end % for h
end % for r


% ******  Show  *******

disp(' ');
disp(sprintf('Elasticity of subst: %6.3f', 1/(1-zeta)));

disp(' ');
disp('hC');
disp([ ' hUS:',   sprintf('  %8.3f',  hUSv)  ]);
for r = 1 : nRho
   disp([ sprintf('%5.2f', rhoV(r)),   sprintf('  %8.3f',  hCM(r,:))  ]);
end

if zeta ~= 1
   disp(' ');
   disp('Earnings share of hC');
   for r = 1 : nRho
      disp([ sprintf('%5.2f', rhoV(r)),   sprintf('  %8.3f',  earnShareM(r,:))  ]);
   end
end


disp(' ');
disp('Relative Skill premia');
for r = 1 : nRho
   disp([ sprintf('%5.2f', rhoV(r)),   sprintf('  %8.2f',  spM(r,:))  ]);
end


disp(' ');
disp('Absolute Skill premia');
for r = 1 : nRho
   disp([ sprintf('%5.2f', rhoV(r)),   sprintf('  %8.2f',  absSPM(r,:))  ]);
end


disp(' ');
disp('Absolute Skill premia in US');
for r = 1 : nRho
   disp([ sprintf('%5.2f', rhoV(r)),   sprintf('  %8.2f',  usSPM(r,:))  ]);
end

if zeta ~= 1
   disp(' ');
   disp('Earnings share of hC in US');
   for r = 1 : nRho
      disp([ sprintf('%5.2f', rhoV(r)),   sprintf('  %8.3f',  earnShareUSM(r,:))  ]);
   end
end

diary off;
%disp(mfilename);
%keyboard;


% *** eof ***
