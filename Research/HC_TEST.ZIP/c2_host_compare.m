function c2_host_compare(dbg);
% Compare host countries
% -------------------------------------

global pwtS UNDEFINED c2S


% Load RGDPW
year1 = 1960;
year2 = 1985;
rgdpwM = getvar(pwtS.rgdpwIdx, year1, year2, c2S.pwtVer, dbg);



% For each host country record:
%  - year of observation
%  - earnings of immigrants relative to natives
%    (not corrected for characteristics)

% Australia: Weighted average of relative wages of English and NonEnglish speaking
relAustralia = [314.39 * 1200 + 262.95 * 180] / 1380 / 301.90;

% Source       Smith 2001     Friedberg96  Venturini98   Winkelman00 Schmidt97
%  Venturini98  Begg/Chapman     Bloom/G.    Hayfron98
yearV       = [1995           1978          1993         1991     1986 ...
   1993         1980             1980         1980];
pwtNoV      = [pwtS.cDenmark  pwtS.cIsrael, pwtS.cItaly  pwtS.cNZ pwtS.cGermany ...
   pwtS.cItaly  pwtS.cAustralia  pwtS.cCanada pwtS.cNorway];
relImmEarnV = [0.98           0.93          0.87         1.1      0.8...
   1/1.153      relAustralia     19/20.4      exp(-0.076)];

% Reduce invalid years
yearV = min(yearV, year2);


n = length(yearV);
xV = zeros(1, n);
yV = zeros(1, n);
for i = 1 : n
   c = pwtNoV(i);
   xV(i) = rgdpwM(c, yearV(i)-year1+1) / rgdpwM(pwtS.cUSA, yearV(i)-year1+1);
   yV(i) = xV(i) * relImmEarnV(i);
end

%line45 = [min([xV, yV])+0.02,  max([xV, yV])-0.02];
line45 = [0.5, 0.95];
plot( xV, yV, 'bo',  line45, line45, 'k-' );
title('Immigrant earnings across host countries');
xlabel('RGDPW rel. to USA');
pause_print(0);


disp(mfilename);
keyboard;


% ********  eof   ********
