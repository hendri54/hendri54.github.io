function c2_avg_by_skill(loadFn, saveFn, year, filterNo, dbg)
% Compute per capita mean of variable by (sex, skill, country)
% Assumes that variable is stored in classes [dim1, sex, age, educ, c]
% as CLASS TOTALS, not as class per capita averages!

% IN:
%  loadFn      File to be loaded (with load2)
%  saveFn      File to be saved  (with save2)

% OUT:  Stored in variable file
%  varM(sex, skill, c)
%     Mean variable per worker
%     Also for both sexes

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------

global c2S UNDEFINED

if nargin ~= 5
   abort([ mfilename, ': Invalid nargin' ]);
end

cUSA = c2S.cUSA;
male = c2S.male;
female = c2S.female;


% ******  Filter settings  *******
fltS = c2_filter_settings(filterNo, dbg);

% No of imperfectly substitutable skill types
nSkill = fltS.nSkill;
% Which education classes count as skilled/unskilled?
skillIdxM = fltS.skillIdxM;
% Weight assigned to males when averaging over sexes
maleWt = fltS.maleWt;



% ********  Load data  ************

% Count in each cell.
cntM = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );
wtM = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Load the variable to be averaged
varM = load2( loadFn );

[n1, nSex, nAge, nS, nC] = size(wtM);
if ~isequal( size(varM), size(wtM) )
   warnmsg([ mfilename, ':  Size mismatch' ]);
   keyboard;
end



% **********  Compute averages  ****************

% Averages by sex, skill country
avgM = repmat( UNDEFINED, [nSex+1, nSkill, nC] );


for c = 1 : nC
   % No of observations for this country
   cCntM = cntM(:,:,:,:,c);
   cCnt = sum( cCntM(:) );

   % Enough observations?
   if cCnt >= fltS.minObs
      for sex = 1 : nSex
         for skill = 1 : nSkill
            skillIdxV = skillIdxM(skill,1) : skillIdxM(skill,2);

            % Weights for this (sex, skill, country)
            csWtM  = wtM(:,sex,:,skillIdxV,c);
            csWt   = sum( csWtM(:) );
            csCntM = cntM(:,sex,:,skillIdxV,c);

            % Enough observations?
            if sum(csCntM(:)) >= fltS.minObsSS  &  csWt > 0
               % *** Avg hours per year ***
               avg = varM(:,sex,:,skillIdxV,c);
               avgM(sex,skill,c) = sum(avg(:)) / csWt;
            end
         end % for skill
      end % for sex
   end  % if
end % for c



% ****  Average over sexes.  *****
% Use only one sex, if the other does not have data
keepMale = 1;
keepNegative = 0;

for skill = 1 : nSkill
   avgM(c2S.sexAll,skill,:) = c2_sex_avg( squeeze(avgM(1:2,skill,:)), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
end % for skill



% *******  Save  **********

save2( avgM, saveFn );


%disp(mfilename);
%keyboard;

% ***********  eof  ************
