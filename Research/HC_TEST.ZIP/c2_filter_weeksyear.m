function invalidV = c2_filter_weeksyear( xV, fltS, dbg );
% Find invalid observations in variable WEEKs WORKED per year
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

invalidV = find( xV < fltS.minWeeks  |  xV > fltS.maxWeeks );

% ********  eof  ***********
