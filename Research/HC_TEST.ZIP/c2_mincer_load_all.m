function [cSchoolM, cExpM, cExpSqM] = c2_mincer_load_all(year, dbg);
% Load Mincer coefficients from my sample and from Bils/Klenow
% Merge them
% Preference is given to my coefficients and to the year closest
% to the input YEAR
% But if a Mincer regression exists only for another year, it is used

% OUT:
%  cSchoolM, cExpM, cExpSqM(sex, country)
%     Mincer coefficients for schooling, experience, experience squared

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------------

global UNDEFINED c2S
nC = c2S.nCountries;
male = c2S.male;
female = c2S.female;
nSex = 2;


% Load Bils-Klenow Mincer coefficients
[bkSchoolV, bkExpV, bkExpSqV] = c2_bils_klenow_load;


% Load my Mincer coefficients
mS = c2_mincer_load(year, [male, female], dbg);
% Loaded matrix is by (country, sex, year)
% Transpose into (sex,country)
mSchoolM = mS.schoolM(:,:,1)';
mExpM    = mS.expM(:,:,1)';
mExpSqM  = mS.expSqM(:,:,1)';


% Load my Mincer coefficients for another year
if year == 1990
   year2 = 1980;
else
   year2 = 1990;
end
mS = c2_mincer_load(year2, [male, female], dbg);
% Loaded matrix is by (country, sex, year)
% Transpose into (sex,country)
mSchool2M = mS.schoolM(:,:,1)';
mExp2M    = mS.expM(:,:,1)';
mExpSq2M  = mS.expSqM(:,:,1)';


% Construct matrix of school/experience coefficients
cSchoolM = UNDEFINED .* ones(nSex, nC);
cExpM    = UNDEFINED .* ones(nSex, nC);
cExpSqM  = UNDEFINED .* ones(nSex, nC);

% Use my coefficients if available
cSchoolM(:, 1:cols(mSchoolM)) = mSchoolM;
cExpM(:, 1:cols(mSchoolM))    = mExpM;
cExpSqM(:, 1:cols(mSchoolM))  = mExpSqM;


% Count how each observation is constructed
cntM = zeros(nSex, 3);
cntM(male,1)   = sum( cSchoolM(male,:) > 0 );
cntM(female,1) = sum( cSchoolM(female,:) > 0 );
for c = 1 : nC
   for sex = 1 : nSex
      if cSchoolM(sex,c) <= 0
         if mSchool2M(sex,c) > 0
            % Use my coefficients for alternative year
            cSchoolM(sex,c) = mSchool2M(sex,c);
            cExpM(sex,c)    = mExp2M(sex,c);
            cExpSqM(sex,c)  = mExpSq2M(sex,c);
            cntM(sex,2)     = cntM(sex,2) + 1;
         elseif bkSchoolV(c) > 0  &  bkSchoolV(c) < 0.25
            % Use Bils-Klenow for both sexes if necessary      +++
            cSchoolM(sex,c) = bkSchoolV(c);
            cExpM(sex,c)    = bkExpV(c);
            cExpSqM(sex,c)  = bkExpSqV(c);
            cntM(sex,3)     = cntM(sex,3) + 1;
         end
      end
   end % for sex
end


if dbg > 10
   disp(' ');
   disp(mfilename);
   disp(sprintf('No of my Mincer observations: %2i, %2i   BK: %2i', cntM(male,:)));
   disp(sprintf('                   For women: %2i, %2i   BK: %2i', cntM(female,:)));
   v_check( cSchoolM, 'f', [nSex,nC], UNDEFINED, 0.3 );
   v_check( cExpM,    'f', [nSex,nC], UNDEFINED, 0.3 );
   v_check( cExpSqM,  'f', [nSex,nC], UNDEFINED, 0 );
end


% *********  eof  ***********
