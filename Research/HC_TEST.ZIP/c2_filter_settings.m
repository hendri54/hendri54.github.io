function fltS = c2_filter_settings(filterNo, dbg);
% Settings for particular filter

% Last checked:   10-9-98
% ---------------------------------------

global UNDEFINED c2S


% ****** DEFAULTS *******

%bplSetting  = 4;    % see c1_filter
%eduCl1      = 0;    % Keep education class 1 separate from 2?
dim1Type    = '0';   % How to determine first dimension of classification?
dim1Use     = 99;    % How many of the first dimension types to use?
onlyMale    = 0;     % Use only data for males?
fltS.posWeight = 1;  % Keep only person weight > 0
fltS.maleWt = 0.6;   % Weight assigned to males when averaging over sexes

fltS.stdHoursYr = 2100;    % No of hours per year used to compute annual earnings
fltS.useHourlyWage = 01;    % Use hourly wage or annual earnings?

% Age classes
ageMin = 20;
ageMax = 70;
dAge   = 5;          % Size of age class

fltS.arrivalAgeMin = 20;     % Earliest arrival age (ensures completed schooling)
fltS.arrivalAgeMax = 999;    % Latest arrival age
maxYrsUS = 99;          % Max no of years in US (for non-classified data)

% Earnings filters
fullTime = 1;     % Keep only full time workers?
hoursFt  = 30;    % Min hours/week for full time workers
weeksFt  = 40;    % Min weeks/year for full time workers
fltS.minHours = hoursFt;
fltS.minWeeks = weeksFt;
fltS.maxHours = 120;    % Max hours worked per week
fltS.maxWeeks = 53;     % Max weeks worked
fltS.minEarnYr = 500;  % Min earnings per year

% English language filter. Range of values to keep
fltS.EnglishMin = -9999;   % Even keep invalid entries
fltS.EnglishMax = 99;

% Min no of observations
nMax = 3500*1000;    % No of observations to keep at most. Should not bind
fltS.minObs = 150;   % No of observations requ to keep a country (not by sex)
fltS.minObsCell = 50;   % Min no of obs in a sex/age/educ cell required for
                        % natives. Impute others

% Education classes
educUpperV = [4, 8, 11, 12, 14, 999];
% Years of schooling assumed for each education class
educYearsV = [2.5, 6.5, 10, 12, 13, 17];

% Start age for Barro-Lee 2000
fltS.BLstartAge = 25;      % +++
% Upper bounds of school years associated with BL classes
fltS.blUpperV = [0  4 8  11 12  14 999];
% Avg years of schooling for BL classes
fltS.blYearsV = [0  2.5 6.5  10 12  13 17];

% Years in USA classes (if used)
fltS.yrsUSAUpperV = [10, 30, 50, 100];

% Arrival age classes (if used)
fltS.arrAgeUpperV = [10, 16, 22, 40, 110];

% Imperfect substitution of skilled/unskilled
fltS.nSkill = 1;           % Only one skill type
fltS.unskillMaxEduc = 3;   % Highest education CLASS that counts as unskilled


% Self-selection
% Which filter to use when computing immigrant position
% in source country skill distribution?
% fltS.fltImmSchoolPos = c2S.fltAll;
fltS.fltImmSchoolPos = filterNo;


% ***********  INDIVIDUAL CASES  ***************
if filterNo == 1
   disp('Default settings');

elseif filterNo == 2
   disp('Include part-time workers');
   fullTime = 0;
   fltS.minHours = 10;
   fltS.minWeeks = 10;

elseif filterNo == 3
   disp('Limit time since arrival');
   maxYrsUS = 10;    % Max no of years in US (for non-classified data)

elseif filterNo == 4
   disp('Earliest arrival age 24');
   fltS.arrivalAgeMin = 24;

elseif filterNo == 5
   disp('Earliest arrival age 0');
   fltS.arrivalAgeMin = 0;

elseif filterNo == 10
   disp('Good English skills only');
   fltS.EnglishMin = 0;
   fltS.EnglishMax = 2;

elseif filterNo == 30
   % Imperfect substitution of skilled/unskilled
   fltS.nSkill = 2;
   fltS.unskillMaxEduc = 3;   % Skilled = HS graduate

elseif filterNo == 31
   % Imperfect substitution of skilled/unskilled
   fltS.nSkill = 2;
   fltS.unskillMaxEduc = 4;   % Skilled = some college

elseif filterNo == 32
   % Imperfect substitution of skilled/unskilled
   fltS.nSkill = 2;
   fltS.unskillMaxEduc = 5;   % Skilled = college graduate

elseif filterNo == 50  |  filterNo == c2S.fltAll
   % This is for computing the source country weights only.
   % Essentially no filtering except age.
   % To be comparable with Barro-Lee 2000
   disp('All Immigrants');
   fltS.nSkill = 1;
   ageMin = 18;
   ageMax = 95;
   fullTime = 0;
   fltS.minEarnYr = 0;
   fltS.minHours = 0;
   fltS.minWeeks = 0;
   fltS.arrivalAgeMin = 0;

elseif filterNo == 900
   disp('Test case');
   % Do not set too low. Otherwise only natives are retained
   nMax = 100*1000;

else
   abort([ mfilename, ': Invalid filterNo' ]);
end



% ****************  Derived Variables  ***********************

% No of obs by sex required
fltS.minObsSex = max(75, fltS.minObs / 2);
% No of obs by sex/skill required
fltS.minObsSS = max(50, fltS.minObs / fltS.nSkill / 1.5);

% Make sure ageMin is consistent for natives and immigrants
ageMin = max(fltS.arrivalAgeMin, ageMin);

% Which education classes belong to each skill class?
nS = length(educUpperV);
if fltS.nSkill == 1
   fltS.skillIdxM = [1, nS];
elseif fltS.nSkill == 2
   fltS.skillIdxM = [1, fltS.unskillMaxEduc;  fltS.unskillMaxEduc+1, nS];
else
   abort([ mfilename, ': Invalid nSkill' ]);
end

% Age classes
ageMax = min(ageMax, 95);
% Upper bounds of age classes
fltS.ageUpperV = [ageMin-1+dAge : dAge : ageMax-dAge+1, ageMax];
% Mid points of age classes
fltS.ageYearsV = (fltS.ageUpperV + [ageMin, fltS.ageUpperV(1:end-1)]) ./ 2;



% ********  RETURN ARGUMENTS  **********

% Don't retain anyone younger than arrival age
ageMin = max(ageMin, fltS.arrivalAgeMin);


if fullTime == 1
   fltS.minHours = hoursFt;      % Min hours worked per week
   fltS.minWeeks = weeksFt;      % Min weeks worked per year
end
fltS.ageMin     = ageMin;
fltS.ageMax     = ageMax;
fltS.fullTime   = fullTime;
fltS.dim1Type   = dim1Type;
fltS.dim1Use    = dim1Use;
fltS.onlyMale   = onlyMale;
fltS.maxYrsUS   = maxYrsUS;

fltS.educUpperV = educUpperV;
fltS.educYearsV = educYearsV;
fltS.nMax = nMax;

if dbg > 5
   v_check( fltS.fullTime, 'i', [1,1], 0, 1 );
end


% *** eof ***
