function [fPath, fn] = c2_ascii_fn(year, varNo, immNat, dbg);
% File name for a PUMS ascii variable file created by
% Microanalyst

% IN:
%  immNat         'i': immigrant file; 'n': native file
% ----------------------------------------------------

global c2S

fn = [ sprintf('v%03i_%04i', varNo, year), immNat, '.txt' ];
fPath = [c2S.data2Dir, fn];

% **********  eof  ********
