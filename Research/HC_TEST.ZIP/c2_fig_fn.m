function fn = c2_fig_fn(figureNo, year, filterNo, expNo, dbg);
% File name for saving a figure
% -------------------------------------------------------

global c2S UNDEFINED

fn = [c2S.dataDir,  sprintf('fig%02i_%04i_%03i_%03i.eps', ...
   figureNo, year, filterNo, expNo) ];


% *********  eof  *********
