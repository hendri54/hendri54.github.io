function invalidV = c2_filter_class( classV, fltS, dbg );
% Find invalid observations in variable CLASS (worker)
% IN:
%  classV      Recoded PUMS variable CLASS
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

global c2S puS

if fltS.employeesOnly == 1
   invalidV = find( classV ~= puS.classEmployee );
else
   invalidV = find( classV < 0 );
end


% ********  eof  ***********
