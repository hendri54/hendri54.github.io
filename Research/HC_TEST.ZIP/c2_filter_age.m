function invalidV = c2_filter_age( xV, fltS, dbg );
% Find invalid observations in variable person AGE
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

invalidV = find( xV < fltS.ageMin  |  xV > fltS.ageMax );

% ********  eof  ***********
