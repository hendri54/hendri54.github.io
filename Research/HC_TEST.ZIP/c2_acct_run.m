function c2_acct_run(year, filterNo, expNo, dbg);
% Run levels accounting. Decompose output per
% worker into contributions of K/Y, A, hc

% Approach:
% - Estimate mean earnings per worker from US census data
% - Find TFP level that yields US earnings per worker
% - Compute earnings per worker from the production function
%   replacing one at a time:
%   - (K/Y) with source country level
%   - Population weights with source country weights
%   - Unmeasured hc with estimates from immigrant earnings
%   - Immigrant self-selection w.r.to unmeasured skills
% - The result: 4 levels of earnings per worker for each country
%   that decompose the difference between source country earnings per worker
%   and US earnings per worker into contributions of capital, human capital,
%   and TFP residual (decPerWkM)

% OUT:  Saved to file
%  decEarnPerWkM(level, sex, country)
%     Predicted earnings per worker, where levels are described above
%     not relative to USA
%     Also average for both sexes
%  decBySkillM(level, sex, skill, country)
%     Same decomposition by skill. Predicted earnings per worker
%     in each skill class (not per worker overall).
%     Identity:  decEarnPerWkM = sum( decBySkillM(1:nSkill) .* skillFracM(1:nSkill) )
%     Also average for both sexes

%  explainedM(level, sex, country)
%     Explained or predicted ratio source/US earnings per worker
%     Equals decEarnPerWkM(:,:,c) / decEarnPerWkM(:,:,cUSA)

%  explainedFracM(level, sex, country)
%     Explained fraction of ratio sourc/US earnings per worker

%  csValidM(sex,c)
%     Equals 1 for (sex,country) pairs with valid data

%  impliedSelectM(sex, skill, country)
%  impliedSelectSC(sex, country)
%     Degree of self-selection (earnings multiple) implied
%     by model with identical tfps. Comprises measured and unmeasured skills.
%     Also for avg of both sexes

%  selfSelectM(sex, skill, country)
%     Proxy for self-selection. s(c) factors.

%  immSrcPosM(sex, country)
%     Position of immigrants in source country earnings distribution
%     implied by impliedSelectM earnings factors. These account for observed
%     cc earnings differences
%     Also for avg of both sexes
%  modelScrPosM(sex, country)
%     Same object, but using s(c) factors implied by the model

%  LM(sex, skill, country)
%     Labor endowments in efficiency units
%     This is per worker in the population, not per worker in the skill class!

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ------------------------------------------

global UNDEFINED c2S pwtS

if nargin ~= 4
   abort([ mfilename, ': Invalid no of inputs' ]);
end

cUSA = c2S.cUSA;
male = c2S.male;
female = c2S.female;

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;

expS = c2_exp_settings(expNo, dbg);

% For averaging over sexes
keepMale = 1;
keepNegative = 0;
sexV = male : female;


% *******  Load data  *******

% Earnings by class (not per worker, but totals)
% clEarnM = load2( c2_class_fn(year, c2S.vEarnings, filterNo, dbg) );
% Weights by class
clWtM   = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Observation count by class
clCntM  = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );
% Earnings per worker. Adjusted for standard hours, if filter demands it
earnPerWkM = load2( c2_class_fn(year, c2S.clEarnPerWorker, filterNo, dbg) );


[nDim1, nSex, nAge, nS, nC] = size( clWtM );
if nDim1 > 1
   abort([ mfilename, ': Not implemented for nDim1 > 1' ]);
end
if nC ~= c2S.nCountries
   warnmsg([ mfilename, ':  Invalid nC' ]);
end


% K/Y
KYv = load2( c2_class_fn(year, c2S.vKY, filterNo, dbg) );

% Source country std dev of log earnings
stdDevLogEarnV = load2( c2_class_fn(year, c2S.vSourceSig,   filterNo, dbg) );


% Population composition in source countries
% by the same classes as clWtM
% Cannot have missing values! Otherwise entire country is dropped
sourceWtM = load2( c2_class_fn(year, c2S.vSourceWt, filterNo, dbg) );

% Population weights by skill level in source countries
skillFracM = load2( c2_class_fn(year, c2S.vSrcSkillWt, filterNo, dbg) );
if ~isequal( size(skillFracM), [nSex,nSkill,nC] )
   warnmsg([ mfilename, ':  Invalid size of skillFracM' ]);
   keyboard;
end

% Fraction of workers in each skill class. Immigrants. By sex/skill/c
immSkillFracM = load2( c2_class_fn(year, c2S.vImmSkillFrac,  filterNo, dbg) );

% Source country earnings per worker in the data
% by (sex, skill, country)
sourceEarnM  = load2( c2_class_fn(year, c2S.vSourceEarn, filterNo, dbg) );
sourceEarnSC = load2( c2_class_fn(year, c2S.vSourceEarnSC, filterNo, dbg) );
if ~isequal(size(sourceEarnM), [nSex+1,nSkill,nC])
   warnmsg([ mfilename, ':  Invalid sourceEarnM size' ]);
   keyboard;
end


% Ratio of measured skills: immigrants / src natives
measSkillRatioM  = load2( c2_class_fn(year, c2S.vMeasSkillRatio, filterNo, dbg) );
measSkillRatioSC = load2( c2_class_fn(year, c2S.vMeasSkillRatioSC, filterNo, dbg) );
if ~isequal(size(measSkillRatioM), [nSex+1,nSkill,nC])
   warnmsg([ mfilename, ':  Invalid measSkillRatioM size' ]);
   keyboard;
end



% Earnings of immigrants relative to US natives (by sex, country)
% Cannot have missing values! Otherwise entire country is dropped
relImmEarn2M = load2( c2_class_fn(year, c2S.vRelImmEarn, filterNo, dbg) );
if ~isequal( size(relImmEarn2M), [nSex+1, fltS.nSkill, nC] )
   warnmsg([ mfilename, ':  Invalid size of relImmEarn2M' ]);
   keyboard;
end

% Fill in values for all classes
% +++ one could construct those more directly
relImmEarnM = repmat(UNDEFINED, size(clWtM));
for c = 1 : nC
   for sex = 1 : nSex
      for skill = 1 : fltS.nSkill
         skillIdxV = fltS.skillIdxM(skill,1) : fltS.skillIdxM(skill,2);
         relImmEarnM(:,sex,:,skillIdxV,c) = relImmEarn2M(sex,skill,c);
      end
   end
end


% ********  Immigrant self-selection factors (the s(c))  *******
% Ratio of immigrant to source country native etas
if expS.selfSelectType(1) == 'h'
   selfSelectM = load2( c2_class_fn(year, c2S.vSelfSelect2, filterNo, dbg) );

elseif expS.selfSelectType(1) == 'e'
   ssM = load2( c2_class_fn(year, c2S.vSelfSelect2SC, filterNo, dbg) );
   % Same self-selection for all skills
   for skill = 1 : nSkill
      selfSelectM(:,skill,:) = ssM;
   end

elseif expS.selfSelectType(1) == 'm'
   % Self-selection based on source country mincer
   ssM = load2( c2_class_fn(year, c2S.vRelImmSrcEarn,  filterNo, dbg) );
   % Same self-selection for all skills
   for skill = 1 : nSkill
      selfSelectM(:,skill,:) = ssM;
   end

else
   abort([ mfilename, ': Invalid expS.selfSelectType' ]);
end
if ~isequal( size(selfSelectM), [nSex+1, fltS.nSkill, nC] )
   warnmsg([ mfilename, ':  Invalid size of selfSelectM' ]);
   keyboard;
end


% Find valid observations
validM = (earnPerWkM > 0)  &  (clWtM > 0)  &  (relImmEarnM > 0);

% Find valid country/sex combinations
csValidM = zeros(nSex, nC);
for c = 1 : nC
   for sex = 1 : nSex
      cntM  = clCntM(1,sex,:,:,c);
      sWtM  = sourceWtM(1,sex,:,:,c);
      relImmEarn = relImmEarnM(1,sex,:,:,c);
      if sum(cntM(:)) > fltS.minObsSex  &  KYv(c) > 0  ...
         &  min(sWtM(:)) >= 0  &  min(relImmEarn(:)) > 0  ...
         &  min(squeeze(selfSelectM(sex,:,c))) > 0
         csValidM(sex,c) = 1;
      end
   end
end





% ******  Labor endowments of source countries  ********
% This treats the US like another source country
LM = zeros(nSex, nSkill, nC);
% Labor endowments after adjusting for relative imm earnings
LAdjustM = zeros(nSex, nSkill, nC);
% Same after adjusting for immigrant self-selection
% Labor endowments after adjusting for relative imm earnings
LSelfSelectM = zeros(nSex, nSkill, nC);
for c = 1 : nC
   for sex = 1 : nSex
      if csValidM(sex,c) == 1
         % Total weight of all workers in (sex,country)
         csWt = sum_dim_lh( sourceWtM(:,sex,:,:,c), 0, dbg );

         for skill = 1 : nSkill
            % These education classes belong into current skill class
            skillIdxV = fltS.skillIdxM(skill,1) : fltS.skillIdxM(skill,2);
            % Fractions of workers by class
            wtM = sourceWtM(1,sex,:,skillIdxV,c);
            % Efficiency units by class from US workers (no missing values)
            effUnitM = earnPerWkM(1,sex,:,skillIdxV,cUSA) .* wtM;

            % Labor endowment. This is per worker in country, not in skill class!
            LM(sex,skill,c) = sum(effUnitM(:)) / csWt;
            % Adjusted for immigrant earnings
            effUnitM = effUnitM .* relImmEarnM(1,sex,:,skillIdxV,c);
            LAdjustM(sex,skill,c) = sum(effUnitM(:)) / csWt;
            % Adjust for self-selection
            LSelfSelectM(sex,skill,c) = LAdjustM(sex,skill,c) / selfSelectM(sex,skill,c);
         end
      end
   end
end



% *****  US earnings per worker for natives  *******

% Efficiency units of labor in US by sex PER WORKER
% (not per worker in skill class!)
usLM = UNDEFINED .* ones(nSex+1, nSkill);
% Native earnings per worker
usEarnPerWkV = UNDEFINED .* ones(1, nSex);
% Ratio of skilled/unskilled wage bill
usWageBillM  = UNDEFINED .* ones(nSex, nSkill);

for sex = 1 : nSex
   for skill = 1 : nSkill
      skillIdxV = fltS.skillIdxM(skill,1) : fltS.skillIdxM(skill,2);
      % For US the first dimension is always 1
      % Use earnPerWkM instead of class total earnings b/c hourly wages may be used
      earnM = earnPerWkM(1,sex,:,skillIdxV,cUSA) .* clWtM(1,sex,:,skillIdxV,cUSA);
      % Total wage bill of this skill class
      usWageBillM(sex,skill) = sum(earnM(:));

      % Use weights over all workers. Not just in this skill class!
      wtM = clWtM(1,sex,:,:,cUSA);
      usLM(sex,skill) = usWageBillM(sex,skill) / sum(wtM(:));
   end

   % Across skill classes
   wtM   = clWtM(1,sex,:,:,cUSA);
   earnM = earnPerWkM(1,sex,:,:,cUSA) .* wtM;
   usEarnPerWkV(sex) = sum(earnM(:)) / sum(wtM(:));
end

% Average over sexes
usLM(c2S.sexAll, :) = ...
   c2_sex_avg(usLM(sexV,:), fltS.maleWt, keepMale, keepNegative, dbg);



% *********  Calibrate production function to US data  ***********

% *** Calibrate skilled labor weight (rho) ***
for sex = 1 : nSex
   if nSkill == 1
      LSweightV(sex) = 0.5;      % Not used if there is only 1 skill
   else
      % Match wage bill ratio of skilled to unskilled labor
      wageBillRatio = usWageBillM(sex,2) / usWageBillM(sex,1);
      zeta  = 1 - 1 / expS.substElast;
      LSweightV(sex) = 1 / (1 + (usLM(sex,2) / usLM(sex,1))^zeta / wageBillRatio);

      % Check wage bill ratio computation
      [MPLv, MPK, Y, LshareV] = c2_prod_fct(KYv(cUSA), usLM(sex,:),  ...
         1, LSweightV(sex), c2S.capShare, expS.substElast, dbg);
      diff = (LshareV(2)/LshareV(1)) / wageBillRatio - 1;
      if abs(diff) > 1e-3
         warnmsg([ mfilename, ':  Invalid wage bill ratio' ]);
         keyboard;
      end
   end
end

disp(sprintf('  Skilled labor weight in production function:  %5.2f  %5.2f', ...
   LSweightV ));


% *** Calibrate Technology coefficients ***
usAv = zeros(1, nSex);

for sex = 1 : nSex
   % Compute earnings per worker with A=1
   [MPLv, MPK, Y] = c2_prod_fct(KYv(cUSA), usLM(sex,:),  ...
      1, LSweightV(sex), c2S.capShare, expS.substElast, dbg);
   earnPerWk = sum(MPLv .* usLM(sex,:));

   % Adjust A to match earnings per worker in the data
   usAv(sex) = (usEarnPerWkV(sex) / earnPerWk) ^ (1-c2S.capShare);

   % Check that the correct earnings per worker figure is recovered
   [MPLv, MPK, Y] = c2_prod_fct(KYv(cUSA), usLM(sex,:),  ...
      usAv(sex), LSweightV(sex), c2S.capShare, expS.substElast, dbg);
   earnPerWk = sum(MPLv .* usLM(sex,:));
   diff = max(abs( earnPerWk / usEarnPerWkV(sex) - 1 ));
   if diff > 1e-4
      warnmsg([ mfilename, ':  Invalid A computation.' ]);
      keyboard;
   end
end



% ************************  Earnings by country  *************************
% US decomposition does not return the same value for all levels
% Reason: Barro-Lee labor weights differ from my labor weights

nl = 4;
decEarnPerWkM = repmat(UNDEFINED, [nl, nSex+1, nC]);
immSrcPosM = UNDEFINED .* ones(nSex+1, nC);
modelSrcPosM = UNDEFINED .* ones(nSex+1, nC);
impliedSelectM = UNDEFINED .* ones(nSex+1, nSkill, nC);
% Same decomposition separated by skill
decBySkillM = repmat( UNDEFINED, [nl, nSex+1, nSkill, nC] );
% Same variables by sex/country
impliedSelectSC = repmat( UNDEFINED, [nSex+1, nC] );

for c = 1 : nC
   for sex = 1 : nSex
      if csValidM(sex,c) == 1

         % *****  Effect of K/Y  *******
         level = 1;
         % Fraction of workers with each skill for US natives
         skillFracV = squeeze(immSkillFracM(sex,:,cUSA));
         skillFracV = skillFracV ./ sum(skillFracV);
         % Labor input per worker in efficiency units
         % Each worker has Lv units the two skills
         % This is not per worker in each skill class!
         Lv = usLM(sex,:);
         [MPLv, MPK, Y] = c2_prod_fct(KYv(c), Lv, ...
            usAv(sex), LSweightV(sex), c2S.capShare, expS.substElast, dbg);
         % Predicted earnings per worker in each skill class
         decBySkillM(level, sex, 1:nSkill, c) = MPLv .* Lv ./ skillFracV;
         % Predicted earnings per worker
         decEarnPerWkM(level, sex, c) = sum( MPLv .* Lv );


         % *****  Effect of population weights  ******
         level = 2;
         skillFracV = squeeze(skillFracM(sex,:,c));
         skillFracV = skillFracV ./ sum(skillFracV);
         Lv = squeeze( LM(sex,:,c) );
         [MPLv, MPK, Y] = c2_prod_fct(KYv(c), Lv, ...
            usAv(sex), LSweightV(sex), c2S.capShare, expS.substElast, dbg);
         decBySkillM(level, sex, 1:nSkill, c) = MPLv .* Lv ./ skillFracV;
         decEarnPerWkM(level, sex, c) = sum( MPLv .* Lv );


         % *****  Unmeasured skill differences  ******
         level = 3;
         Lv = squeeze( LAdjustM(sex,:,c) );
         [MPLv, MPK, Y] = c2_prod_fct(KYv(c), Lv, ...
            usAv(sex), LSweightV(sex), c2S.capShare, expS.substElast, dbg);
         decBySkillM(level, sex, 1:nSkill, c) = MPLv .* Lv ./ skillFracV;
         decEarnPerWkM(level, sex, c) = sum( MPLv .* Lv );


         % ******  Self-selection  *****
         % Result is source country earnings per worker predicted by
         % model without technology differences
         level = 4;
         Lv = squeeze( LSelfSelectM(sex,:,c) );
         [MPLv, MPK, Y] = c2_prod_fct(KYv(c), Lv, ...
            usAv(sex), LSweightV(sex), c2S.capShare, expS.substElast, dbg);
         decBySkillM(level, sex, 1:nSkill, c) = MPLv .* Lv ./ skillFracV;
         decEarnPerWkM(level, sex, c) = sum( MPLv .* Lv );


         % *******  USA  *******
         % Make sure the same number is returned for all levels
         % It should be the same as measured earnings per worker
         if c == cUSA
            dist = decEarnPerWkM(1,sex,cUSA) / usEarnPerWkV(sex) - 1;
            if abs(dist) > 1e-4
               warnmsg([ mfilename, ':  Invalid decEarnPerWkM for USA' ]);
               keyboard;
            end
            decEarnPerWkM(:,sex,cUSA) = usEarnPerWkV(sex);
         end


         % Implied degree of self-selection that fully accounts for
         % cross-country earnings differences
         impliedSelectM(sex, 1:nSkill, c) = squeeze(decBySkillM(3, sex, 1:nSkill, c))' ./ ...
            sourceEarnM(sex, 1:nSkill, c) .* measSkillRatioM(sex,1:nSkill,c);
         impliedSelectSC(sex, c) = decEarnPerWkM(3, sex, c) / sourceEarnSC(sex, c) ...
            * measSkillRatioSC(sex,c);

         % Implied selection given s(c) factors
         scFactor = decEarnPerWkM(3, sex, c) / decEarnPerWkM(4, sex, c);
         modelSelectSC(sex, c) = measSkillRatioSC(sex, c) * scFactor;

         if stdDevLogEarnV(c) > 0
            % Immigrant position in the source country earnings distribution
            % Accounts for measured and unmeasured skills
            % Necessary SS to account fully for cc differences
            immSrcPosM(sex, c) = ...
               c2_distr_pos(impliedSelectSC(sex,c), stdDevLogEarnV(c), dbg);
            % SS implied by s(c) and measured skill ratio
            modelSrcPosM(sex, c) = ...
               c2_distr_pos(modelSelectSC(sex,c), stdDevLogEarnV(c), dbg);
         end
      end
   end % for sex


   % *** Average over sexes ***
   sex = c2S.sexAll;
   if csValidM(male,c) == 1  &  csValidM(female,c) == 1
      % Data for both sexes
      decBySkillM(:,sex,:,c) = fltS.maleWt .* decBySkillM(:,male,:,c) + ...
         (1-fltS.maleWt) .* decBySkillM(:,female,:,c);
      decEarnPerWkM(:,sex,c) = fltS.maleWt .* decEarnPerWkM(:,male,c) + ...
         (1-fltS.maleWt) .* decEarnPerWkM(:,female,c);
   elseif csValidM(male,c) == 1
      % Only male data. Use them.
      decBySkillM(:,sex,:,c) = decBySkillM(:,male,:,c);
      decEarnPerWkM(:,sex,c) = decEarnPerWkM(:,male,c);
   end
end


% ******  Average over sexes  ********
keepMale = 1;
keepNegative = 0;
sexV = male : female;
immSrcPosM(c2S.sexAll,:) = c2_sex_avg(immSrcPosM(sexV,:), ...
   fltS.maleWt, keepMale, keepNegative, dbg);
modelSrcPosM(c2S.sexAll,:) = c2_sex_avg(modelSrcPosM(sexV,:), ...
   fltS.maleWt, keepMale, keepNegative, dbg);
impliedSelectSC(c2S.sexAll,:) = c2_sex_avg(impliedSelectSC(sexV,:), ...
   fltS.maleWt, keepMale, keepNegative, dbg);
for skill = 1 : nSkill
   impliedSelectM(c2S.sexAll,skill,:) = c2_sex_avg(impliedSelectM(sexV,skill,:), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
end


% ********  Explained fractions  ***************
% What fraction of the Y/L gap is explained by each level?

% Explained ratio source/US earnings per worker
% = [predicted earnings for c] / [earnings for USA]
% For the US, measured = predicted earnings
cUSAv = cUSA.*ones(1,nC);
acctS.explainedM = ...
   m_divide( decEarnPerWkM, decEarnPerWkM(:,:,cUSAv), UNDEFINED, dbg );

% Actual ratio source/US earnings per worker by (sex/country)
% Use PWT for source countries and US
relSourceEarnSC = m_divide( sourceEarnSC, sourceEarnSC(:,cUSAv), UNDEFINED, dbg );

% Explained fraction by level
acctS.explainedFracM = repmat( UNDEFINED, [nl, nSex+1, nC] );
for l = 1 : nl
   for sex = [male, female, c2S.sexAll]
      idxV = find( squeeze(acctS.explainedM(l,sex,:))' > 0  &  ...
         relSourceEarnSC(sex,:) > 0   &  relSourceEarnSC(sex,:) < 1 );
      acctS.explainedFracM(l,sex,idxV) = log(1 ./ squeeze(acctS.explainedM(l,sex,idxV))') ...
         ./ log(1 ./ relSourceEarnSC(sex,idxV));

      % Check: Compute predicted earnings ratio c/USA
      ratioV = acctS.explainedM(l,sex,idxV) .^  (1./acctS.explainedFracM(l,sex,idxV));
      distV = ratioV(:)' ./ relSourceEarnSC(sex,idxV) - 1;
      if max(abs( distV )) > 1e-5
         warnmsg([ mfilename, ':  Invalid acctS.explainedFracM' ]);
         keyboard;
      end
   end
end




% *****  Save  ******

fn = c2_acct_fn(year, filterNo, expNo, dbg);
acctS.decEarnPerWkM = decEarnPerWkM;
acctS.decBySkillM   = decBySkillM;
% acctS.usEarnPerWkM  = usEarnPerWkM;
acctS.csValidM      = csValidM;
acctS.impliedSelectM = impliedSelectM;
acctS.impliedSelectSC = impliedSelectSC;
acctS.immSrcPosM = immSrcPosM;
acctS.modelSrcPosM = modelSrcPosM;
acctS.selfSelectM  = selfSelectM;
acctS.LM = LM;
save2( acctS, fn );


% ***********  SHOW  **************
if 0
   disp(' ');
   disp('-------  c2_acct_run  ----------');
   disp(' ');
   disp('PwtNo   Measured Skill     Labor');
   disp('        All   Sk.1  Sk.N   Sk.1  Sk.N');

   sex = c2S.male;
   cV = 30 : 90;
   for c = cV
      if decEarnPerWkM(2,sex,c) > 0
         measSkillV = squeeze(decBySkillM(2,sex,:,c) ./ decBySkillM(1,sex,:,c));
         dataV = [c, decEarnPerWkM(2,sex,c)/decEarnPerWkM(1,sex,c), measSkillV(1), ...
            measSkillV(end), LM(sex,1,c), LM(sex,nSkill,c)];
         disp(sprintf('%4i  %5.2f  %5.2f %5.2f  %6.0f %6.0f', dataV));
      end
   end
end

%disp(mfilename);
%keyboard;


% *********  eof  ***********
