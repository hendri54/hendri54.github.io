function c2_earn_per_worker(year, filterNo, dbg);
% Compute earnings per worker and hourly wages
% If filter uses hourly wages, then earnings per worker
% are computed from (hourly wage) * (standard hours)
% Outputs are indexed by (dim1, sex, age, ed, c)

% Also computes c2S.vImmEarn: Immigrant earnings per worker
%  by sex/skill/country.
% ---------------------------------------------------

global UNDEFINED c2S


fltS = c2_filter_settings(filterNo, dbg);


% ********  Load data  ************

wtM = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Earnings: Total in each cell. Not per capita. Annual
earnM = load2( c2_class_fn(year, c2S.vEarnings, filterNo, dbg) );
% Hours per year. Not per capita
hoursYrM = load2( c2_class_fn(year, c2S.clHoursYr, filterNo, dbg) );

% Set invalid observations to zero (this should be redundant)
validM = (earnM > 0  &  wtM > 0  &  hoursYrM > 0);


% Mean wage per hour
hourlyWageM = earnM ./ max(1, hoursYrM);
hourlyWageM = hourlyWageM .* validM;


if fltS.useHourlyWage == 1
   % Per capita earnings with standard hours
   perCapEarnM = hourlyWageM .* fltS.stdHoursYr;
else
   % Mean per capita earnings by class using actual hours
   perCapEarnM = earnM ./ max(1e-4, wtM);
end
perCapEarnM = perCapEarnM .* validM;



% *** Save ***
save2( perCapEarnM, c2_class_fn(year, c2S.clEarnPerWorker, filterNo, dbg) );
save2( hourlyWageM, c2_class_fn(year, c2S.clHourlyWage,    filterNo, dbg) );


% *** Immigrant earnings per worker by sex/skill/country ***

loadFn = c2_class_fn(year, c2S.clEarnPerWorker, filterNo, dbg);
saveFn = c2_class_fn(year, c2S.vImmEarn, filterNo, dbg);
c2_avg_by_skill(loadFn, saveFn, year, filterNo, dbg)


%disp(mfilename);
%keyboard;


% ************   eof   *************
