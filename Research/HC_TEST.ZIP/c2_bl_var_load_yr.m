function blM = c2_bl_var_load_yr(blVarNo, year, filterNo, dbg);
% Load a Barro-Lee 2000 variable for one year
% Return the result matrix by (sex, country)
% Include average over sexes
% Append undefined data, if no of countries less than c2S.nCountries
% --------------------------------------------------------------------

global UNDEFINED c2S bl2S
male = c2S.male;
female = c2S.female;

fltS = c2_filter_settings(filterNo, dbg);

% Load variable matrix indexed by (pwt country, sex)
[loadM, success] = var_load_yr_bl2(blVarNo, year, fltS.BLstartAge, 1, dbg);

% Transpose into (sex, country)
blM(male,:)   = loadM(:, bl2S.sexMale)';
blM(female,:) = loadM(:, bl2S.sexFemale)';

% Average over sexes
blM(c2S.sexAll,:) = c2_sex_avg(blM(male:female,:), fltS.maleWt, 0, 0, dbg);

% Append countries, if BL has fewer countries than I need
if cols(blM) < c2S.nCountries
   blM(:, cols(blM)+1 : c2S.nCountries) = UNDEFINED;
end


% **********   eof   ***********
