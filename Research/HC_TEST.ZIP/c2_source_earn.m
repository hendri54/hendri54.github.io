function c2_source_earn(year, filterNo, dbg);
% Compute earnings per worker for source countries

% OUT:
%  All Include male/female average
%  sourceEarnM(sex, skill, pwtNo)
%  sourceEarnSC(sex, pwtNo)
%  skillPremM(sex, pwtNo)
%     Ratio of earnings of nSkill vs skill=1 workers

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ------------------------------------------------

global c2S UNDEFINED pwtS

fltS = c2_filter_settings(filterNo, dbg);
nC   = c2S.nCountries;
nSex = 2;
nSkill = fltS.nSkill;
male = c2S.male;
female = c2S.female;

% Load output per worker
rgdpwV = getvar(pwtS.rgdpwIdx, year,year, c2S.pwtVer, dbg);
if length(rgdpwV) < nC
   rgdpwV(end+1 : nC) = UNDEFINED;
end
rgdpwV = rgdpwV(:)';

% Load K/Y
kyV = load2( c2_class_fn(year, c2S.vKY, filterNo, dbg) );
kyV = kyV(:)';

% Load ratio of female/male earnings in source countries
genderRatioV = load2( c2_class_fn(year, c2S.vGenderGap, filterNo, dbg) );
genderRatioV = genderRatioV(:)';

% Load skill premium from Mincer regressions (earnings relative to skill 1)
% by sex, skill, country
skillEarnM = load2( c2_class_fn(year, c2S.vSrcRelEarn, filterNo, dbg) );

% Load fraction of workers by skill class (by sex, skill, country)
skillFracM = load2( c2_class_fn(year, c2S.vSrcSkillWt, filterNo, dbg) );



% ********  Avg earnings per worker in each country  **********

% Find countries with data
validV = find( kyV > 0  &  rgdpwV > 0   &  genderRatioV > 0);


if 1
   % Same capital share for all countries
   capShareV = c2S.capShare .* ones(1, nC);
else
   % Find the MPK consistent with US data
   MPK = c2S.capShare / kyV(pwtS.cUSA);
   % Find the capital shares for all countries
   capShareV = UNDEFINED .* ones(1, nC);
   capShareV(validV) = MPK .* kyV(validV);
end

% Earnings per worker
sourceEarnV = UNDEFINED .* ones(1, c2S.nCountries);
sourceEarnV(validV) = rgdpwV(validV) .* (1-capShareV(validV));


% Mean earnings by sex, country
sourceEarnSC = UNDEFINED .* ones(nSex+1, c2S.nCountries);
sourceEarnSC(c2S.male, validV) = sourceEarnV(validV) ./ ...
   (fltS.maleWt + genderRatioV(validV) .* (1-fltS.maleWt));
sourceEarnSC(c2S.female, validV) = genderRatioV(validV) .* sourceEarnSC(c2S.male, validV);
sourceEarnSC(c2S.sexAll, validV) = sourceEarnV(validV);



% **********  Avg earnings by sex,skill,country  ******************

sourceEarnM = repmat( UNDEFINED, [nSex+1, nSkill, nC] );
% Skill premia
skillPremM  = repmat( UNDEFINED, [nSex+1, nC] );

for c = 1 : nC
   for sex = 1 : nSex
      fracV = squeeze( skillFracM(sex,1:nSkill,c) );
      % Relative earnings of skills
      relEarnV = squeeze( skillEarnM(sex,1:nSkill,c) );
      if min(fracV) >= 0  &  min(relEarnV) > 0  &  sourceEarnSC(sex,c) > 0
         % Fraction of each skill type
         fracV = fracV ./ sum(fracV);
         % Mean source country earnings before scaling
         srcEarn = sum(fracV .* relEarnV);
         % Scale factor to match source country earnings
         scaleFactor = sourceEarnSC(sex,c) / srcEarn;
         sourceEarnM(sex,:,c) = relEarnV .* scaleFactor;
         % Skill premia
         skillPremM(sex,c) = relEarnV(nSkill) / relEarnV(1);
      end
   end % for sex
end


% Average over sexes
keepMale = 1;
keepNegative = 0;
skillPremM(c2S.sexAll,:) = c2_sex_avg(skillPremM([c2S.male, c2S.female],:), ...
   fltS.maleWt, keepMale, keepNegative, dbg);
for skill = 1 : nSkill
   sourceEarnM(c2S.sexAll,skill,:) = c2_sex_avg(sourceEarnM([c2S.male, c2S.female],skill,:), ...
      fltS.maleWt, keepMale, keepNegative, dbg);
end


% Save
save2( sourceEarnM, c2_class_fn(year, c2S.vSourceEarn, filterNo, dbg) );
save2( sourceEarnSC,    c2_class_fn(year, c2S.vSourceEarnSC, filterNo, dbg) );
save2( skillPremM,  c2_class_fn(year, c2S.vSrcSkillPrem, filterNo, dbg) );


% ******  SELF-TEST  ********
if dbg > 10
   % Check that male/female earnings have correct average
   avgEarnV = fltS.maleWt .* sourceEarnSC(c2S.male, :) + ...
      (1-fltS.maleWt) .* sourceEarnSC(c2S.female, :);
   if max(abs( avgEarnV ./ sourceEarnV - 1 )) > 1e-4
      warnmsg([ mfilename, ':  Invalid sourceEarnSC' ]);
      keyboard;
   end


   % Check that averages of source country earnings match
   cIdxV = find( sourceEarnM(1,1,c) > 0 );
   for c = cIdxV
      % Fraction by sex,skill
      fracM = skillFracM(:,:,c);
      % Population weights by sex,skill
      wtM = [fltS.maleWt .* fracM(male,:) ./ sum(fracM(male,:)); ...
             (1-fltS.maleWt) .* fracM(female,:) ./ sum(fracM(female,:))];
      % Mean source country earnings
      sourceEarn = sourceEarnM(:,:,c) .* wtM;
      sourceEarn = sum( sourceEarn(:) );
      % Check against target
      dist = (sourceEarn / sourceEarnV(c) - 1);
      if abs(dist) > 1e-3
         warnmsg([ mfilename, ':  Invalid sourceEarn' ]);
         keyboard;
      end
   end
end


% ******  Show  ********
if 0
   disp(' ');
   disp('Country  Y/L   AvgEarn  capShare');
   for c = validV(:)'
      dataV = [c, rgdpwV(c)/rgdpwV(pwtS.cUSA)*100,  ...
         sourceEarnV(c)/sourceEarnV(pwtS.cUSA)*100,  capShareV(c)];
      disp(sprintf(' %3i   %5.1f   %5.1f   %5.2f', dataV ));
   end

   lineV = [0.02  0.98];  % [min(rgdpwV(validV)), max(rgdpwV(validV))];
   plot( rgdpwV(validV)./rgdpwV(pwtS.cUSA), sourceEarnSC(male,validV)./sourceEarnSC(male,pwtS.cUSA), 'bo', ...
      rgdpwV(validV)./rgdpwV(pwtS.cUSA), sourceEarnSC(female,validV)./sourceEarnSC(female,pwtS.cUSA), 'ro', ...
      lineV, lineV, 'k-' );
   title('Source country earnings vs RGDPW');
   legend('Male', 'Female', 'Line');
   pause_print(0);


   %plot( rgdpwV(validV)./rgdpwV(pwtS.cUSA), capShareV(validV), 'bo' );
   %title('Capital share vs RGDPW');
   %pause_print(0);
end

%disp(mfilename);
%keyboard;


% **********  eof  ***********
