function invalidV = c2_filter_hoursweek( xV, fltS, dbg );
% Find invalid observations in variable HOURS PER WEEK WORKED
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

invalidV = find( xV < fltS.minHours  |  xV > fltS.maxHours );

% ********  eof  ***********
