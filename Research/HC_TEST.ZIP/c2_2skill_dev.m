function dev = c2_2skill_dev(guessV);
% Deviations for 2 skill model
% --------------------------------------

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:   11-6-98

% --------------------------------------

global UNDEFINED  twoSkillS
lambdaUS = twoSkillS.lambdaUS;
etaUS   = twoSkillS.etaUS;
hUS     = twoSkillS.hUS;
lUS     = 1 - hUS;
lambdaC = twoSkillS.lambdaC;
theta   = twoSkillS.theta;
rho     = twoSkillS.rho;
zeta    = twoSkillS.zeta;

%hC = logistic(guessV, 0, 1);
hC = min(0.9999, exp(guessV));
lC = 1 - hC;


if zeta == 0
   % etaC implied by guess;   Cobb Douglas

   term1 = (twoSkillS.relY / twoSkillS.relKY^(theta/(1-theta))) ^ (1/rho);
   term2 = etaUS * hUS / hC  *  (lambdaC * lC / lambdaUS / lUS) ^ (1-1/rho);
   etaC = term1 * term2;

   dev = etaC / twoSkillS.etaC - 1;

else
   %  CES
   term1 = (twoSkillS.relY / twoSkillS.relKY^(theta/(1-theta))) ^ zeta;
   term2 = rho * (etaUS * hUS)^zeta  +  (1-rho) * (lambdaUS * lUS)^zeta;
   RHS = term1 * term2;

   LHS = rho * (twoSkillS.etaC * hC)^zeta  +  (1-rho) * (lambdaC * lC)^zeta;
   dev = LHS / RHS - 1;
end

%keyboard

% *** eof ***
