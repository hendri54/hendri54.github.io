function [dev, qShareV] = c2_qshare_dev(logSig, qShareTgV);
% Deviation from target quintile shares
% Given a log-normal RV with mean 0 and std dev exp(logSig)

% IN:
%  logSig      ln(sig)
%  qShareTgV = Quintile share targets

% OUT:
%  dev         Deviation from quintile ratio
%  qShareV     Quintile shares implied by sig

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------

mu = 0;
% Std dev of log earnings
sig = exp(logSig);

% Compute quintile shares from log-normal
qShareV = c2_logn_quint(mu, sig);

% Quintile ratio
qRatio = qShareV(end) / qShareV(1);

% Quintile ratio target
qRatioTg = qShareTgV(end) / qShareTgV(1);

dev = qRatio / qRatioTg - 1;


% **********  eof  ***********
