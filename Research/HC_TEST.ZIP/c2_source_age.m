function c2_source_age(year, filterNo, dbg);
% Calculate age distribution for source countries

% OUT:
%  sourceAgeM(sex,ageClass,country)
%     Fraction of population in each class

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% -------------------------------------------------

global UNDEFINED c2S pwtS

male = c2S.male;
female = c2S.female;

fltS = c2_filter_settings(filterNo, dbg);
ageUpperV = fltS.ageUpperV;
na = length(ageUpperV);

% RGDPW
rgdpwV = getvar(pwtS.rgdpwIdx, year,year, c2S.pwtVer, dbg);
rgdpwV = rgdpwV(:)';
nc = length(rgdpwV);


% ******  Load population composition  *******
% Text file created from IDB data spreadsheet
fn = [c2S.dataDir, 'age_compos.txt'];
m = dlmread(fn, '\t');

% ***  Which age classes to keep?  ***
% Upper bounds of age classes. The first entry is invalid
ageUbV = m(1, 2:end);
% The retained classes must contain the interval ageMin:ageMax
classN = find( ageUbV > fltS.ageMax );
classV = 1 : classN(1);
% Upper bounds of age classes
ageUbV = ageUbV(classV);


% Country numbers
pwtNoV  = m(2 : 2: end-1, 1);
nc = min(nc, max(pwtNoV));


% *** Construct population matrix by age/country/sex ***
% For countries with data

% Data by (sex, age class, country ROW)
dataM(female, :, :) = m(3 : 2: end,   classV+1)';
dataM(male, :, :)   = m(2 : 2: end-1, classV+1)';

nSex = 2;
popM = repmat( UNDEFINED, [nSex, length(ageUbV), nc] );
hasPopDataM = zeros(nSex, nc);

for c = 1 : size(dataM,3)
   for sex = [male, female]
      if pwtNoV(c) > 0
         pwtNo = pwtNoV(c);
         dataV = squeeze(dataM(sex,:,c))';
         % If only the last cell is missing, interpolate
         % Assume that those in top class are 40pct
         if dataV(end) < 0  &  dataV(end-1) > 0
            dataV(end) = dataV(end-1) * 0.4;
            dataV(end-1) = dataV(end-1) * 0.6;
         end
         if min(dataV) >= 0
            popM(sex, :, pwtNo) = dataV ./ sum(dataV);
            hasPopDataM(sex,pwtNo) = 1;
         end
      end
   end % for sex
end


% Which countries have population and gdp data?
hasDataM = zeros(nSex, nc);
for sex = 1 : nSex
   idxV = find( hasPopDataM(sex,1:nc) == 1   &   rgdpwV(1:nc) > 0 );
   hasDataM(sex, idxV) = 1;
end


% Continents
continentV = load( c2S.continentFn )';
continentV = continentV(1:nc);




% *************  Loop over countries with data  **************

sourceAgeM = UNDEFINED .* ones(nSex, na, c2S.nCountries);

for c = 1 : nc
   for sex = [male, female]
      if hasPopDataM(sex, c) == 1
         % Construct cdf of population structure in data
         cdfV = cumsum( popM(sex,:,c) );
         cdfV = cdfV ./ cdfV(end);

         % Interpolate for my age classes
         cumFracV = interp1( ageUbV, cdfV, [fltS.ageMin, ageUpperV], 'linear' );

         % Mass in each class
         fracV = cumFracV(2:end) - cumFracV(1:end-1);
         sourceAgeM(sex, :, c) = fracV ./ sum(fracV);
      end
   end
end


% ********  Loop over countries without data  **********

imputeCntV = [0 0];  % No imputed by sex

for c = 1 : nc
   for sex = [male, female]
      if (hasPopDataM(sex, c) < 0.5)  &  (rgdpwV(c) > 0)
         % ***  Find countries on same continent  ***
         idxV = find( continentV == continentV(c)  &  (hasDataM(sex,:) == 1) );
         if length(idxV) < 1
            % No country on same continent.
            % Use all countries with population and RGDPW data
            disp(sprintf('No countries on same continent as %i', c));
            idxV = find(hasDataM(sex,:) == 1);
         end

         % Find country with closest RGDPW
         [tmp, tmp, cMin] = minidx( abs( rgdpwV(idxV) ./ rgdpwV(c) - 1 ) );
         cMin = idxV(cMin);
         sourceAgeM(sex,:,c) = sourceAgeM(sex,:,cMin);
         imputeCntV(sex) = imputeCntV(sex) + 1;
         % disp(sprintf('Data for country %3i taken from %3i', c, cMin));
      end
   end
end


% *****  Save  *******

save2( sourceAgeM, c2_class_fn(year, c2S.vSourceAge, filterNo, dbg) );

disp(sprintf('No of countries with population data:  %i', ...
   sum( hasPopDataM(male,:) ) ));
disp(sprintf('No of countries imputed by sex:  %i   %i', imputeCntV ));



% ******  Self test  *******
if 0
   c = 72;
   disp('Data for USA male');
   disp(ageUpperV);
   disp(squeeze(sourceAgeM(male, :, c)));
end


%disp(mfilename);
%keyboard;


% ***********  eof  *************
