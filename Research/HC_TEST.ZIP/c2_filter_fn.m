function [fPath, fn] = c2_filter_fn(year, filterNo);
% File name for data sorted into classes
% IN:
%  year
%  filterNo
% -----------------------

global UNDEFINED c2S

v_check( year,   'i', [1,1], 1940, 2020 );
v_check( filterNo, 'i', [1,1], 0, 999 );

fn = sprintf('flt%04i_%03i.mat', year, filterNo);

fPath = [c2S.dataDir, fn];


% *** eof ***
