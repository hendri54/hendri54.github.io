function c2_source_weights(year, filterNo, dbg);
% Construct source country population weights
% by the same classes as used throughout the analysis

% Should not have any missing values. Otherwise entire
% country/sex is dropped.

% OUT:
%  sourceWtM(n1,sex,age,nS,nC)
%     Source country population weights
%  skillWtM(sex,fltS.nSkill,nC)
%     Source country population weights by skill class of filter

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ----------------------------------------------------

global UNDEFINED c2S

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;


% Load source country education distribution
sourceEducM = load2( c2_class_fn(year, c2S.vSourceEduc, filterNo, dbg) );
[nSex, nEduc, nC1] = size( sourceEducM );

% Load source country age distribution
sourceAgeM = load2( c2_class_fn(year, c2S.vSourceAge, filterNo, dbg) );
[nSex2, nAge, nC2] = size( sourceAgeM );

nc = min( nC2, nC1 );


sourceWtM = repmat(UNDEFINED, [1, nSex, nAge, nEduc, c2S.nCountries]);
skillWtM  = repmat(UNDEFINED, [nSex, nSkill, c2S.nCountries]);

for c = 1 : nc
   for sex = 1 : nSex
      ageV  = squeeze(sourceAgeM(sex,:,c));
      educV = squeeze(sourceEducM(sex,:,c));
      % Does the country have data?
      if min(educV) > 0  &  min(ageV) > 0
         if sum(ageV(:)-1) > 1e-4
            warnmsg([ mfilename, ':  Invalid age distribution' ]);
            keyboard;
         end
         if sum(educV(:)-1) > 1e-4
            warnmsg([ mfilename, ':  Invalid education distribution' ]);
            keyboard;
         end
         % Assume that education and age are indepdendent
         sourceWtM(1,sex,1:nAge,1:nEduc,c) = ageV(:) * educV(:)' ...
            ./ sum(ageV) ./ sum(educV);

         % *** Weights by filter skill class ***
         for skill = 1 : nSkill
            % These education classes belong into current skill class
            skillIdxV = fltS.skillIdxM(skill,1) : fltS.skillIdxM(skill,2);
            % Fractions of workers by class
            wtM = sourceWtM(1,sex,:,skillIdxV,c);
            % Mass in this skill class
            skillWtM(sex,skill,c) = sum(wtM(:));
         end
      end
   end
end

% Save
save2( sourceWtM, c2_class_fn(year, c2S.vSourceWt,   filterNo, dbg) );
save2( skillWtM,  c2_class_fn(year, c2S.vSrcSkillWt, filterNo, dbg) );

%disp(mfilename);
%keyboard;

% **********   eof   ***********
