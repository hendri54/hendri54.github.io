function c2_sum_by_skill(loadFn, saveFn, saveSCFn, filterNo, dbg)
% Compute cell totals of variable by (sex, skill, country)
% Assumes that variable is stored in classes [dim1, sex, age, educ, c]
% as CLASS TOTALS, not as class per capita averages!

% Example:
%  Compute total no of observations in each sex, skill, country class

% IN:
%  loadFn      File to be loaded (with load2)
%  saveFn      File to be saved  (with save2)
%  saveSCFn    File for matrix by (sex, c)
%              Set to negative number to not save by (sex, c)

% OUT:  Stored in variable file
%  sumM(sex, skill, c)
%  sumSC(sex, c);

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------

global c2S UNDEFINED

if nargin ~= 5
   abort([ mfilename, ': Invalid nargin' ]);
end



% ******  Filter settings  *******
fltS = c2_filter_settings(filterNo, dbg);
% No of imperfectly substitutable skill types
nSkill = fltS.nSkill;
% Which education classes count as skilled/unskilled?
skillIdxM = fltS.skillIdxM;



% ********  Load data  ************

% Load the variable to be averaged
varM = load2( loadFn );
[n1, nSex, nAge, nS, nC] = size(varM);



% **********  Compute averages  ****************

% Averages by sex, skill country
sumM = repmat( UNDEFINED, [nSex, nSkill, nC] );
if saveSCFn(1) > 0
   sumSC = repmat( UNDEFINED, [nSex, nC] );
end

for c = 1 : nC
   for sex = 1 : nSex
      for skill = 1 : nSkill
         skillIdxV = skillIdxM(skill,1) : skillIdxM(skill,2);
         % Sum over all dimensions
         sumM(sex,skill,c) = sum_dim_lh( varM(:,sex,:,skillIdxV,c), 0, dbg);
      end % for skill

      % Sum over all education classes
      if saveSCFn(1) > 0
         sumSC(sex, c) = sum_dim_lh( varM(:,sex,:,:,c), 0, dbg);
      end
   end % for sex
end % for c




% ****  Save  ****
save2( sumM, saveFn );
if saveSCFn(1) > 0
   save2( sumSC, saveSCFn );
end

%disp(mfilename);
%keyboard;

% ***********  eof  ************
