function [xV, infoS] = c2_pums_load(varNo, year, filterNo, dbg);
% Save one variable file into matlab matrix
% ---------------------------------------------

global UNDEFINED

xV = UNDEFINED;
infoS = UNDEFINED;

[fPath, fn] = c2_pums_fn(year, varNo, filterNo, dbg);
load(fPath);


% ********  eof  ********
