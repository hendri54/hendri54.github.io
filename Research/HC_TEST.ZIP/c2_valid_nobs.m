function c2_valid_nobs(year, filterNo, dbg);
% Mark which sex/skill/country combinations have
% enough observations

% OUT:
%  validM(sex, skill, c)  [not implemented]
%  validSC(sex, c)
%     1: sufficient no of observations
%     0: otherwise

% ------------------------------------------------

global UNDEFINED c2S

fltS = c2_filter_settings(filterNo, dbg);

% Load no of observations
nobsM  = load2( c2_class_fn(year, c2S.vImmNobs, filterNo, dbg) );
nobsSC = load2( c2_class_fn(year, c2S.vImmNobsSC, filterNo, dbg) );

%validM  = repmat( UNDEFINED, size(nobsM) );
validSC = repmat( UNDEFINED, size(nobsSC) );

for c = 1 : c2S.nCountries
   % No of observations of country
   nobsC = sum( nobsSC(:,c) );
   % Drop everything if total nObs for country too small
   if nobsC >= fltS.minObs
      for sex = [c2S.male, c2S.female]
         % Drop entire sex if nObs too small
         if nobsSC(sex,c) >= fltS.minObsSex
            % Only keep by sex, if ALL skills have sufficient nobs
            if min(squeeze( nobsM(sex,:,c) )) >= fltS.minObsSS
               validSC(sex,c) = 1;
               %validM(sex,:,c) = 1;
            end
         end
      end % for sex
   end
end


% Save
%save2( validM,  c2_class_fn(year, c2S.vValidNobs,   filterNo, dbg) );
save2( validSC, c2_class_fn(year, c2S.vValidNobsSC, filterNo, dbg) );


% ********  eof  ***********
