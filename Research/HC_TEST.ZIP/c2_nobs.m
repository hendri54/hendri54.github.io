function c2_nobs(year, filterNo, dbg);
% Compute no of observations by sex/skill/country
% and by sex/country
% ------------------------------------------------

global UNDEFINED c2S

loadFn   = c2_class_fn(year, c2S.vCellCnt,   filterNo, dbg);
saveFn   = c2_class_fn(year, c2S.vImmNobs,   filterNo, dbg);
saveSCFn = c2_class_fn(year, c2S.vImmNobsSC, filterNo, dbg);

c2_sum_by_skill(loadFn, saveFn, saveSCFn, filterNo, dbg);


% *********  eof  *********
