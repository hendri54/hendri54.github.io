function explFracV = c2_explained_frac(relMeasuredV, relPredictedV, dbg);
% Which fraction of relMeasuredV is explained by relPredictedV?

% IN:
%  relMeasuredV         Source country / US measured level (e.g. Y/L)
%  relPredictedV        Same predicted

% OUT:
%  Fractions explained for each observation
%  UNDEFINED values are ignored

% ---------------------------------

global UNDEFINED

idxV = find( relMeasuredV ~= UNDEFINED  &  relPredictedV ~= UNDEFINED );

explFracV = repmat( UNDEFINED, size(relMeasuredV) );

explFracV(idxV) = log(relPredictedV(idxV)) ./ log(relMeasuredV(idxV));


% *******  eof  **********
