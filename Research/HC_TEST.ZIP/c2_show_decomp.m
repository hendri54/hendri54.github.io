function c2_show_decomp(year, filterNo, expNo, dbg);
% Show earnings per worker decomposition
% Figure with 5 panels. w-kappa, w-N, w-eta, w-p

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ----------------------------------------------------

global c2S UNDEFINED pwtS

saveFigures = c2S.saveFigures;
figOptS = struct('FontMode','fixed','FontSize',10, 'preview', 'tiff');
diaryFn = [c2S.dataDir, sprintf('Decomp%04i_%03i_%03i', year, filterNo, expNo)];
showFigures = 01;
ylPoor = 0.4;     % Y/L relative to US that counts as poor

male = c2S.male;
female = c2S.female;
cUSA = c2S.cUSA;

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;
expS = c2_exp_settings(expNo, dbg);

% Load strings with country names
[cn, cnLen, cnMax] = cnames(c2S.pwtVer);
clabelM = pw_clabels(c2S.pwtVer);

% Load result file
acctS = load2( c2_acct_fn(year, filterNo, expNo, dbg), dbg );
decEarnPerWkM = acctS.decEarnPerWkM;
[nl, nSex, nc2] = size(decEarnPerWkM);

% Source country earnings per worker (real)
% By sex, country
srcEarnSC = load2( c2_class_fn(year, c2S.vSourceEarnSC, filterNo, dbg) );

% Source country skill premia
srcSkillPremM = load2( c2_class_fn(year, c2S.vSrcSkillPrem, filterNo, dbg) );



% *********  SHOW DECOMPOSITION  ******************

nc = min([c2S.nCountries, cnMax]);

diaryon( diaryFn );
disp(' ');
disp('-------  Y/L relative to US. Decomposition  --------');
nl = 4;
% Unexplained fraction (dw/w, not ratio wM/wP) by level
unexplainedM  = UNDEFINED .* ones(nl, nSex+1, c2S.nCountries);
skillPremM    = UNDEFINED .* ones(nSex+1, c2S.nCountries);

for sex = c2S.sexAll
   if sex == male
      sexStr = 'Male';
   elseif sex == female
      sexStr = 'Female';
   else
      sexStr = 'Both sexes';
   end
   disp(' ');
   disp([ '* ', sexStr, ' *' ]);
   disp('Country                     K/Y  PopWts  Unmeas.H SelfSel. SrcEarn  ResidNoSS SkPrem');

   relSourceEarnM(sex,:) = 100 .* srcEarnSC(sex,:) ./ srcEarnSC(sex,cUSA);

   % Relative earnings per worker as predicted by model with identical tfps
   explainedM = 100 .* acctS.explainedM;

   for c = 1 : nc
      if decEarnPerWkM(4,sex,c) > 0
         % Unexplained residual
         for l = 1 : nl
            unexplainedM(l,sex,c) = ...
               100 * (100 .* acctS.explainedM(l,sex,c) / max(0.01, relSourceEarnM(sex,c)) - 1);
         end
         % Skill premium (skilled/unskilled earnings per worker)
         skillPremM(sex,c) = acctS.decBySkillM(4,sex,nSkill,c) / acctS.decBySkillM(4,sex,1,c);
      end

      dataV = [c, 100 .* acctS.explainedM(1:4,sex,c)',  relSourceEarnM(sex,c), ...
         unexplainedM(nl-1,sex,c), skillPremM(sex,c)];

      if min(dataV(1:6)) > 0
         disp([ sprintf('%15s  ', cn(c,1:15)), sprintf('  %6.1f', dataV) ]);
      end
   end


   % *******  Factors explained by K/Y etc  ********
   if showFigures == 1
      idxV = find( relSourceEarnM(sex,1:nc) > 0  &  squeeze(unexplainedM(nl,sex,1:nc))' > -90 );
      % Range to display (risky!)
      axisVec = [0 100  0 170];

      subplot(3,2,1);
      plot( relSourceEarnM(sex,idxV), 100 .* squeeze(acctS.explainedM(1,sex,idxV)), 'bo', ...
         [0,100], [0,100], 'k-' );
      axis( axisVec );
      xlabel('(a) Effect of capital-output ratio on earnings');

      subplot(3,2,4);
      plot( relSourceEarnM(sex,idxV), 100 .* squeeze(acctS.explainedM(2,sex,idxV)), 'bo', ...
         [0,100], [0,100], 'k-' );
      axis( axisVec );
      xlabel('(c) Joint effect of capital and measured skills');

      subplot(3,2,6);
      plot( relSourceEarnM(sex,idxV), 100 .* squeeze(acctS.explainedM(3,sex,idxV)), 'bo', ...
         [0,100], [0,100], 'k-' );
      axis( axisVec );
      xlabel('(e) Predicted source country earnings');


      subplot(3,2,3);
      plot( relSourceEarnM(sex,idxV), 100.*squeeze(decEarnPerWkM(2,sex,idxV))./squeeze(decEarnPerWkM(1,sex,idxV)), 'bo', ...
         [0,100], [0,100], 'k-' );
      axis( axisVec );
      xlabel('(b) Effect of measured skills on earnings');

      subplot(3,2,5);
      plot( relSourceEarnM(sex,idxV), 100.*squeeze(decEarnPerWkM(3,sex,idxV))./squeeze(decEarnPerWkM(2,sex,idxV)), 'bo', ...
         [0,100], [0,100], 'k-' );
      axis( axisVec );
      xlabel('(d) Effect of unmeasured skills on earnings');

      if saveFigures == 1
         fn = c2_fig_fn(1, year, filterNo, expNo, dbg);
         exportfig(gcf, fn, figOptS);
      end
      pause_print(0);
   end



   % ***********  Unexplained Fractions  ****************

   % Mean unexplained ratio among the poor
   idxV = find( relSourceEarnM(sex,1:nc) > 0  &  relSourceEarnM(sex,1:nc) < 40 ...
      & squeeze(unexplainedM(nl,sex,1:nc))' > -90 );
   disp(sprintf('Mean unexplained fraction (not ratio) for relY<0.4:  %5.1f pct   w/o ss: %5.1f', ...
      mean(squeeze(unexplainedM(nl,sex,idxV))), mean(squeeze(unexplainedM(nl-1,sex,idxV))) ));

   % Poorest and richest 5 countries
   N = 5;
   validV = ( relSourceEarnM(sex,1:nc) > 0   &  squeeze(explainedM(nl,sex,1:nc))' > 0 );
   [idxRichestV, idxPoorestV] = c2_richest_poorest(N, relSourceEarnM(sex,1:nc), validV, dbg);
   disp(sprintf('Mean unexplained fraction (not ratio) for poorest %i:  %5.1f pct   w/o ss: %5.1f', ...
      N, mean(squeeze(unexplainedM(nl,sex,idxPoorestV))), mean(squeeze(unexplainedM(nl-1,sex,idxPoorestV))) ));


   if showFigures == 1
      idxV = find( relSourceEarnM(sex,1:nc) > 0  &  squeeze(unexplainedM(nl-1,sex,1:nc))' > -90 );
      % Add 1 to make the fractions into ratios
      %plot( relSourceEarnM(sex,idxV), 1 + squeeze(unexplainedM(nl-1,sex,idxV))' ./ 100, 'bo' );
         % relSourceEarnM(sex,idxV), 100 + squeeze(unexplainedM(nl,sex,idxV))', 'ro', ...
      % legend('Self-selection', 'No self-selection');
      pwlS.FontSize = 8;
      plot_w_labels_lh( relSourceEarnM(sex,idxV), 1 + squeeze(unexplainedM(nl-1,sex,idxV))' ./ 100, ...
         clabelM(idxV,:), pwlS, dbg);
      xlabel('Relative source country earnings');
      if saveFigures == 1
         fn = c2_fig_fn(2, year, filterNo, expNo, dbg);
         exportfig(gcf, fn, figOptS, 'height', 4);
      end
      pause_print(0);
   end



   % ***********  Fraction explained by hc  ************

   % Mean explained for the rich and for the poor. By level
   nl = 4;
   poor = 1;   rich = 2;
   poorest = 3;   richest = 4;
   meanExplainedM = UNDEFINED .* ones(4, nl);
   % Mean s(c) factors
   meanSelectV = UNDEFINED .* ones(4, 1);

   % Rich and poor countries
   idxRichV = find( relSourceEarnM(sex,:) > 70  &  squeeze(explainedM(4,sex,:))' > 0 );
   idxPoorV = find( relSourceEarnM(sex,:) > 0   &  squeeze(explainedM(4,sex,:))' > 0  &  ...
      relSourceEarnM(sex,:) < 40 );

   % Poorest and richest 5 countries
   N = 5;
   validV = ( relSourceEarnM(sex,:) > 0   &  squeeze(explainedM(4,sex,:))' > 0 );
   [idxRichestV, idxPoorestV] = c2_richest_poorest(N, relSourceEarnM(sex,:), validV, dbg);

   for l = 1 : nl
      meanExplainedM(poor,l) = mean( squeeze(acctS.explainedFracM(l,sex,idxPoorV)) );
      meanExplainedM(rich,l) = mean( squeeze(acctS.explainedFracM(l,sex,idxRichV)) );
      meanExplainedM(poorest,l) = mean( squeeze(acctS.explainedFracM(l,sex,idxPoorestV)) );
      meanExplainedM(richest,l) = mean( squeeze(acctS.explainedFracM(l,sex,idxRichestV)) );
   end
   meanSelectV(poor) = mean(mean( squeeze(acctS.selfSelectM(sex,1:nSkill,idxPoorV)) ));
   meanSelectV(rich) = mean(mean( squeeze(acctS.selfSelectM(sex,1:nSkill,idxRichV)) ));
   meanSelectV(poorest) = mean(mean( squeeze(acctS.selfSelectM(sex,1:nSkill,idxPoorestV)) ));
   meanSelectV(richest) = mean(mean( squeeze(acctS.selfSelectM(sex,1:nSkill,idxRichestV)) ));

   disp(' ');
   disp('--- Mean fraction explained by level ---');
   disp('Level    Poor    Rich   Poorest  Richest');
   for l = 1 : nl
      disp(sprintf(' %i    %5.1f   %5.1f    %5.1f   %5.1f', ...
         l, 100*meanExplainedM(poor,l),    100*meanExplainedM(rich,l), ...
            100*meanExplainedM(poorest,l), 100*meanExplainedM(richest,l)));
   end
   disp(' ');
   disp('--- Mean s(c) factors [proxy] ---');
   disp(sprintf('       %5.1f   %5.1f    %5.1f   %5.1f', ...
      meanSelectV([poor,rich, poorest, richest]) ));

   if 0
      % Graph for the poor
      noSSv = squeeze(acctS.explainedFracM(3,sex,idxPoorV)) .* 100;
      ssV   = squeeze(acctS.explainedFracM(4,sex,idxPoorV)) .* 100;
      plot( relSourceEarnM(sex,idxPoorV), noSSv, 'ro',  ...
            relSourceEarnM(sex,idxPoorV), ssV, 'bo' );
      legend('No self-selection', 'Self-selection');
      title('Fraction explained by HC');
      pause_print(0);

   end


   % **********  Skill Premia  *****************
   if nSkill > 1
      disp(' ');
      idxV = find( srcSkillPremM(sex,1:nc) > 0  &  skillPremM(sex,1:nc) > 0 );
      disp(sprintf('US skill premium model:  %5.2f    data: %5.2f', ...
         skillPremM(sex,cUSA), srcSkillPremM(sex,cUSA) ));
      disp(sprintf('Avg skill premium relative to US.  Model: %5.2f  Data: %5.2f', ...
         mean(skillPremM(sex,idxV)) / skillPremM(sex,cUSA), ...
         mean(srcSkillPremM(sex,idxV)) / srcSkillPremM(sex,cUSA) ));

      if 0
         idxV = find( relSourceEarnM(sex,1:nc) > 0  &  skillPremM(sex,1:nc) > 0 );
         plot( relSourceEarnM(sex,idxV), skillPremM(sex,idxV), 'bo', ...
            relSourceEarnM(sex,idxV), skillPremM(sex,cUSA).*ones(size(idxV)), 'k-', ...
            relSourceEarnM(sex,idxV), max(0,srcSkillPremM(sex,idxV)), 'ro' );
         legend('Model', 'USA Model', 'Data');
         title('Skill Premia');
         pause_print(0);
      end
   end

end % for sex




% ------------  COMPARE WITH HALL-JONES 1999  ----------------
if 1
   disp(' ');
   disp('----------  Comparison with Hall-Jones 1999  ---------');
   disp(' ');
   sex = c2S.sexAll;

   % Load Hall-Jones data indexed by PWT numbers
   % All relative to US
   [kyFactorHJ, hFactorHJ, ylHJ] = load_hj99;

   % Corresponding vectors for my model
   kyFactorV = squeeze(acctS.explainedM(1,sex,:))';
   hFactorV  = squeeze(decEarnPerWkM(3,sex,:))' ./ squeeze(decEarnPerWkM(1,sex,:))';

   nc = min([c2S.nCountries, length(kyFactorHJ)]);

   idxV = find( kyFactorV(1:nc) > 0   &   kyFactorHJ(1:nc) > 0 );
   corrCoeffKY = corrcoef(kyFactorV(idxV), kyFactorHJ(idxV));
   disp(sprintf('Correlation coefficient between kyFactors Hall-Jones vs. LH: %6.3f', ...
      corrCoeffKY(1,2) ));

   %idxV = find( hFactorV(1:nc) > 0   &   hFactorHJ(1:nc) > 0 );
   corrCoeffH = corrcoef(hFactorV(idxV), hFactorHJ(idxV));
   disp(sprintf('Correlation coefficient between hFactors Hall-Jones vs. LH: %6.3f', ...
      corrCoeffH(1,2) ));

   bV = regress( log(hFactorHJ(idxV))', [ones(length(idxV),1), log(hFactorV(idxV))'], 0.05 );
   disp(sprintf('log H-HJ = %6.3f + %6.3f * log H-LH', bV(1:2) ));


   % Average fractions accounted for by K and H. Poor countries
   idxPoorV = find( kyFactorV(1:nc) > 0   &   kyFactorHJ(1:nc) > 0  &  ylHJ(1:nc) < ylPoor );
   % Avg fraction explained by K
   avgKYv  = c2_explained_frac( ylHJ(idxPoorV), kyFactorV(idxPoorV), dbg );
   avgKYHJ = c2_explained_frac( ylHJ(idxPoorV), kyFactorHJ(idxPoorV), dbg );
   % Avg fraction explained by H
   avgHv  = c2_explained_frac( ylHJ(idxPoorV), hFactorV(idxPoorV), dbg );
   avgHHJ = c2_explained_frac( ylHJ(idxPoorV), hFactorHJ(idxPoorV), dbg );
   disp(' ');
   disp('Avg explained by KY');
   disp(sprintf(' LH: %6.2f    HJ: %6.2f',  mean(avgKYv), mean(avgKYHJ) ));
   disp('Avg explained by H');
   disp(sprintf(' LH: %6.2f    HJ: %6.2f',  mean(avgHv), mean(avgHHJ) ));
   %keyboard;


   % *********  Plot my factors against Hall/Jones  *******
   if showFigures == 1
      line45 = [0.4, 1];
      %subplot(2,2,1);
      pwlS.FontSize = 8;
      hold on;
      plot_w_labels_lh( kyFactorV(idxV),  kyFactorHJ(idxV), clabelM(idxV,:), pwlS, dbg);
      %plot( kyFactorV(idxV),  kyFactorHJ(idxV), 'bo',  line45, line45, 'k-' );
      plot( line45, line45, 'k-' );
      hold off;
      xlabel('(a) K/Y factors');
      %if saveFigures == 1
      %   fn = c2_fig_fn(10, year, filterNo, expNo, dbg);
      %   exportfig(gcf, fn, figOptS, 'height', 4);
      %end
      pause_print(0);

      %subplot(2,2,2);
      %plot( hFactorV(idxV),  hFactorHJ(idxV), 'bo',  line45, line45, 'k-' );
      pwlS.FontSize = 8;
      hold on;
      plot_w_labels_lh( hFactorV(idxV),  hFactorHJ(idxV), clabelM(idxV,:), pwlS, dbg);
      plot( line45, line45, 'k-' );
      hold off;
      ylabel('Hall and Jones (1999)');
      xlabel('One-skill model');
      if saveFigures == 1
         fn = c2_fig_fn(11, year, filterNo, expNo, dbg);
         exportfig(gcf, fn, figOptS, 'height', 4);
      end
      pause_print(0);
   end
end


diary off;

%disp(mfilename);
%keyboard;


% ************  eof  ***********
