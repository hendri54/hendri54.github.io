function c2_show_rel_imm_earn(year, filterNo, dbg);
% Show table with earnings of immigrants relative to natives
% by sex and high/low skill
% ---------------------------------------------------

global UNDEFINED c2S pwtS

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;


% Load country names
[cn, cnLen, cnMax] = cnames(c2S.pwtVer);


% **********  Load classified data  **********

cntM = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );
% Relative immigrant earnings by (sex, skill, country)
relEarnM = load2( c2_class_fn(year, c2S.vRelImmEarn, filterNo, dbg) );
% Immigrant school years by (sex, country)
immSchoolAllM = load2( c2_class_fn(year, c2S.vImmSchoolSC, filterNo, dbg) );

[n1, nSex, nAge, nS, nC] = size(cntM);



% ********  Table  *********

disp(' ');
disp('Country           Count    School            Skill1          Skill2');
disp('                           Male  Female      Male  Female    Male Female');
for c = 1 : nC
   cEarnM = relEarnM(:,:,c);
   if max(cEarnM) > 0
      cCntM = cntM(:,:,:,:,c);
      cCnt = sum(cCntM(:));
      dataV = [cCnt, immSchoolAllM(1:2,c)'];
      fmtStr = '  %6i   %5.1f  %5.1f';
      for skill = 1 : nSkill
         % Male and female relative earnings for this skill
         dataV = [dataV, 100.*cEarnM(1:2,skill)'];
         fmtStr = [fmtStr, '    %5.1f   %5.1f'];
      end
      disp([ sprintf('%15s', cn(c,1:15)),  sprintf(fmtStr, dataV) ]);
   end
end


if 1
   rgdpwV = getvar(pwtS.rgdpwIdx, year,year, c2S.pwtVer, dbg);
   skill = 1;
   sex = 1;
   idxV = find( rgdpwV > 0  &  squeeze(relEarnM(sex,skill,:)) > 0 );
   plot( rgdpwV(idxV)./rgdpwV(pwtS.cUSA).*100,  ...
         squeeze(relEarnM(sex,skill,idxV)).*100, 'bo' );
   title('Immigrant Earnings vs. RGDPW');
   pause_print(0);
end

%disp(mfilename);
%keyboard;


% ***********  eof  ****************
