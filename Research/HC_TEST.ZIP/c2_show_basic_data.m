function c2_show_basic_data(year, filterNo, expNo, dbg);
% Show table with basic country data

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  2-3-2001

% -------------------------------------------------

global pwtS bl2S c2S UNDEFINED

if nargin ~= 4
   abort([ mfilename, ': Invalid no of arguments' ]);
end

diaryFn = [c2S.dataDir, sprintf('BasicTable%04i_%03i_%03i', year, filterNo, expNo)];
male = c2S.male;
female = c2S.female;
cUSA = c2S.cUSA;
nc = c2S.nCountries;

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;


% *************  Load Data  ************************

% Load strings with country names
[cn, cnLen, cnMax] = cnames(c2S.pwtVer);

% K/Y
KYv = load2( c2_class_fn(year, c2S.vKY, filterNo, dbg) );

% Load rgdp per worker
rgdpwV = getvar(pwtS.rgdpwIdx, year, year, c2S.pwtVer, dbg)';
relGDPv = rgdpwV ./ rgdpwV(pwtS.cUSA);
relGDPv( rgdpwV <= 0 ) = UNDEFINED;
if length(relGDPv) < c2S.nCountries
   relGDPv = [relGDPv(:)', UNDEFINED .* ones(1, c2S.nCountries-length(relGDPv))];
end
relGDPv = relGDPv(1:c2S.nCountries);

% Load GDP per capita relative to US
relPerCapV = getvar(pwtS.pRelGdpIdx, year, year, c2S.pwtVer, dbg)' ./ 100;



% Load average years of schooling
BLavgSchoolM = c2_bl_var_load_yr(bl2S.vAvgYrAll, year, filterNo, dbg);

% Mincer regression data by (country,sex,year)
mS = c2_mincer_load(year, [male, female], dbg);
mincerSchoolM = mS.avgSchoolM';
if cols(mincerSchoolM) < nc
   mincerSchoolM(:, cols(mincerSchoolM)+1 : nc) = UNDEFINED;
end

% Schooling of immigrants by (sex, country)
immSchoolSC = load2( c2_class_fn(year, c2S.vImmSchoolSC, filterNo, dbg) );
% Observation count by sex/country
immCntSC = load2( c2_class_fn(year, c2S.vImmNobsSC, filterNo, dbg) );
% Is sex/country combination valid?
validSC = load2( c2_class_fn(year, c2S.vValidNobsSC, filterNo, dbg) );


disp(' ');
disp('---------------- Basic stats:   ----------------');

diaryon(diaryFn, UNDEFINED, '.out');
for sex = male
   if sex == male
      sexStr = 'Male';
   elseif sex == female
      sexStr = 'Female';
   else
      sexStr = 'Both sexes';
   end
   disp(' ');
   disp('Country           PWT   Rel   K/Y    Avg Schooling    nObs');
   disp('                  No.   GDP         BL Mincer Immigr');

   for c = 1 : nc
      if validSC(sex, c) == 1
         relGDP = max(0, relGDPv(c) * 100);
         dataV = [c, relGDP, KYv(c), ...
            BLavgSchoolM(sex,c), mincerSchoolM(sex,c), immSchoolSC(sex,c), immCntSC(sex,c)];
         if dataV(3) > 0  &  dataV(4) > 0  &  c ~= c2S.cUSA
            disp([ sprintf('%15s  ', cn(c,1:15)), ...
               sprintf(' %3i %6.1f %6.1f %6.1f %6.1f %6.1f %6i', dataV) ]);
         end
      end % if
   end
end % for sex



% *******  Mean years of schooling  *************

sex = c2S.male;
immSchoolV = immSchoolSC(sex,:);
mincerSchoolV = mincerSchoolM(sex,:);
BLschoolV = BLavgSchoolM(sex,:);

% All countries
idxV = find( immSchoolV > 0  &  mincerSchoolV > 0  &  BLschoolV > 0 );
disp(' ');
disp(sprintf('Mean years of schooling BL: %5.1f  Mincer: %5.1f  Immigrants: %5.1f', ...
   mean(BLschoolV(idxV)), mean(mincerSchoolV(idxV)), mean(immSchoolV(idxV)) ));

% Poor countries
idxV = find( immSchoolV > 0  &  mincerSchoolV > 0  &  BLschoolV > 0  &  relGDPv < 0.4 );
disp(' ');
disp(sprintf('Poor countries          BL: %5.1f  Mincer: %5.1f  Immigrants: %5.1f', ...
   mean(BLschoolV(idxV)), mean(mincerSchoolV(idxV)), mean(immSchoolV(idxV)) ));
diary off;


% ******  No of observations  *******

nTotal  = sum(immCntSC(:));
nNative = sum(immCntSC(:,c2S.cUSA));
nImmig  = nTotal - nNative;
disp(' ');
disp(sprintf('No of observations. Immigrants: %i   Natives: %i', ...
   nImmig, nNative));


% *******  Compare relative gdp per worker/per capita  ************
if 0
   nPwt = min(length(relGDPv), length(relPerCapV));
   validV = find( relGDPv(1:nPwt) > 0  &  relPerCapV(1:nPwt) > 0 );
   diffV = relGDPv(validV) ./ relPerCapV(validV) - 1;
   maxAbsDev = max(abs(diffV)) .* 100;
   maxDev    = max(diffV)  .* 100;
   minDev    = min(diffV)  .* 100;
   meanDev   = mean(diffV) .* 100;
   disp(' ');
   disp('--- Compare gdp per worker/per capita ---');
   disp(sprintf('Max dev %5.1f   Min dev %5.1f   Max abs dev %5.1f   Mean dev %5.1f', ...
      maxDev, minDev, maxAbsDev, meanDev ));

   if 1
      plot( relGDPv(validV), diffV .* 100, 'bo' );
      title('Pct diff RGDPW vs per capita GDP');
      pause_print(0);
   end
end


%disp(mfilename);
%keyboard;


% *******  eof  *********
