function invalidV = c2_filter_weight( weightV, fltS, dbg );
% Find invalid observations in variable person weight
% IN:
%  weightV      Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

if fltS.posWeight == 1
   invalidV = find( weightV <= 0 );
else
   invalidV = find( weightV < 0 );
end


% ********  eof  ***********
