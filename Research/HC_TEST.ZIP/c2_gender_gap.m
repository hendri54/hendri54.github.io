function c2_gender_gap(year, filterNo, dbg);
% Calculate ratio of female to male average earnings by country
% Save to file by PWT no

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% -------------------------------------------------------------

global UNDEFINED c2S pwtS
male = c2S.male;
female = c2S.female;

% Ratio of male to female earnings
earnRatioV = UNDEFINED .* ones(1, c2S.nCountries);
% Data source
sourceV = UNDEFINED .* ones(size(earnRatioV));


% *****  Blau-Kahn 1996 table 3  *******

pwtNoV = [pwtS.cAustralia, pwtS.cAustria, pwtS.cGermany, pwtS.cHungary, pwtS.cItaly, ...
   pwtS.cNorway, pwtS.cSweden, pwtS.cSwitzerland, pwtS.cEngland, pwtS.cUSA];
blauKahnV = [0.7334  0.7407  0.7091  0.6454  0.8232  0.7138  0.7724  0.6455  0.6133 ...
   0.6692];
earnRatioV(pwtNoV) = blauKahnV;

% Mark that data came from Blau-Kahn
sourceV(pwtNoV) = 1;


% *******  Mincer regressions  ********

% Compute average earnings in local currency
% by [pwtNo, sex, year]
censusYearV = [1960 1970 1980 1990];
sexV = [male female];
mEarnM = c2_avg_mincer_earn(censusYearV, sexV, dbg);
[nc, nSex, ny] = size(mEarnM);
nc = min(nc, c2S.nCountries);

% Start from last year, so that earlier years do not override
% later year observations
for iy = ny : - 1 : 1
   for c = 1 : nc
      % Do we have Mincer data, but no valid observation yet?
      if min(squeeze(mEarnM(c,:,iy))) > 0   &   earnRatioV(c) < 0
         earnRatioV(c) = mEarnM(c,female,iy) / mEarnM(c,male,iy);
         sourceV(c) = 2;
      end
   end
end



% Fill in missing values as average of the existing values
idxV = find( earnRatioV > 0.2  &  earnRatioV < 1.5 );
meanEarnRatio = mean( earnRatioV(idxV) );

missV = find( earnRatioV <= 0.2  |  earnRatioV >= 1.5 );
earnRatioV(missV) = meanEarnRatio;
sourceV(missV) = 3;

disp(sprintf('No of valid observations:  %i    Imputed: %i', ...
   length(idxV), length(missV) ));


% ***  Save  ***
save2( earnRatioV, c2_class_fn(year, c2S.vGenderGap, filterNo, dbg) );




% ******  Graph  *******
if 0
   % Load RGDPW
   rgdpwV = getvar(pwtS.rgdpwIdx, year, year, c2S.pwtVer, dbg)';
   idx1V = find( sourceV == 1  &  rgdpwV > 0 );
   idx2V = find( sourceV == 2  &  rgdpwV > 0 );
   idx3V = find( sourceV == 3  &  rgdpwV > 0 );

   plot( rgdpwV(idx1V), earnRatioV(idx1V), 'ro', ...
         rgdpwV(idx2V), earnRatioV(idx2V), 'bo', ...
         rgdpwV(idx3V), earnRatioV(idx3V), 'ko' );
   title('Gender gap vs RGDPW');
   legend('Blau-Kahn', 'Mincer data', 'Average');
   pause_print(0);
end

%disp(mfilename);
%keyboard;

% *********  eof  **********
