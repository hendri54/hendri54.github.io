function mS = c2_mincer_load(censusYearV, sexCodeV, dbg);
% Load data for Mincer regressions

% IN:  File exported from Excel spreadsheet
%  censusYearV       Retain observations belonging to these census years only
%                    These should be 1980, 1990 etc (not 1979, 1989)
%  sexCodeV          Retain only these sex codes. 1=male. 2=female

% OUT:
%  mS    Structure with matrices by (pwtNo, sex, censusYear)
%     .useM             1 for a usable observation; UNDEFINED else

% Author:  Lutz Hendricks
% Last checked:  1/23/01
% TEST:  t_c2_mincer_load

% --------------------------------------------

global UNDEFINED c2S
% File with Mincer regression results
mincerFn = [c2S.dataDir, 'mincer_regr.txt'];

tmp = dlmread(mincerFn, '\t');


% ****  Filter observations  ****
% Only retain "usable" observations with valid census years
yearV = tmp(:, 6)';    % Year of Mincer regression
useV  = tmp(:, 12)';   % Use this observation?
v_check( useV,  'f', UNDEFINED,  0, 1 );

% Ex: For 1980 census year, retain 1975 to 1984 data
useIdxV = find( useV > 0.5  &  yearV >= censusYearV(1)-5  &  ...
   yearV <= censusYearV(end)+4 );
useV  = useV(useIdxV);
yearV = yearV(useIdxV);

% Break into variables
pwtNoV      = tmp(useIdxV, 1)';  % PWT no
interceptV  = tmp(useIdxV, 2)';    % Intercept; in current dollars
schoolV     = tmp(useIdxV, 3)';    % Mincer regression coefficients
expV        = tmp(useIdxV, 4)';
expSqV      = tmp(useIdxV, 5)';

sexV        = tmp(useIdxV, 8)';
avgSchoolV  = tmp(useIdxV, 9)';    % Average years of schooling
avgExpV     = tmp(useIdxV, 10)';    % Average experience (not always available)



% *** check ***
nObs = length(pwtNoV);
v_check( avgSchoolV, 'f', [1,nObs], 1, 17 );
v_check( interceptV, 'f', [1,nObs], -5, 999 );
v_check( pwtNoV, 'i', [1,nObs], 1, 160 );
v_check( yearV,  'i', [1,nObs], 1950, 2010 );
v_check( sexV,   'i', [1,nObs], 1, 3 );
v_check( avgExpV, 'f', [1,nObs], 5, 45 );


% **********  Sort into matrices  *********

nc = c2S.nCountries;
ny = length(censusYearV);
ns = length(sexCodeV);
sizeV = [nc, ns, ny];
mS.useM            = UNDEFINED .* ones(sizeV);
mS.schoolM         = UNDEFINED .* ones(sizeV);
mS.expM            = UNDEFINED .* ones(sizeV);
mS.expSqM          = UNDEFINED .* ones(sizeV);
mS.interceptM      = UNDEFINED .* ones(sizeV);
mS.avgSchoolM      = UNDEFINED .* ones(sizeV);
mS.avgExpM         = UNDEFINED .* ones(sizeV);

for i = 1 : nObs
   pwtNo = pwtNoV(i);
   sex = find( sexV(i) == sexCodeV );

   if length(sex) == 1
      % *** Valid observation ***
      % Find closest census year
      distV = abs( yearV(i) - censusYearV(:) );
      [tmp, iYr] = minidx(distV);

      % Check that this entry does not already exists
      if mS.schoolM(pwtNo, sex, iYr) ~= UNDEFINED
         warnmsg([ mfilename, ':  Duplicate entry' ]);
         keyboard;
      end

      % Drop implausible observations
      % Wage growth between ages 25 and 45
      wageGrowth = exp( expV(i) * 25  +  expSqV(i) * 25^2 ) ./ ...
                   exp( expV(i) * 5   +  expSqV(i) * 5^2 );
      if schoolV(i) > 0  &  schoolV(i) < 0.25  &  expV(i) > 0  &  ...
         wageGrowth < 5  &  wageGrowth > 0  &  expSqV(i) < 0
         % Observation is valid
         mS.useM(pwtNo, sex, iYr) = 1;
         mS.schoolM(pwtNo, sex, iYr) = schoolV(i);
         mS.expM(pwtNo, sex, iYr) = expV(i);
         mS.expSqM(pwtNo, sex, iYr) = expSqV(i);
         mS.interceptM(pwtNo, sex, iYr) = interceptV(i);
         mS.avgSchoolM(pwtNo, sex, iYr) = avgSchoolV(i);
         mS.avgExpM(pwtNo, sex, iYr) = avgExpV(i);
      end

      %disp(sprintf('i: %i   use: %i   year: %i   censusYear: %i  pwtNo: %i', ...
      %   i, mS.useM(pwtNo, sex, iYr), yearV(i), censusYearV(iYr), pwtNo ));

   elseif length(sex) > 1
      warnmsg([ mfilename, ':  Multiple matches for sex' ]);
      keyboard;
   end
end

%disp(mfilename);
%keyboard;

% *** eof ***
