function invalidV = c2_filter_english( xV, fltS, dbg );
% Find invalid observations in variable english
% IN:
%  xV          PUMS variable english
%              0: native; 1: very good; 2: good; 3: 4:
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

global c2S

invalidV = find( xV < fltS.EnglishMin  |  xV > fltS.EnglishMax );


% ********  eof  ***********
