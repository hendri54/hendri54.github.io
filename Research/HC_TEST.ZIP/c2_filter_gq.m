function invalidV = c2_filter_gq( xV, fltS, dbg );
% Find invalid observations in variable GQ
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

global puS

abort([ mfilename, ': Not updated' ]);

invalidV = find( xV < 0  |  xV > puS.notGQorInst );

% ********  eof  ***********
