function qShareV = c2_logn_quint(mu, sig);
% Compute quintile shares for a log-normal distribution
% with mean mu and std dev sig

% IN:
%  mu, sig     Mean and std deviation of log earnings

% OUT:
%  qShareV     Quintile shares.

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001
% Test:  t_c2_logn_quint

% ----------------------------------------------

if nargin ~= 2
   abort([ mfilename, ': Invalid no of arguments' ]);
end

% Find the quintile upper bounds
probV = [0.2 : 0.2 : 0.8, 0.9995];
n = length(probV);

% Pr(earn <= qUpperV) = probV
qUpperV = logninv( probV, mu, sig );

% Check
prob2V = logncdf( qUpperV, mu, sig );
dist = max(abs( probV - prob2V ));
if dist > 1e-5
   warnmsg([ mfilename, ':  Invalid qUpperV' ]);
end


% Quintile lower bounds
qLowerV = [logninv(0.0005, mu, sig), qUpperV(1:n-1)];


% Integrate over ranges
trace = 0;
toler = 1e-6;
for i = 1 : n
   qIntegV(i) = quad( 'c2_logn_expect', qLowerV(i), qUpperV(i), toler, trace, mu, sig );
end

qShareV = qIntegV ./ sum(qIntegV);


% ********  eof  **********
