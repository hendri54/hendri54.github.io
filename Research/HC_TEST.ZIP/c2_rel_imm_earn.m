function c2_rel_imm_earn(year, filterNo, dbg);
% Compute earnings of immigrants relative to
% natives by class (sex,age,education,country)

% Missing values and small cells are set to
% the average for the country as a whole

% ---------------------------------------------

global c2S UNDEFINED


% +++++++++++++++++++++++++++








% ***********  eof  ***************
