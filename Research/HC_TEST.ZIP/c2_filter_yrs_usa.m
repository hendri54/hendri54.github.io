function invalidV = c2_filter_yrs_usa( xV, fltS, dbg );
% Find invalid observations in variable YEARS IN USA
% IN:
%  xV          Recoded PUMS variable
%  fltS        Structure with filter settings

% OUT:
%  Row numbers of invalid entries

% ------------------------------------------------

invalidV = find( xV < 0  |  xV > fltS.maxYrsUS );

% ********  eof  ***********
