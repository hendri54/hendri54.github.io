function c2_source_sig(year, filterNo, dbg);
% Compute source country standard deviation of log
% earnings.
% Based on Deininger/Squire quintile ratios

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ----------------------------------------------------

global UNDEFINED c2S ds96S
nc = c2S.nCountries;


% Load DS96 quintile shares by country/year
[dsM, success] = load_ds96('quintRatio', ds96S.yearV(1), ds96S.yearV(end), dbg);
[dsQualityM, success2] = load_ds96('quality', ds96S.yearV(1), ds96S.yearV(end), dbg);
if success ~= 1  |  success2 ~= 1
   warnmsg([ mfilename, ':  Cannot load DS96 data' ]);
   keyboard;
end

% Target quintile ratios
% Retain the observations with highest quality / year closest to census year
qRatioTgV = UNDEFINED .* ones(1, nc);
for c = 1 : rows(dsM)
   % Data for this country and their qualities
   qRatioV = dsM(c,:);
   qualityV = dsQualityM(c,:);
   % Are any data valid?
   if max(qRatioV) > 1.01
      % Find highest quality data
      idxV = find( qualityV == ds96S.qualAccept  &  qRatioV > 1.01 );
      % If none exist, try second highest
      if length(idxV) < 1
         idxV = find( qualityV == ds96S.qualNN   &  qRatioV > 1.01 );
      end
      if length(idxV) > 0
         % Choose latest year.
         qRatioTgV(c) = qRatioV(idxV(end));
         if qRatioTgV(c) < 1.01
            warnmsg([ mfilename, ':  Invalid qRatioTgV(c)' ]);
            keyboard;
         end
      end
   end
end


% Find std deviations that match quintile ratios
nq = 5;
qShareM = UNDEFINED .* ones(nc, nq);
stdDevV = UNDEFINED .* ones(1, nc);

for c = 1 : nc
   if qRatioTgV(c) > 1
      % Construct quintile shares with the right qRatio
      qShareTgV(nq) = qRatioTgV(c);
      qShareTgV(1)  = 1;
      % Construct arbitrary values in between
      qShareTgV(2:nq-1) = 1;
      qShareTgV = qShareTgV ./ sum(qShareTgV);
      % This assumes that only quintile ratio is needed!
      [stdDevV(c), qShareM(c,:)] = c2_qshare_match(qShareTgV, dbg);
   end
end


% ******  Save  *******

% Source country std dev of log earnings
save2( stdDevV,   c2_class_fn(year, c2S.vSourceSig,   filterNo, dbg) );
% Quintile shares implied by vSourceSig
save2( qShareM,   c2_class_fn(year, c2S.vQuintShares, filterNo, dbg) );
% DS96 quintile ratios
save2( qRatioTgV, c2_class_fn(year, c2S.vQRatioDS,    filterNo, dbg) );

%disp(mfilename);
%keyboard;

% *********  eof  ***********
