function c2_show_earn_dist(year, filterNo, dbg);
% Show the US earnings distribution by age/sex/education
% for natives
% -------------------------------------------------------

global c2S UNDEFINED pwtS

fltS = c2_filter_settings(filterNo, dbg);

% Load earnings by class
clEarnM = load2( c2_class_fn(year, c2S.vEarnings, filterNo, dbg) );
% Load class weights
clWtM = load2( c2_class_fn(year, c2S.vWeight, filterNo, dbg) );
% Load class counts
clCntM = load2( c2_class_fn(year, c2S.vCellCnt, filterNo, dbg) );
% Source country weights
sourceWtM = load2( c2_class_fn(year, c2S.vSourceWt, filterNo, dbg) );

% Earnings per capita. Dim1 not used for natives
perCapEarnM = squeeze(clEarnM(1,:,:,:,c2S.cUSA)) ./ ...
    max(0.01, squeeze(clWtM(1,:,:,:,c2S.cUSA)));

cntM = squeeze( clCntM(1,:,:,:,c2S.cUSA) );

[n1, nSex, nAge, nS, nC] = size(clWtM);



for sex = [c2S.male, c2S.female]
   disp(' ');
   disp('------  US earnings by education / age  --------');
   disp(' ');
   if sex == c2S.male
      disp('* Males *');
   else
      disp('* Females *');
   end
   disp(' ');
   disp(['       ',  sprintf(' %6.1f', fltS.ageUpperV) ]);

   for s = 1 : nS
      disp([ sprintf(' %3.0f:  ', fltS.educUpperV(s)),  ...
         sprintf(' %6.1f', perCapEarnM(sex,:,s)./1000) ]);
   end
end



for sex = [c2S.male, c2S.female]
   disp(' ');
   disp('------  No of observations  --------');
   disp(' ');
   if sex == c2S.male
      disp('* Males *');
   else
      disp('* Females *');
   end
   disp(' ');
   disp(['       ',  sprintf(' %7.1f', fltS.ageUpperV) ]);

   for s = 1 : nS
      disp([ sprintf(' %3.0f:  ', fltS.educUpperV(s)),  ...
         sprintf(' %7i', cntM(sex,:,s)) ]);
   end
end



% ********  Show a country  ************

c = pwtS.cBrazil;
srcWtM = squeeze( sum(sourceWtM(:,:,:,:,c), 1) );
srcWtM = 100 .* srcWtM ./ sum( srcWtM(:) );

for sex = [c2S.male, c2S.female]
   disp(' ');
   disp('------  Source country weights  --------');
   disp(' ');
   if sex == c2S.male
      disp('* Males *');
   else
      disp('* Females *');
   end
   disp(' ');
   disp(['       ',  sprintf(' %7.1f', fltS.ageUpperV) ]);

   for s = 1 : nS
      disp([ sprintf(' %3.0f:  ', fltS.educUpperV(s)),  ...
         sprintf(' %7.1f', srcWtM(sex,:,s)) ]);
   end
end



disp(mfilename);
keyboard;


% *********  eof  *********
