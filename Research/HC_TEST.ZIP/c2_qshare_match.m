function [sig, qShareV] = c2_qshare_match(qShareTgV, dbg);
% Find the std deviation sig that matches quintile shares
% of a log-normal (with mean 0)
% Only uses quintile ratio. Other information in qShareTgV is ignored

% IN:
%  qShareTgV         Target quintile shares

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% -----------------------------------------------

if nargin ~= 2
   abort([ mfilename, ': Invalid no of inputs' ]);
end

% Input check
qsSum = sum( qShareTgV );
if abs(qsSum - 1) > 1e-3
   warnmsg([ mfilename, ':  qShareTgV does not sum to 1' ]);
   keyboard;
end
qShareTgV = qShareTgV ./ qsSum;

% Quintile ratio must be > 1
qRatioTg = qShareTgV(end) / qShareTgV(1);
if qRatioTg < 1.01
   warnmsg([ mfilename, ':  qRatioTg < 1.01' ]);
   keyboard;
end


optS = optimset('fzero');

[logSig, fval, exitFlag] = fzero('c2_qshare_dev', log(0.3), optS, qShareTgV);
sig = exp(logSig);

if exitFlag ~= 1
   warnmsg([ mfilename, ':  No convergence' ]);
   keyboard;
end

[dev, qShareV] = c2_qshare_dev(logSig, qShareTgV);

if abs(dev) > 1e-3
   warnmsg([ mfilename, ':  Invalid solution' ]);
   disp(dev);
   keyboard;
end


%disp(mfilename);
%keyboard;


% **********   eof  ***************
