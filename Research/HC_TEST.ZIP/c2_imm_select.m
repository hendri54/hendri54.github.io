function c2_imm_select(year, filterNo, dbg);
% Compute immigrant self-selection by country/skill/sex

% OUT:
%  selfSelectM(sex,skill,country)
%     s(c) = Ratio of immigrant to source country eta (unmeasured skills)
%     estimated from measured self-selection
%     Assumes that position in earnings distribution is the same as
%     position in schooling distribution.
%  selfSelect2M(sex,skill,country)
%     Assumes that s(c,skill) = h(j) ratio of immigrants to source country natives
%  selfSelect2SC(sex,country)
%     Average of selfSelect2M over skill types. Proxies for unmeasured selection
%     when there are multiple skills

% AUTHOR:  Lutz Hendricks
% LAST CHECKED:  3-3-2001

% ---------------------------------------------------

global UNDEFINED c2S pwtS

fltS = c2_filter_settings(filterNo, dbg);
nSkill = fltS.nSkill;
nSex = 2;


% **********  Load data  **********

% Ratio of measured skills: immigrants / src natives by (sex,skill,c)
measSkillRatioM = load2( c2_class_fn(year, c2S.vMeasSkillRatio, filterNo, dbg) );
% Same by (sex, c)
measSkillRatioSC = load2( c2_class_fn(year, c2S.vMeasSkillRatioSC, filterNo, dbg) );

% Position of immigrants in src country skill distribution
% This may be loaded from a different filter (to match Barro-Lee)
immSchoolPosM = load2( c2_class_fn(year, c2S.vImmSchoolPos, fltS.fltImmSchoolPos, dbg) );

% Std dev of log source country earnings
stdDevLogEarnV = load2( c2_class_fn(year, c2S.vSourceSig, filterNo, dbg) );

[nSex2, nS, nC] = size(measSkillRatioM);
nC = min(nC, c2S.nCountries);



% *************  Compute Immig/Avg source Earnings  ********************

selfSelectM  = UNDEFINED .* ones(nSex, nSkill, c2S.nCountries);

for c = 1 : nC
   for sex = 1 : nSex
      for skill = 1 : nSkill
         % Does country have observations?
         if immSchoolPosM(sex,skill,c) > 0  &  ...
            (stdDevLogEarnV(c) > 0)  &  (measSkillRatioM(sex,skill,c) > 0)

            % *** Assume that position in source country earnings
            % *** distribution is same as in src country school distribution
            % Find ratio immigrant to source country earnings
            % due to self-selection
            earnRatio = exp(norminv( immSchoolPosM(sex,skill,c), 0, stdDevLogEarnV(c) ));
            % Earnings ratio due to measured skills
            % measSkillRatio = immEarnM(sex,skill,c) / usSrcEarnM(sex,skill,c);
            % Ratio of unmeasured skills: immigrants/natives
            selfSelectM(sex,skill,c) = earnRatio / measSkillRatioM(sex,skill,c);
         end
      end % for skill

   end % for sex
end

selfSelect2M  = measSkillRatioM;
selfSelect2SC = measSkillRatioSC;


% No self-selection for US, of course
selfSelectM(:,:,c2S.cUSA)  = 1;
selfSelect2M(:,:,c2S.cUSA) = 1;
selfSelectSC(:,c2S.cUSA)   = 1;


% ******  Save  *******

save2( selfSelectM,   c2_class_fn(year, c2S.vSelfSelect,  filterNo, dbg) );
save2( selfSelect2M,  c2_class_fn(year, c2S.vSelfSelect2, filterNo, dbg) );
save2( selfSelect2SC, c2_class_fn(year, c2S.vSelfSelect2SC, filterNo, dbg) );

%disp(mfilename);
%keyboard;


% ***********  eof  ****************
