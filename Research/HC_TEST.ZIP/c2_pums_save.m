function c2_pums_save(xV, infoS, varNo, year, filterNo, dbg);
% Save one variable file into matlab matrix
% ---------------------------------------------

global c2S


[fPath, fn] = c2_pums_fn(year, varNo, filterNo, dbg);
save(fPath, 'xV', 'infoS');


% ********  eof  ********
