function posV = c2_distr_pos(earnMultipleV, stdDevLogEarn, dbg);
% Compute position in earnings distribution, given
% that an observation earns earnMultipleV(i) of mean earnings
% and that earnings are log-normal with std deviation stdDevLogEarn

% OUT:
%  posV        Percentile position in earnings distribution. In [0, 1]

% -----------------------------------------------------------------

global UNDEFINED

posV = UNDEFINED .* ones(size(earnMultipleV));

idxV = find( earnMultipleV > 0 );
if length(idxV) > 0
   posV(idxV) = normcdf( log(earnMultipleV(idxV)), 0, stdDevLogEarn );
end


% ********  eof  **********
