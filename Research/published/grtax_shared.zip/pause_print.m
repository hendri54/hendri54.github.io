function pause_print(doPrint)
% Pause + print graph if doPrint > 0
% Then close graph
% ----------------------------------

   if doPrint > 0.5
      ansS = questdlg('Print current figuere (no)?', 'Print Figure?', 'yes', 'no', 'no');
      if strcmp(ansS, 'yes') == 1
         for i = 1 : round(doPrint)
            print -dwin;
         end
      end
   else
      pause;
   end
   close;

% *** end function ***
