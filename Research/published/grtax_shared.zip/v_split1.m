function [v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,v16,v17,v18,v19,v20]...
= v_split1(x, vLen, dbg);
% Split vector x into sub-vectors of equal length
% ---------------------------------------
% TASK:
%  The remainder will be put into the N+1-st return vector
% IN:
%  x        vector
%  vLen     1x1. Length of output vectors
% OUT:
%  v1...    sub-vectors of given lengths.
% ---------------------------------------

% REM:
%  - a matrix can be split into its rows by first flattening it
%    [v1, v2] = v_split1( m(:)', nCols, dbg );

% ERRORS:
%  - x too short  -> WARN and return remainder only.

% TEST:
%  T_VSPLT1
% AUTHOR: Lutz Hendricks, 1995
% ---------------------------------------

% *******  CONSTANTS  *******

   global UNDEFINED
   fName = 'V_SPLIT1';
   % Max no of vectors one can return (plus one for remainder, if any)
   maxN = 19;
   xLen = length(x);
   % No of return vectors (plus reminder)
   N = fix( xLen / vLen );


% *******  INPUT CHECK  ********

   if N > maxN
      N
      maxN
      abort([ fName, ':  N > maxN' ]);
   end


% *****************  M A I N  *****************

   % *** Initialize to UNDEFINED ***
   %  This is easier and faster than using 'eval'
   v1  = UNDEFINED;
   v2  = UNDEFINED;
   v3  = UNDEFINED;
   v4  = UNDEFINED;
   v5  = UNDEFINED;
   v6  = UNDEFINED;
   v7  = UNDEFINED;
   v8  = UNDEFINED;
   v9  = UNDEFINED;
   v10  = UNDEFINED;
   v11  = UNDEFINED;
   v12  = UNDEFINED;
   v13  = UNDEFINED;
   v14  = UNDEFINED;
   v15  = UNDEFINED;
   v16  = UNDEFINED;
   v17  = UNDEFINED;
   v18  = UNDEFINED;
   v19  = UNDEFINED;
   v20  = UNDEFINED;


   % *** Case: Only remainder ***
   if N < 1
      warnmsg([ fName, ':  Returning only remainder.' ]);
      v1 = x;
      return;
   end



   % *** Regular vectors ***
   i1 = 1;
   i2 = vLen;
   for i = 1 : N
      vec = x( i1 : i2 );
      eval([ 'v', int2str(i), ' = vec;' ]);
      i1 = i1 + vLen;
      i2 = i2 + vLen;
   end


   % Set remainder.
   % Length of remainder
   remLen = rem( xLen, vLen );
   if remLen > 0
      vRem = x( N*vLen + 1 : xLen );
      eval([ 'v', int2str(N+1), ' = vRem;' ]);
   end


% *** end function ***
