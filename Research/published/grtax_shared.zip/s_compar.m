function s_compar( titleS, s1, s2, changeS )
% s_compar( titleS, s1, s2, changeS )
% Compare two scalars. One line display.
% IN:
%  changeS     what kind of change to display?  'a' = absolute; 'p' = percent
% ------------------------------------------------------------

%fmtS = '%15s:  %6.2f \t %6.2f \t (%6.2f';
fmtS = '%15s:  %6.3f \t %6.3f \t (%6.3f';

if changeS == 'a'
   fmtS = [ fmtS, ' change)' ];
   sChange = s2 - s1;
else
   fmtS = [ fmtS, ' %% change)' ];
   if s1 == s2
      sChange = 0;
   elseif abs( s1 ) > 1e-6
      sChange = (s2/s1 - 1) * 100;
   else
      % Impossible to compute percent change!
      sChange = 0;
   end
end

tmp = sprintf( fmtS, titleS, s1, s2, sChange );
disp(tmp);


% *** end function ***
