function v_check(v, dataType, vSize, minVal,maxVal);
% Check a variable against several restrictions.
% ---------------------------------------
% TASK:
%  v_check(v, dataType, vSize, minVal,maxVal);
%  This is a debugging tool similar to 'assert'
%  If a restriction is violated: Error

% IN:
%  v           variable
%  dataType    'i' = integer; 'f' = float; 's' = string
%  vSize       size of v
%  minVal      lower bound
%  maxVal      upper bound

% ---------------------------------------

% REM:
%  To omit an input set it to UNDEFINED or omit it altogether

% TEST:  t_vcheck.m

% AUTHOR: Lutz Hendricks, 1995
% ---------------------------------------

   global UNDEFINED


   % *** Default arguments ***
   if nargin < 5
      maxVal = UNDEFINED;
   end
   if nargin < 4
      minVal = UNDEFINED;
   end
   if nargin < 3
      vSize = UNDEFINED;
   end
   if nargin < 2
      dataType = UNDEFINED;
   end


% ******************  TESTS  ********************************

   if isempty(v)
      abort('v empty');
   end
   if any( isinf(v) )
      abort('Inf encountered');
   end
   if any( isnan(v) )
      abort('NaN encountered');
   end
   % Complex numbers?
   %if any( iscomplx(v) )
   if any( imag(v) ~= 0 )
      abort('Complex numbers encountered.');
   end

   % *** Data Type ***
   %  'f' imposes no restrictions; one could check that it is not string
   if dataType ~= UNDEFINED  &  dataType ~= 'f'
      if dataType == 's'
         if (~isstr(v))
            abort('v not a string');
         end
      elseif dataType == 'i'
         if any( isint(v) ~= 1 )
            abort('v not integer');
         end
      else
         abort([ fName, ':  Invalid dataType.' ]);
      end
   end

   % *** Size ***
   if vSize ~= UNDEFINED
      if any( size(v) ~= vSize )
         disp(' ');
         disp( sprintf('Size:  Soll: [%i, %i]    Ist: [%i, %i]', vSize(1), vSize(2),...
            size(v,1), size(v,2) ));
         abort('Invalid size of input');
      end
   end

   % *** Bounds ***
   if minVal ~= UNDEFINED
      if min(min(v)) < minVal
         disp( min(min(v)) );
         abort('v < minVal');
      end
   end
   if maxVal ~= UNDEFINED
      if max(max(v)) > maxVal
         disp( max(max(v)) );
         abort('v > maxVal');
      end
   end


% *** end function ***
