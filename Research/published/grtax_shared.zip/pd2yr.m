function xYr = pd2yr(xPd, yPerPd, dbg);
% Convert vector from periods to years.
% ---------------------------------------
% TASK:
%  Given a vector xPd(1:nPd). xPd(i) = x in period i
%  We want: xYr(1:nYr) such that xYr(j) = x in year j
%  We use linear interpolation between periods to find values for years.
%  Year 1 = period 1!
% NOTE:
%  Period and year are just names. Whenever the length of the period
%  has to be changed (years to quarters etc), this will work.

% IN:
%  xPd         1:nPd
%  yPerPd      years per period; may be fractional

% OUT:
%  xYr         1:nYr. nYr is determined as the max year before nPd
% ---------------------------------------

% TEST:
%  t_pd2yr

% AUTHOR: Lutz Hendricks, 1995
% ---------------------------------------

% ************  CONSTANTS  *************************************

   global UNDEFINED
   fName = 'PD2YR';
   nPd = length(xPd);
   if dbg > 5
      v_check(xPd, 'f', [1, nPd], UNDEFINED, UNDEFINED);
      v_check(yPerPd, 'f', [1,1], 0.0001, 1000);
      if nPd < 3
         abort([ fName, ':  nPd < 3' ]);
      end
   end


% ************  MAIN  ******************************************

   % Construct period values corresponding to years.
   % Max year before nPd.
   nYr = 1 +  floor( (nPd-1) * yPerPd  );
   if nYr < 1
      abort([ fName, ':  nYr < 1' ]);
   end
   yrIdx = [1, 1 + seqa(1/yPerPd, 1/yPerPd, nYr-1)];
   if yrIdx(nYr) > nPd
      abort([ fName, ':  yrIdx too high.' ]);
   end

   % Interpolate xPd values
   %  Don't forget to transpose! interp1 returns a column vector.
   xYr = interp1( 1:nPd, xPd, yrIdx, 'linear' );


% ***********  CHECK RETURN VALUES  **************

if dbg > 5
   v_check( xYr, 'f', [1,nYr], min(xPd), max(xPd) );

   if yPerPd > 1  &  nYr < nPd
      abort([ fName, ':  nYr < nPd.' ]);
   end
   if yPerPd < 1  &  nYr > nPd
      abort([ fName, ':  nYr > nPd.' ]);
   end
end

% *** end function ***
