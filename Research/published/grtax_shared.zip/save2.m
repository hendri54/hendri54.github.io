function save2(saveMat, fn)
% save2: replaces save
% ---------------------------------------
% TASK:
%   Replaces save
% IN:
%   saveMat
%       matrix to be saved
%   fn
%       filename

% REM:
%   The main idea is to make load predictable. By default, load() creates
%   and thereby destroys any variables that were used when the data were
%   saved. save2 makes this variable name predictable.
% TEST: t_load.m
% AUTHOR: Lutz Hendricks, 1993-96
% ---------------------------------------

   global UNDEFINED

   % Avoid exchanging arguments
   v_check( fn, 's', UNDEFINED, UNDEFINED, UNDEFINED );

   eval([ 'save ', fn, ' saveMat' ]);


% *** end function ***

