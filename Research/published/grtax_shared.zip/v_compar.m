function v_compar(titleS, v1, v2);
% Show two variables and their changes
% Used to show capital stock variables of two bgps
% --------------------------------------------------

   global UNCHANGED UNDEFINED

   fName = 'V_COMPAR';
   dbg = 10;
   vLen = length(v1);

   if dbg > 5
      v_check( v1, 'f', [1,vLen], UNDEFINED, UNDEFINED );
      v_check( v2, 'f', [1,vLen], UNDEFINED, UNDEFINED );
      v_check( titleS, 's', UNDEFINED, UNDEFINED, UNDEFINED );
   end

   disp(' ');
   % Format string
   fmtS = '%6s:  %6.2f';
   fmtC = ' %6s (%6.2f';
   % Format string for changes
   for i = 2 : vLen
      % Append format for another number
      fmtS = [ fmtS, ' \t %6.2f' ];
      fmtC = [ fmtC, ' \t %6.2f' ];
   end
   fmtC = [ fmtC, ')' ];

   tmp = sprintf(fmtS, titleS, v1);
   disp(tmp);
   tmp = sprintf(fmtS, ' ', v2);
   disp(tmp);

   % Display change
   vChange = zeros(1,vLen);
   for i = 1 : vLen
      if v1(i) == 0
         vChange(i) = 100;
      else
         vChange(i) = (v2(i) / v1(i) - 1) * 100;
      end
   end


   tmp = sprintf(fmtC, '%', vChange);
   disp(tmp);

% *** end function ***
