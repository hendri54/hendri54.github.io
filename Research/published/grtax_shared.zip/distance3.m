function dist = distance3(x,y, ySmall, dbg);
% Compute distance between two vectors
% ---------------------------------------
% IN:
%   two vectors or matrices of equal dimension

% OUT:
%   distance
%   for each row, compute (x-y)/mean(y)
%   distance is the max of those over all rows
%   if mean(y)<ySmall, take (x-y)/ySmall instead

% REM:

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

   global UNDEFINED

   if nargin < 4
      abort([ fName, ':  Too few input arguments.' ]);
   end

   if dbg > 5
        if any( size(x) ~= size(y) )
            size(x)
            size(y)
            abort( 'Distance3: Different lengths of inputs.' )
        end
   end


% ***********  MAIN  *************************************


   % Row means of y
   yMeanV = max( mean( y' ), ySmall );

   dist = max(max( abs(x-y) ./ (yMeanV' * ones(1,cols(y)) )));




% **********  SELF TEST  *********

if dbg > 5
   v_check( dist, 'f', [1,1], 0, UNDEFINED );
end


% *** end function ***
