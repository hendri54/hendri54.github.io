function dist = distance(x,y, dbg)
% Compute distance between two vectors
% ---------------------------------------
% IN:
%   two vectors or matrices of equal dimension
%   dbg     optional
% OUT:
%   distance
%   - if y(i)=0: |x(i)-y(i)|
%   - if abs(y(i))>0.1%: |x(i)/y(i)-1|
%   - else |x(i)-y(i)| * 10
% REM:
%   - can handle values of opposite signs

% TEST:
%
% AUTHOR: Lutz Hendricks, 1993-97
% ---------------------------------------

   smallC = 0.001;
   tinyC  = 1e-10;
   if nargin < 3
      dbg = 0;
   end

   if dbg > 10
      if any( size(x) ~= size(y) )
         size(x)
         size(y)
         abort( 'Distance: Different lengths of inputs.' )
     end
   end

   x = x(:);
   y = y(:);

   yabs = abs(y);

   if any(yabs < smallC)
      iLarge = find( yabs > smallC );
      if ~isempty(iLarge)
         distLarge = max(abs( x(iLarge) ./ y(iLarge) - 1 ));
      else
         distLarge = 0;
      end

      iSmall = find( (yabs <= smallC) & (yabs > tinyC) );
      if ~isempty(iSmall)
         distSmall = 10 .* max(abs( x(iSmall) - y(iSmall) ));
      else
         distSmall = 0;
      end

      iZero = find( yabs < tinyC );
      if ~isempty(iZero)
         distZero = max(abs( x(iZero) - y(iZero) ));
      else
         distZero = 0;
      end

      dist = max([ distLarge, distSmall, distZero ]);

   else % all large
      dist = max( abs( x./y-1 ));
   end



% *** end function ***
