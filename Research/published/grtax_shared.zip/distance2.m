function dist = distance2(x,y, ySmall, dbg);
% Compute distance between two vectors
% ---------------------------------------
% IN:
%   two vectors or matrices of equal dimension
%   ySmall  take absolute distance for smaller values
%   dbg     optional
% OUT:
%   distance
%   - if y(i)<ySmall: |x(i)-y(i)|
%   - else: |x(i)/y(i)-1|

% REM:
%   - can handle values of opposite signs
%   - same as distance.m, but does not multiply by 10
%     for small values

% TEST:
%
% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

   global UNDEFINED
   fName = 'distance2';

   if nargin < 4
      abort([ fName, ':  Too few input arguments.' ]);
   end

   if dbg > 5
        if any( size(x) ~= size(y) )
            size(x)
            size(y)
            abort( 'Distance2: Different lengths of inputs.' )
        end
   end


% ***********  MAIN  *************************************

    x = x(:);
    y = y(:);

    yabs = abs(y);

    if all(yabs > ySmall)
        dist = max( abs( x./y-1 ));
    else
       iLarge = find( yabs >= ySmall );
       if ~isempty(iLarge)
         distLarge = max(abs( x(iLarge) ./ y(iLarge) - 1 ));
       else
         distLarge = 0;
       end

       iSmall = find( yabs < ySmall );
       if ~isempty(iSmall)
         distSmall = max(abs( x(iSmall) - y(iSmall) ));
       else
         distSmall = 0;
       end

       dist = max([ distLarge, distSmall ]);
    end



% **********  SELF TEST  *********

if dbg > 5
   v_check( dist, 'f', [1,1], 0, UNDEFINED );
end


% *** end function ***
