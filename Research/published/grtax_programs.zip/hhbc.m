function [PvExpend,PvIncome] = hhbc(c,wt,x,h, r,w,tl,xDeduct,xEarn,sx,...
     onePtc, Tr, a1Pr, B1,tBequ,BTwTax, dbg);
% Check hh bc
% ---------------------------------------

% IN:
%   obvious interpretation; 1xT (length of hh life)
%   One_tw  = 1-tw; including payroll taxes and tax deductable share
%   onePtc  = 1+tc
%   a1Pr    = a1*(1+r(1))
%   Tr      = including ss benefits
%   B1      = bequest received at age tBequ
%   BTwTax  = bequest left at END of T  INCLUDING TAX

% OUT:
%   Present value of surplus, expenditure, income; discounted to date 0


% REM:
% - important to optimize this; it is called in hhiter.m

% AUTHOR: Lutz Hendricks, 1993-97
% ---------------------------------------

% ****** CONSTANTS  ******
    global bequ


% **************  Present values  ************

    Expend = onePtc.*c + x.*(1-xEarn).*(1 - sx);
    Income = Tr + netearn(w,h,wt, x,xEarn,tl,xDeduct);
    RR = cumprod( 1+r );
    PvExpend = sum( Expend ./ RR );
    PvIncome = sum( Income ./ RR ) + a1Pr / (1+r(1));

    if bequ > 0  |  B1 ~= 0  |  BTwTax ~= 0
       T = size(Tr,2);
       PvExpend = PvExpend + BTwTax/RR(T);
       if tBequ == 0
         B1value = B1;
       else
         B1value = B1/RR(tBequ);
       end
       PvIncome = PvIncome + B1value;
    end

% *** end function ***

