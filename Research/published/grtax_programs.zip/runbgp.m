function dist = runbgp(calibNo, bgpCal, bgpNo);
% Compute BGP for a particular experiment
% IN
%   calibNo     = calibration number (will be loaded)
%   bgpCal      = also part of calibration
%   bgpNo       = bgp number
% -------------------------------------------------------------

   global UNDEFINED
   dbg = 10;

   if nargin ~= 3
      disp('Usage:   runbgp(calibNo, bgpCal, bgpNo);');
      return
   end

   calWhat = 0;

   % File with initial guesses
   if 1
      inFile.calNo  = calibNo;
      inFile.calBgp = bgpCal;
      inFile.bgpNo  = bgpNo;
   else
      disp('* Using default guesses! *');
      inFile = [];
   end

   % Result file
   outFile.calNo  = calibNo;
   outFile.calBgp = bgpCal;
   outFile.bgpNo  = bgpNo;


   dist = og1bgp(inFile, outFile,calWhat, dbg);

% *** end function ***
