function table1( sTable, runThem, showThem );
% Shows table with growth effects for models linking
% OLG -> IH
% --------------------------------------------------

global UNDEFINED
dbg = 5;
if nargin ~= 3
   disp(' ');
   disp('Usage:  table1(calBgp, runThem, showThem)');
   disp(' ');
   return;
end

bgpNo = 42;

stepV  = [0,2,5,8];
%stepV  = [5,8];

if sTable == 8  | sTable == 10
   if sTable == 8
      calBgp = 5;
   else
      calBgp = 6;
   end
   calV = [640, 660, 700, 740];
elseif sTable == 9
   calBgp = 6;
   calV = [840, 860, 900, 940];
else
   calBgp = 5;
   calV   = [340, 590, 370, 400, 430, 550];
end

%calV   = [660, 860];
%calV   = [840,860,920];
%calV = [740, 940, 720, 920];
%calV = [700, 900, 720, 920, 740, 940];


% ********  RECOMPUTE RESULTS  ***********
if runThem == 1
   for stepNo = stepV
      for calibNo = calV
         calNo = calibNo + stepNo;
         dist = calibr(calNo, calBgp);
         if dist < 1.1e-2
            % Don't run the rest, unless the calibration has converged
            %runbgp(calNo, calBgp, calBgp);
            runbgp(calNo, calBgp, bgpNo);
         end
      end
   end
end


% *************  SET UP TABLE  ****************
if showThem == 1
   %stepV = [0,2,5,8,9];
   %calV  = 640;

   %calBgp = 5;
   %bgpNo  = 42;

   convDist = 1.1e-3;     % Distance required for convergence
   nCal = length(calV);
   nStep = length(stepV);
   grEffectM = zeros(nCal, nStep);

   for s = 1 : nStep
      for c = 1 : nCal
         calibNo = calV(c) + stepV(s);

         % *****  Load both bgp's  *****
         [priceS1,agS1,hhS1] = bgpload(calibNo, calBgp, calBgp, dbg);
         [priceS2,agS2,hhS2] = bgpload(calibNo, calBgp, bgpNo,  dbg);

         % *****  Make sure both have converged  *****
         if agS1.dist > convDist  |  agS2.dist > convDist
            warnmsg(sprintf( 'No convergence of %i  %i  %i:    %6f   %6f', ...
               calibNo, calBgp, bgpNo, agS1.dist, agS2.dist ));
         else
            % *****  Determine growth rate change  *****
            grEffectM(c, s) = agS2.gr - agS1.gr;
         end
      end
   end

   % ******  SHOW TABLE  *******
   disp(' ');
   disp('--- Growth effects ---');
   disp(' ');
   for c = 1 : nCal
      disp([ sprintf('%3i', calV(c)),  sprintf('%8.3f', grEffectM(c,:).*100) ]);
   end
end


% *** end function ***


