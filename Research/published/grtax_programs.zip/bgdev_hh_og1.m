function [dev, maxDev] = bgdev_hh_og1(hhS,priceS,agS,dbg);
% Deviatons for hh problem. BGP only
% ---------------------------------------
% TASK:
%   Deviatons for hh problem. BGP only!

% IN:

% OUT:
%   deviations to be set to zero

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

    global eta psi bb sig ddh popGrowth
    global B bequ tb hcAge hcInherit hAbility
    global BEQUTYPE ALTRUISTIC NONALTRUISTIC hcAltruism hSpill
    global hhLife T1 tb
    ageDiff = tb - 1;


% ***** Process inputs *****

    T = hhLife;
    phi0 = hhS.phi0;
    phiX = hhS.phiX;
    Lambda = hhS.Lambda;
    v = hhS.v;
    x = hhS.x;
    h = hhS.h;

    gr = agS.gr;
    hAvg = agS.hAvg .* gr.^(0:T-1);

    r = priceS.r;
    w = priceS.w;



% *********  DERIVED VARIABLES  *****************

   Rv = cumprod( 1 + r );
   wt = 1 - hhS.l - v;
   phi0X = phi0 / Lambda;

   phiPos = find( phiX > 0 );
   Gh = zeros(1,T);
   [tmp, tmp, tmp, Gh(phiPos)] = Gf( v(phiPos), x(phiPos), h(phiPos), hAvg(phiPos), 1 );


% ***********  LOM FOR PHI  **********************

   vChildV = zeros(1, T);
   phiXN   = zeros(1, T);
   if hcAltruism == 1
      % ** Add value of child's hc
      vChildFactor = bequ * hcInherit * (bb * popGrowth / gr^sig)^(tb-1) * phi0X;
      if hSpill.type == 1
         if hcAge == T+1
            phiXN(T) = Rv(T) * vChildFactor;
         else
            vChildV(hcAge) = Rv(hcAge) * vChildFactor;
         end
      elseif hSpill.type == 2
         weightV = zeros(1,T);
         weightV(hSpill.age1:hSpill.age2) = (hSpill.age2 - (hSpill.age1:hSpill.age2)) ./ ...
            (hSpill.age2 - hSpill.age1);
         vChildV = vChildFactor .* Rv .* weightV;
      end
   end

   phiXN(1:T-1) = ( phiX(2:T) .* (1-ddh + Gh(2:T)) + w(2:T) .* wt(2:T) + vChildV(2:T) ) ./ (1+r(2:T));
   dev_phi = distance2( phiX, phiXN, 0.01, dbg );

   dev = dev_phi;
   maxDev = max(abs( dev ));


%disp(mfilename)
%keyboard

% *** end function ***

