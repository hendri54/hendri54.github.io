function bgp_guess
% Create a file with initial guesses for a bgp
% ---------------------------------------
% TASK:
%   This can also be used to change individual variables in
%   a result file, for example, to obtain better inital guesses
%   Uses an existing file as basis
%   Adapt settings in code before use!
%   Always save to file (0,0,0)

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

dbg = 20;
global tb hcInherit h1Invest
global yPerPd iniPop popGrowth hhLife
global Tx
global ddk
ageDiff = tb - 1;

abort([ mfilename, ': Not updated' ]);


% *******************  SETTINGS  **************************

% Use a file for initial guesses?
useGuess = 1;
% If so, which file?
guessCalNo  = 161;
guessCalBgp = 5;
guessBgpNo  = 5;
% Save results under:
outFile.calNo   = 0;
outFile.calBgp  = 0;
outFile.bgpNo   = 0;




% **************  REQUIRED SETTINGS  **********************

   % Load calibration
   paraload(guessCalNo, guessCalBgp, dbg);
   % Experiment settings
   [tax0, T,T1, kDeduct,xDeduct,xEarn, taxAdj0] = bsetting(guessBgpNo, dbg);
   [tw0,tk0,TrY,GY,tc0,to0,DY,sx0,tmp,tmp,taxb0,sxx0,twx0] = taxvec(tax0);


% **************  LOAD/CONSTRUCT GUESSES  *****************

if useGuess == 1
   % *** Load initial guess ***
   [K,L,gr,pol0V, mu, phi, c, l, v, a, h, x,util,BT,phi0,valAbil,...
      vhx,ax,hx,xx,Xx,vh1Child,hT1,Lambda,dist,B1 ]...
      = bgpload(guessCalNo, guessCalBgp, guessBgpNo, dbg);
else
   % *** Use defaults ***
   h1x = 1;
   L = popsize(iniPop, popGrowth, T) .* h1x ./ 3;
   % Choose the initial guess for k to match an interest rate.
   r = 1.08 ^ yPerPd - 1;
   k = kbounds(r, r, tk0,kDeduct,ddk);
   K = L .* k;
   gr      = 1.015;
   phi     = linspace(2, 0, T);
   mu      = zeros(1, T);
   phi0    = 2;
   valAbil = phi0;

   wt = [linspace(0.5, 0.3, T1), zeros(1,T-T1)];
   x  = [linspace(0.05, 0, T1),  zeros(1,T-T1)];
   h  = multseq(h1x, 3*h1x, T);
   c1 = 0.2;
   l1 = 0.5;
   c = linspace(c1, 2*c1, T);
   l = 0.5 .* ones(1, T);
   v = linspace(0.1, 0, T);
   a = ones(1, T);

   [ tmp, Uc1 ] = ufct(c1, l1);
   [Y, MPK, MPL] = prodfct(K,L);
   r = bgprw( MPK, MPL, tk0,tw0,0,to0, kDeduct, ddk,T1,T );
   Lambda = bb * Uc1 / (1+tc0) / (1+r(1));

   pol0V = tax0;

   util = -1;

   B1 = 0;
   BT = 0;

   vhx = 0;
   ax  = 0;
   hx  = h1x;
   Xx  = 0;
   vh1Child = 1;
   hT1 = h1x;
   dist = 10;
end

Tx  = 0;
Pol = pol0V(taxAdj0);

% +++ should be loaded
priceS.r = 0.05;
priceS.w = 0.5;


% **************  MODIFY GUESSES  *************************
% Adapt this section, if desired, to improve initial guess

if 0
   disp(' ');
   disp('--- Adding bequest ---');
   disp(' ');
   B1 = c(1) * gr^ageDiff;
   BT = c(1) * gr^T;
end

if 1
   disp(' ');
   disp('--- Adding h1 investment ---');
   disp(' ');
   Tx  = 10;
   vhx = ones(1, Tx) .* 0.2;
   ax  = zeros(1, Tx);
   hx  = ones(1, Tx);
   Xx  = 1;
end

agS.C = c;
hhS = 0;


% **************  SAVE  ***********************************

bgpsave(gr, K,L, Pol, mu,phi, c, l, v, a, h, x,tax0,taxAdj0,...
BT,phi0,valAbil,vhx,ax,hx,xx,Xx,vh1Child,hT1,Lambda,dist,B1,priceS,agS,hhS, outFile, dbg);


% *** end function ***

