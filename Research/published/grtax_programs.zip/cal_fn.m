function fn = cal_fn( calNo, bgpNo );
% File names for a calibration.
% Tax and Growth model.
% IN:
%  calNo    no of calibration
%  bgpNo    no of bgp
% OUT:
%  fn       full path
% ------------------------------------------------

   global calDir
   fn = sprintf('%sc%03i_%03i', calDir, calNo, bgpNo);


% *** end function ***
