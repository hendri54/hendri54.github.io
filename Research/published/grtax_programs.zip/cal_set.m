function cal_set(calNo, dbg)
% Set exogenous parameters
% ---------------------------------------
% IN:
%  standard notation

% This should be the only routine that handles
% annual values (except for display of results)
% Does not initialize values that are calibrated!

% AUTHOR: Lutz Hendricks, 1995-97
% ---------------------------------------

   global ALTRUISTIC NONALTRUISTIC NOBEQUEST bequ
   global calH calDdh calSig sigTarget ddhTarget calEta calPsi calBeta
   global calRho
   global yPerPd gg
   global UNDEFINED
   global A aa ddk
   global psi ksi eta gg ddh zeta hExog hEndog hAbility
   global iniPop popGrowth tBequ
   global yearsOfLife hhLife tbYear iniAge hcAge tb T1
   global bb sig sigMin BEQUTYPE hcAltruism hSpill hEndowment aEndowment

   v_check( calNo, 'i', [1,1], 1, 999 );


% ***************  DEFAULTS  *******************************************

   % *** Firms ***
   A   = 1;
   aa  = 0.3;
   ddk = 0.05;

   % *** Households ***
   iniPop = 1;
   popGrowth = 1.0124;
   hEndowment = 1;      % Endowments at beginning of life
   aEndowment = 0;

   yearsOfLife = 55;
   hhLife = 55;
   tbYear = 28;         % Parent's age when child born
   iniAge = 20;
   T1     = 64;

   %bb       = 0.99;
   sigTarget      = 1.5;
   sigMin   = 1.1;
   BEQUTYPE = NOBEQUEST;
   hcAltruism   = 0;
   hSpill.type  = 1;
   hSpill.year1 = 1;             % model age of CHILD when spillover begins
   hSpill.year2 = iniAge-1;      % ... and ends  (for type 2 only)
   hSpill.hcYear = 11;           % for type 1: child's physical age at which spillover occurs

   % *** Human Capital ***
   eta  = 0.35;
   psi  = 0.35;
   ksi  = psi;
   gg   = 0;
   ddhTarget  = 0.01;

   hExog    = UNDEFINED;
   hEndog   = 1;
   hAbility = 0;

   % Investment in h1
   global etax ddhx psix ksix Tx h1Invest
   h1Invest = 0;
   etax   = 0.24;
   psix   = 0.46;
   ksix   = psix;
   ddhx   = ddhTarget;
   Tx     = 10;

   calH.calB = 1;          % B matches wage growth over life-cycle
   calH.hcInherit = 1;     % value for hcInherit, if exogenous


   % *****  Targets for calibration  *****
   global grTarget IYTarget vTarget hTarget bequTarget BxTarget
   % 1 + Growth rate target, % p.a.
   grTarget = 1.017;
   % (Investment/Output) target, % (adjusts ddk)
   IYTarget = 0.19;
   % Target for average v/(1-l)
   vTarget  = 0.07;
   % Target growth of earnings between age1 and age2: hGrowth
   hTarget.age1    = 20;
   hTarget.age2    = 45;
   hTarget.hGrowth = 1.62 * 1.16;
   hTarget.type    = 'e';  % match earnings growth


   % Bequest: ratio of flow to household net worth
   bequTarget.Flow = 0.01;
   % If not calibrated, set bequ to this value
   bequTarget.bequ = UNDEFINED;
   % How to calibrate bequ?
   bequTarget.calBequ = 2;

   % Investment in h1
   % - total growth of hx
   % - UNDEFINED -> set Bx = B
   BxTarget.hGrowth = UNDEFINED;

   % **  Calibration of bb
   % calType 0: exogenous (=calBeta.bbTarget); 1: match K/Y;
   % 2: move slowly towards bbTarget
   calBeta.calType  = 01;
   calBeta.KYTarget = 2.5;
   calBeta.bbTarget = 0.99;

   % ** Calibration of rho
   % calType: 1: match leisure share; 0: exogenous rho;
   % 2: move slowly towards target
   calRho.calType   = 0;
   calRho.rhoTarget = 0.5;
   calRho.lTarget   = 0.56;     % Target leisure share

   % ***  Move slowly or set directly?
   calSig = 0;
   calDdh = 0;
   calEta = 0;
   calPsi = 0;


% ==================  INDIVIDUAL EXPERIMENTS  ================================

if calNo == 101         % Default

elseif calNo == 102     % Match leisure share
   calRho.calType   = 1;
   calRho.lTarget   = 0.56;


% *****  ABILITY EFFECTS  ***************
elseif calNo >= 131  &  calNo <= 150
   hAbility = 1;
   gg = 1 - eta - ksi;


% *********  BEQUESTS  ***************

   elseif calNo == 151     % Bequest (calibrated)
      bequTarget.calBequ = 2;
      BEQUTYPE = ALTRUISTIC;

   elseif calNo == 152     % Full altruistic bequest
      BEQUTYPE = ALTRUISTIC;
      bequTarget.Flow = UNDEFINED;
      bequTarget.bequ = 1;
      bequTarget.calBequ = 1;

   elseif calNo == 153
      BEQUTYPE = ALTRUISTIC;
      bequTarget.Flow = 0.02;
      bequTarget.calBequ = 2;

   elseif calNo == 154     % Interaction bequest / sigma
      BEQUTYPE = ALTRUISTIC;
      bequTarget.calBequ = 2;
      sigTarget = 1.3;

   elseif calNo == 155
      BEQUTYPE = ALTRUISTIC;
      bequTarget.calBequ = 2;
      sigTarget = 1.1;
      sigMin = sigTarget;

   elseif calNo >= 161  &  calNo <= 166     % h1 investment
      BEQUTYPE = ALTRUISTIC;
      bequTarget.calBequ = 2;
      h1Invest = 1;
      BxTarget.hGrowth = UNDEFINED;
      if calNo == 162
         % Calibrate Bx to match target growth of hx
         BxTarget.hGrowth = 1.5;
      end

   % *******  Parents internalize spillover  ********
   % - main experiment is 172; others are initial guesses
   elseif calNo >= 170  &  calNo < 180
      BEQUTYPE = ALTRUISTIC;
      bequTarget.bequ = 0.6;
      bequTarget.Flow = UNDEFINED;
      hcAltruism = 1;

      if calNo == 171
         bequTarget.calBequ = 1;
         bequTarget.bequ = 0.8;
      elseif calNo == 172
         bequTarget.calBequ = 1;
         bequTarget.bequ = 1;
      elseif calNo == 175     % Calibrated bequest
         bequTarget.calBequ = 2;
         bequTarget.Flow = 0.01;
         bequTarget.bequ = UNDEFINED;

      elseif calNo == 179     % Spillover over date range
         hSpill.type = 2;
         bequTarget.calBequ = 2;
         bequTarget.Flow = 0.01;
         bequTarget.bequ = UNDEFINED;
      end



% *********  HC PRODUCTION FUNCTION  *******************
elseif calNo >= 180  &  calNo < 230
   if calNo == 180     % Higher returns to scale
      eta = 0.3;
      psi = 0.3;
      ksi = psi;

   elseif calNo == 181     % Higher returns to scale
      eta = 0.375;
      psi = 0.375;
      ksi = psi;

   elseif calNo == 182     % Lower returns to scale
      eta = 0.25;
      psi = 0.25;
      ksi = psi;

   elseif calNo == 183     % Higher returns to scale
      eta = 0.4;
      psi = 0.4;
      ksi = psi;

   elseif calNo == 184     % Higher returns to scale
      eta = 0.425;
      psi = 0.425;
      ksi = psi;

   elseif calNo == 185     % King-Rebelo: No spillver
      eta = 0.35;
      psi = 0.35;
      ksi = 1 - eta;

   elseif calNo == 186     % Lower share of goods
      eta = 0.2;
      psi = 0.5;
      ksi = psi;

   elseif calNo == 187     % High share of goods
      eta = 0.5;
      psi = 0.2;
      ksi = psi;

   elseif calNo == 191     % Higher depreciation
      ddhTarget = 0.05;

   elseif calNo == 192     % High ddk
      % Must have exogenous bb here
      calBeta.calType  = 0;
      calBeta.bbTarget = 0.99;
      ddk = 0.1;

   elseif calNo == 198     % Steeper wage profile
      hTarget.hGrowth = 2.5;

   elseif calNo == 210     % Low sigma
      sigTarget = 1.1;
      sigMin = sigTarget;

   elseif calNo == 220
      hSpill.hcYear = 1;

   elseif calNo == 221
      hSpill.hcYear = 21;

   else
      abort([ mfilename, ': Invalid calNo' ]);
   end


% ==========  BASED ON JMR  ========================
elseif calNo > 230  &  calNo < 300

   % With extreme parameters, earnings and wages are zero
   % at beginning of life
   % => Match growth of h instead
   hTarget.age1   = 20;
   hTarget.age2   = 45;
   hTarget.type   = 'h';

   % Observed:    (1-l)             v                       (1-l-v)
   wage1 = 1;     mkTime1 = 1;      v1 = 0.15 * mkTime1;    workTime1 = mkTime1 - v1;
   wage2 = 1.62;  mkTime2 = 1.16;   v2 = 0.05 * mkTime2;    workTime2 = mkTime2 - v2;
   % Back out profile for h
   h1 = wage1 * mkTime1 / workTime1;   h2 = wage2 * mkTime2 / workTime2;
   hTarget.hGrowth = h2 / h1;


   if calNo < 260
      % Ability effects
      caseNo = calNo - 230;
      hAbility = 1;
   else
      % Spillover spec
      caseNo = calNo - 260;
      hAbility = 0;
   end

   gg = 1 - eta - ksi;

   % Move slowly
   sigTarget = 1.1;
   calSig = 1;

   ddhTarget = 0.05;
   calDdh = 1;

   calBeta.calType = 1;
   calBeta.bbTarget = 0.97;
   % Exogenous rho
   calRho.rhoTarget = 0.5;
   calRho.calType = 2;

   bequTarget.calBequ = 1;
   BEQUTYPE = ALTRUISTIC;
   bequTarget.Flow = UNDEFINED;
   bequTarget.bequ = 1;



   % *** Gradually increase rho ***
   if caseNo >= 4
      calRho.rhoTarget = 1;
   end
   if caseNo >= 6
      calRho.rhoTarget = 2;
   end
%   if caseNo >= 8
%      calRho.rhoTarget = 2.5;
%   end

   if caseNo >= 10
      ddhTarget = 0.08;
   end

   if caseNo == 12
      BEQUTYPE = NOBEQUEST;
   end

   % Demographics
   if caseNo >= 20
      popGrowth = 1;                      % No population growth
      T1 = iniAge + yearsOfLife - 1;      % No retirement
   end

   % Internalized spillover
   if caseNo >= 22
      hSpill.type = 2;        % Spillover over period of time
      hcAltruism  = 1;        % Parents internalize spillover
      bequTarget.bequ = 1;
   end
   if caseNo >= 23
      hSpill.type = 1;        % Spillover at point in time
      hcAltruism  = 1;        % Parents internalize spillover
      bequTarget.bequ = 1;
   end
   if caseNo >= 24            % Hc spillover at T+1 (when children are born)
      tbYear = hhLife + 1;
      hSpill.hcYear = iniAge;
      hSpill.type = 1;
      bequTarget.bequ = 1;
   end



% ==================================================


elseif calNo == 300     % Worst case: largest growth effects (reasonable)
   sigTarget = 1.5;           % Compute for bgp=6 (inputs not deductible)
   ddhTarget = 0.05;
   BEQUTYPE = ALTRUISTIC;
   bequTarget.calBequ = 2;

elseif calNo == 301     % Worst case: largest growth effects
   sigTarget = 1.5;     % Compute for bgp=8 (inputs not deductible)
   ddhTarget = 0.05;
   bequTarget.calBequ = 2;
   BEQUTYPE = ALTRUISTIC;
   eta = 0.5;
   psi = 0.2;
   ksi = psi;
   h1Invest = 1;
   BxTarget.hGrowth = 1.5;
   hSpill.hcYear = 21;



% =============================  TRANSFORM OLG -> IH  =============================
% Changes are cumulative
elseif calNo >= 340  &  calNo <= 620
   % Move slowly
   calSig = 1;
   calDdh = 1;
   calBeta.calType = 1;
   calBeta.bbTarget = 0.97;

   %****** Main cases *******
   if calNo >= 340
      % Identical with 101
      caseNo = calNo - 340;
   end
   if calNo >= 370
      % Identical with 152
      BEQUTYPE = ALTRUISTIC;
      bequTarget.calBequ = 1;
      bequTarget.Flow = UNDEFINED;
      bequTarget.bequ = 1;
      caseNo = calNo - 370;
   end
   if calNo >= 400
      popGrowth = 1; % No population growth
      caseNo = calNo - 400;
   end
   if calNo >= 430
      T1 = iniAge + yearsOfLife - 1;     % No retirement
      caseNo = calNo - 430;
   end
   if calNo >= 460
      bequTarget.bequ = 0.5;  % only for initial guess
      hcAltruism  = 1;        % Parents internalize spillover
      hSpill.type = 2;        % Spillover over period of time
      caseNo = calNo - 460;
   end
   if calNo >= 490
      bequTarget.bequ = 0.7;  % only for initial guess
      caseNo = calNo - 490;
   end
   if calNo >= 520
      bequTarget.bequ = 0.85;
      caseNo = calNo - 520;
   end
   if calNo >= 550
      bequTarget.bequ = 1;
      caseNo = calNo - 550;
   end

   if calNo >= 580            % Hc spillover at T+1 (when children are born)
      tbYear = hhLife + 1;
      hSpill.hcYear = iniAge;
      hSpill.type = 1;
      bequTarget.bequ = 0.5;
      caseNo = calNo - 580;
   end
   if calNo >= 590
      bequTarget.bequ = 1;
      caseNo = calNo - 590;
   end

   if calNo >= 610
      calH.calB = 2;    % B matches growth rate; hcInherit exogenous = IH model
      calH.hcInherit = 1;
      caseNo = calNo - 610;
   end

   % **********  Sub Cases  **********
   % For each main case, the same versions exists (sensitivity analysis)
   if caseNo >= 1
      ddhTarget = 0.03;
   end
   if caseNo >= 2
      ddhTarget = 0.05;
   end
   if caseNo >= 3
      sigTarget = 1.3;
   end
   if caseNo >= 5
      sigTarget = 1.1;
   end
   if caseNo > 20
      abort([ mfilename, ': Invalid caseNo' ]);
   end



% =============================  TRANSFORM OLG -> IH  =============================
% =============================  FIXED RHO  =======================================
% Changes are cumulative
elseif calNo >= 640  &  calNo < 760
   % Move slowly
   calSig = 1;
   calDdh = 1;
   calBeta.calType = 1;
   calBeta.bbTarget = 0.97;
   % Exogenous rho
   calRho.rhoTarget = 0.5;
   calRho.calType = 2;


   %****** Main cases *******
   if calNo >= 640
      % Identical with 101
      caseNo = calNo - 640;
   end
   if calNo >= 660
      % Identical with 152, except for rho
      bequTarget.calBequ = 1;
      BEQUTYPE = ALTRUISTIC;
      bequTarget.Flow = UNDEFINED;
      bequTarget.bequ = 1;
      caseNo = calNo - 660;
   end
   if calNo >= 680
      popGrowth = 1; % No population growth
      T1 = iniAge + yearsOfLife - 1;     % No retirement
      caseNo = calNo - 680;
   end
   if calNo >= 700
      hcAltruism  = 1;        % Parents internalize spillover
      hSpill.type = 2;        % Spillover over period of time
      bequTarget.bequ = 1;
      caseNo = calNo - 700;
   end
   if calNo >= 720            % Hc spillover at T+1 (when children are born)
      tbYear = hhLife + 1;
      hSpill.hcYear = iniAge;
      hSpill.type = 1;
      bequTarget.bequ = 1;
      caseNo = calNo - 720;
   end
   if calNo >= 740
      calH.calB = 2;    % B matches growth rate; hcInherit exogenous = IH model
      calH.hcInherit = 1;
      caseNo = calNo - 740;
   end

   % **********  Sub Cases  **********
   % For each main case, the same versions exists (sensitivity analysis)
   if caseNo >= 1
      ddhTarget = 0.03;
   end
   if caseNo >= 2
      ddhTarget = 0.05;
   end
   if caseNo >= 3
      sigTarget = 1.3;
   end
   if caseNo >= 5
      sigTarget = 1.1;
   end
   if caseNo >= 7
      calRho.rhoTarget = 0.65;
   end
   if caseNo >= 8
      calRho.rhoTarget = 0.85;
   end
   if caseNo >= 9
      calRho.rhoTarget = 1.5;
   end
   if caseNo >= 10
      calRho.rhoTarget = 1.8;
   end
   if caseNo >= 11
      eta = 0.5;
      psi = 0.2;
      ksi = psi;
   end

   if caseNo > 20
      abort([ mfilename, ': Invalid caseNo' ]);
   end




% ==============================  ABILITY EFFECT MODEL  ===============================
elseif calNo >= 840  &  calNo < 960
   hAbility = 1;
   gg = 1 - eta - ksi;

   % Move slowly
   calSig = 1;
   calDdh = 1;
   calBeta.calType = 1;
   calBeta.bbTarget = 0.97;
   % Exogenous rho
   calRho.rhoTarget = 0.5;
   calRho.calType = 2;

   %****** Main cases *******
   if calNo >= 840
      caseNo = calNo - 840;
   end
   if calNo >= 860
      bequTarget.calBequ = 1;
      BEQUTYPE = ALTRUISTIC;
      bequTarget.Flow = UNDEFINED;
      bequTarget.bequ = 1;
      caseNo = calNo - 860;
   end
   if calNo >= 880
      popGrowth = 1;                      % No population growth
      T1 = iniAge + yearsOfLife - 1;      % No retirement
      caseNo = calNo - 880;
   end
   if calNo >= 900
      hcAltruism  = 1;        % Parents internalize spillover
      hSpill.type = 2;        % Spillover over period of time
      bequTarget.bequ = 1;
      caseNo = calNo - 900;
   end
   if calNo >= 920            % Hc spillover at T+1 (when children are born)
      tbYear = hhLife + 1;
      hSpill.hcYear = iniAge;
      hSpill.type = 1;
      bequTarget.bequ = 1;
      caseNo = calNo - 920;
   end
   if calNo >= 940
      calH.calB = 2;    % B matches growth rate; hcInherit exogenous = IH model
      calH.hcInherit = 1;
      caseNo = calNo - 940;
   end

   % **********  Sub Cases  **********
   % For each main case, the same versions exists (sensitivity analysis)
   if caseNo >= 1
      ddhTarget = 0.03;
   end
   if caseNo >= 2
      ddhTarget = 0.05;
   end
   if caseNo >= 5
      sigTarget = 1.1;
   end
   if caseNo >= 8
      calRho.rhoTarget = 0.85;
   end
   if caseNo >= 9
      calRho.rhoTarget = 1;
   end
   if caseNo >= 10
      calRho.rhoTarget = 2.5;
   end
   if caseNo >= 11
      eta = 0.5;
      psi = 0.2;
      ksi = psi;
   end
   if caseNo > 20
      abort([ mfilename, ': Invalid caseNo' ]);
   end



else
   warnmsg([ mfilename, ':  Using default parameters' ]);
end % switch



% =====================  IMPLIED PARAMETERS  =========================================

   if hAbility == 0
      zeta = 1 - ksi - eta;
   else
      zeta = 1 - ksi - eta - gg;
   end

   if bequTarget.bequ ~= UNDEFINED  &  bequTarget.calBequ == 0
      bequ = bequTarget.bequ;
   end
   if BEQUTYPE == NOBEQUEST
      bequ = 0;
      bequTarget.bequ = 0;
   end


% ****************  PERIOD FROM ANNUAL VALUES  *************************
% Up to this point everthing must be in annual values!

   T = hhLife;
   yPerPd = yearsOfLife / hhLife;

   popGrowth = popGrowth ^ yPerPd;

   calBeta.bbTarget = calBeta.bbTarget ^ yPerPd;
   if calBeta.calType == 0;
      bb = calBeta.bbTarget;
   end

   ddhTarget  = 1 - (1 - ddhTarget)^yPerPd;
   ddk  = 1 - (1 - ddk)^yPerPd;
   ddhx = 1 - (1 - ddhx)^yPerPd;

   T1    = model_age(T1);

   tb = round( tbYear / yPerPd );
   tBequ = T - tb + 1;
   Tx = round( Tx / yPerPd );

   % Parents age when spillover begins
   hSpill.age1 = hSpill.year1 - 1 + model_age(tbYear);
   % ... and ends
   hSpill.age2 = hSpill.year2 - 1 + model_age(tbYear);
   % Model age of parent at which type 1 spillover occurs
   hcAge = hSpill.hcYear - 1 + model_age(tbYear);


   % ***** Calibration Targets *********
   grTarget = grTarget ^ yPerPd;

   hTarget.age1 = model_age(hTarget.age1);
   hTarget.age2 = model_age(hTarget.age2);

   bequTarget.Flow = bequTarget.Flow * yPerPd;


   % ******  Parameters that are moved slowly  ***********
   % Do not set these parameters directly!
   if calDdh == 0
      ddh = ddhTarget;
   end
   if calSig == 0
      sig = sigTarget;
   end


% *** end function ***

