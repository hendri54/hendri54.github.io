function t_h1invest
% Test of h1invest
% Syntax only

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

% ************  CONSTANTS  *************************************

   global yearsOfLife hcInherit calNo yPerPd
   global UNCHANGED UNDEFINED

   dbg = 100;
   fName = mfilename;

   % *** Construct inputs ***
   h1x = 2;
   a1x = 3;
   Tstar = 5;
   r = 0.1;
   wx = 0.3;
   cx = 0.5;
   hAvg = linspace(1, 2, Tstar);
   dV_da1 = 3;
   dV_dh1 = 4;


   [h, a, v, x] = h1_invest(h1x, a1x, Tstar, r, wx, cx, hAvg, dV_da1, dV_dh1, dbg);

   v_check( h, 'f', [1,Tstar+1], 1e-5, UNDEFINED );
   v_check( a, 'f', [1,Tstar+1], UNDEFINED, a1x );
   v_check( v, 'f', [1,Tstar], 1e-5, UNDEFINED );
   v_check( x, 'f', [1,Tstar], 1e-5, UNDEFINED );


% *** end function ***
