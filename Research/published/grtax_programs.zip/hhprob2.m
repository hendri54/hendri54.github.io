function [c,l,v,a,h,x, c1,mu,phiX, BT,valAbil,hT1, h1Out] = ...
    hhprob2(w,r, tl,tc,Tr, h1x,a1x,B1,tBequ,tbP1, c1Ini,muIni,phiXIni,hIn,...
    hAvg,xDeduct, sx,xEarn,VPrime,bequ,BTin,vh1Child,TOLERANCE,hhOpt, ...
    h1Inv,valAbil,hAvgx,T1, dbg);
% hhprob2: Solve the hh problem, given (w,r) and bequ
% ---------------------------------------
% TASK:
%   Solve the hh problem, given (w,r).
%   ASSUME that the bequest motive is operative if bequ>0!
%   In effect, this solves the hh problem ignoring the non-negativity on
%   bequests.

% IN:       see hhprob
%  hIn      guess for h profile (or fixed profile if exogenous)
% OUT:      see hhprob

% REM:
% - note that hhprob2.m uses the input variable 'bequ', not the global
% - T: length of hh life (remaining)

% ALGORITHM:
% - if the gsw is updated too slowly or if it is raised only when dist
%   is low, the problem takes very long to converge.

% CHANGE:
% - try to determine early if BT will be < 0. Then return an unusable solu-
%   tion.
% - perhaps h should not be updated at all! Idea: Solve conditional on h to stabilize
%   algorithm.
% - not updated for exogenous h

% AUTHOR: Lutz Hendricks, 1995-97
% ---------------------------------------

   global UNDEFINED rho sig bb ddh
   global h1Invest hAbility
   global ALTRUISTIC NONALTRUISTIC BEQUTYPE NOBEQUEST
   v_check( dbg, 'i', [1,1], 0, UNDEFINED );

   updateBT = 01;    % Update BT or take as given?

   % Default return values
   xx  = 0;
   vhx = 0;


% ********   ALGORITHM SETTINGS   **************************

   gsw = 0.05;
   % For some reason, the algorithm is much more stable when miniter not close to 1
   hEndog = 1;
   MINITER = 50;
   MAXITER = 51;

   % Gauss Seidel weight
   % Weight for mu
   maxMuGSweight = 0.3;
   muGSweight    = 2*gsw;

   RoundoffTol = 1e-6;
   chngUp = 1.2;
   chngDn = 0.8;



% ************************  INPUT CHECK  *********************

   T = size(tl,2);
   Tidx = 1:T;
   tcP1 = 1 + tc;
   r1   = 1 + r;

   if dbg > 5
      v_check( c1Ini, 'f', [1,1], 1e-7, UNDEFINED );
      v_check( h1x,   'f', [1,1], 1e-7, UNDEFINED );
   end


   % ******  INVESTMENT IN H1  *******
   % ** Suffix 'x' indicates variables for period of investment in h1
   h = hIn;
   if h1Invest == 0
       a1 = a1x;
       h1 = h1x;
       % Make sure hIn is consistent with h1:
       if h(1) ~= h1
          h = h ./ h(1) .* h1;
       end
       ax = 0;
       hx = h1x;
   end

   % *********  IS HC ENDOGENOUS?  ***********
   if hEndog == 0
       v = zeros(1,T);
       x = zeros(1,T);
       hT1 = 0;
       %disp('HHProb2: h exogenous')
   end



% ***********************  ITERATION OVER HH PROBLEM   ********************

   if hAbility == 1
       abil = h1;
   else
       abil = 1;
   end
   c1   = c1Ini;
   mu   = muIni;
   phiX = phiXIni;
   BT = BTin;
   hN = h;

   iter = 0;
   done = 0;
   oldDist = 1e20;
   bDist = 0;
   h1Dist = 0;
   dist_valAbil = 0;

   dV_da1 = h1Inv.dV_da1;
   dV_dh1 = h1Inv.dV_dh1;


while done == 0;
%---------------------------------------------------

   iter = iter + 1;

   % ********  a1,h1  *********
   if h1Invest == 1
      [hx, ax, vhx, xx] = h1_invest(h1x, a1x, h1Inv.Tstar, h1Inv.rx, h1Inv.wx, h1Inv.cx, ...
         hAvgx, dV_da1, dV_dh1, dbg);
      a1 = ax(h1Inv.Tstar+1);
      h1 = hx(h1Inv.Tstar+1);
      %[a1,h1, ax,hx, xx,vhx] = hhstocks(a1x,h1x,h1x,phi0+valAbil,Rx,hAvgx, wx,sxx, dbg);
      h = h ./ h(1) .* h1;
   end

   %if hEndog == 1
      [c,l,v,hN,x, c1N, muN, phiXN,BTN,dV_da1N,dV_dh1N,valAbilN,hT1]...
          = hhiter(Tr, c1, w, r,tl,xEarn,xDeduct,sx,tcP1, mu,phiX, h,a1,abil,B1, ...
          tBequ,tbP1, hAvg,VPrime,bequ,BTin,vh1Child,dV_da1,T, dbg);
   %else
   %   abort([ mfilename, ': Not updated' ]);
   %   [c,l, c1N, muN, BTN,LambdaN] = hhiter3(Tr, c1, w, r,tl,tcP1, 0,...
   %        mu,h,a1,B1,tBequ,tbP1, hAvg,VPrime,bequ,BTin,T, dbg);
   %   phiXN = phiX;
   %   dV_dh1N = phiX(1) / LambdaN * (1+r(1));
   %end


   % *******  Distance  ***********

   dVdist = max(abs( [dV_dh1N, dV_da1N] ./ [dV_dh1, dV_da1] - 1 ));
   cDist  = (c1N/c1 - 1);
   dist_h = distance(h, hN, dbg);

   % ignore the negative components of muN when computing dist
   % The correct scale here is w b/c mu is added to it
   muDist = max(abs( (max(muN, 0) - mu) ./ w ));

   phiDist = max(abs( (phiXN - phiX) ./ mean(phiX) ));
   if h1Invest == 1
      dist_valAbil = distance(valAbilN, valAbil);
   end

   if updateBT == 0
      BTN = BT;
   end
   if bequ > 0
      bDist = distance2(BTN,BT, 0.01, dbg);
   end

   distV = [cDist,muDist,phiDist,bDist,h1Dist,    dVdist,dist_h,dist_valAbil];
   dist  = max(abs( distV ));

   if  dist < TOLERANCE;
      if iter > MINITER
          done = 1;
      end
   elseif  iter > MAXITER
      done = 2;
   end


   % *************  show  ******************************
   if 0
      if rem(iter, 300) == 0    &  dbg == 222
         disp('----- HH ----------');
         disp([ sprintf('  hhIter: %3i', iter), sprintf( '    %6f', [dist_h, muDist, phiDist, bDist] ) ]);
         disp(sprintf('  h(25):  %6.3f -> %6.3f      BT: %6.3f -> %6.3f', ...
            h(25), hN(25),  BT, BTN ));
         disp(sprintf('  phiX(1): %6.3f -> %6.3f',  phiX(1), phiXN(1) ));
      end
   end


   % *************  UPDATING  *******************************************
   if 1
      if dist < 0.001
         gsw = 0.2;
      elseif dist < 0.01
         gsw = 0.2;
      elseif dist < 0.1
         gsw = 0.15;
      elseif dist < 0.3
         gsw = 0.1;
      else
         gsw = 0.05;
      end
   end


   dV_dh1  = update(dV_dh1N, dV_dh1, gsw, chngUp,chngDn);
   dV_da1  = update(dV_da1N, dV_da1, gsw, chngUp,chngDn);

   c1 = update(c1N, c1, gsw,chngUp,chngDn);
   h  = update(hN,  h,  gsw,chngUp,chngDn);

   % Fast updating: not an input to hh problem
   BT = update(BTN, BT, 0.2, 1.2, 0.8);

   phiXN = phiXN .* (phiXN > RoundoffTol);
   phiX = gsw * phiXN + (1-gsw) * phiX;
   phiX = phiX .* (phiX > RoundoffTol);
   if any(iscomplx(phiX))
      abort('Complex phiX')
   end
   valAbil = update(valAbilN, valAbil, gsw, chngUp, chngDn);

   muGSweight = min(2*gsw, maxMuGSweight);
   mu = update(muN, mu, muGSweight,chngUp,chngDn);
   % prevent mu* from becoming negative
   mu = max( mu, 0 );

end  % while %
% ------------------------------------------------------


%if done == 2
%   [tmp, tmp, maxCol] = maxidx( distV );
%   disp(sprintf( '%s: terminal distance (%i) = %f', mfilename, maxCol, dist));
%end


% *******  Compute asset holdings  *********

wtime = 1 - l - v;
[a, sT] = hhassets(c,wtime,h,x,  h1,a1, w, r, tl,tc, Tr,xDeduct,xEarn,...
    sx, B1,tBequ+1,BT*tbP1);

% Check if terminal savings are zero
% Scale this to get a relative deviation
if dbg > 5  &  abs(sT/c(T)) > TOLERANCE  &  done == 1
    tmp = sprintf('Terminal savings nonzero: %f', sT);
    disp(tmp);
end



% ***************************  CHECK SOLUTION  **********************

if (done==1  &  dbg > 5)
   % Change to reflect new inputs; separate into another function!
   % drop: ssi; all inputs relating to h1investment
   % Must call hhdev with the same BT as the hh problem (hhiter)!
   [dev, maxDev] = hhdev(c,l,v,h,x,  h1,a1,abil, w, r, tl,tc, Tr, mu,phiX,hAvg,...
      xDeduct,xEarn,sx, B1,tBequ,BT,tbP1,dV_da1,VPrime,vh1Child,dV_dh1,hEndog,dbg);

   if  maxDev > 10 * TOLERANCE
      disp([ mfilename, ' - Max. deviation exceeds tolerance: ', num2str(maxDev)]);
      [drow,dcol] = maxelem(abs(dev));
      disp(sprintf('Max. dev. in row %2i, column %2i', drow,dcol));
   elseif dbg > 2
      disp([ 'HHDev: ', num2str(maxDev) ]);
   end

   % Check investment in h1
   if h1Invest == 1
      maxDev = hhdev_h1(ax, hx, vhx, xx, h1Inv.wx, h1Inv.cx, hAvgx, h1Inv.rx, dV_da1, dV_dh1, a1, h1);
      if maxDev > 10 * TOLERANCE
         disp(sprintf( '%s: hhdev in h1: %f', mfilename, maxDev ));
      end
   end

   if dbg > 10
      % ** Check budget constraint
      [PvExpend,PvIncome] = hhbc(c,wtime,x,h, r,w,tl,xDeduct,xEarn,sx,...
         1+tc, Tr, a1*(1+r(1)), B1,tBequ,BT*tbP1, dbg);
      if distance(PvExpend, PvIncome) > 10*TOLERANCE
         disp('HHProb2: hhbc violated.')
         tmp = sprintf('PvExpend: %7.3f    PvIncome: %7.3f', ...
             PvExpend, PvIncome);
         disp(tmp)
         disp(' ')
      end
   end

   if 0
      % ** Check h(t+1) equation
      G = gf( v, x, h, hAvg, abil );
      dev = h(2:T) - (1-ddh).*h(1:T-1) - G(1:T-1);
      if max(max(abs(dev))) > 1e-4
         warnmsg('h(t+1) equation violated')
         dev
      end
   end
end


% ********  RETURN VALUES  **********

% Investment in h1 variables
h1Out.dV_da1 = dV_da1;
h1Out.dV_dh1 = dV_dh1;
h1Out.ax     = ax;
h1Out.vhx    = vhx;
h1Out.hx     = hx;
h1Out.xx     = xx;


if dbg > 5
   disp(sprintf( 'hhprob2:  %i  iterations    dist: %f', iter, dist ));
end

%if dbg == 222;
%   disp(mfilename)
%   keyboard
%end


% *** end function ***

