function parasave(cNo, bgpNo)
% Save calibrated globals
% ---------------------------------------
% IN:
%  cNo     no of file

% AUTHOR: Lutz Hendricks, 1993-97
% ---------------------------------------

% *** GLOBALS ***

   global rho psi ksi eta gg B hcInherit ddh ddk sig zeta bequ bb
   global aa A
   % Demographics
   global hcAltruism BEQUTYPE yearsOfLife iniAge popGrowth tb hcAge popGrowth hhLife
   global yPerPd
   global Bx etax psix ksix ddhx
   global hfCalNo hfExpNo hExog

   v_check( cNo, 'i', [1,1], 0, 9999 );


% *** SAVE ***

   fn1 = cal_fn(cNo, bgpNo);

   xHh   = [rho, bb, sig, bequ, BEQUTYPE, hcAltruism];
   xFirm = [A, aa, ddk];
   xHc   = [B, psi, ksi, eta, zeta, gg, hcInherit, ddh];
   xDem  = [yearsOfLife, iniAge, popGrowth, tb, hcAge, hhLife, yPerPd];
   xHc1  = [Bx,etax,ddhx,0,psix,ksix];
   xMisc = [hfCalNo,hfExpNo];

   eval([ 'save ', fn1, '  xHh xFirm xHc xDem xHc1 xMisc hExog' ]);


% *** end function ***

