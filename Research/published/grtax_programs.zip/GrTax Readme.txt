Readme for Program Files: Taxation and Long-Run Growth
by Lutz Hendricks
------------------------------------------------------

The Matlab M-files are provided in two zip files:
- GrTax programs.zip        Main program files
- GrTax shared.zip          Shared general purpose routines

It is important that all files reside in the directories
specified in og1ini.m

Documentation is provided in the Technical Appendix
available from the author's home page
(http://www.public.asu.edu/~hendrick)



% *** end file ***
