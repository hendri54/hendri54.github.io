function paraload(fNo, bgpNo, dbg)
% Load calibrated globals
% ---------------------------------------
% IN:
%  fNo      no of file

% This only loads calibrated parameters, not the exogenous
% ones set in cal_set
% To work, this must call cal_set before and after loading
% the parameters
% The first call determines dimensions of variables to be
% loaded. The second call ensures that none of the exogenous
% parameters were overwritten.

% AUTHOR: Lutz Hendricks, 1995-97
% ---------------------------------------

% *** GLOBALS ***

   global rho psi ksi eta gg B hcInherit ddh sig ddk zeta
   global bequ BEQUTYPE hcAltruism aa A
   global yearsOfLife iniAge tb hcAge popGrowth yPerPd hhLife
   global tb hcAge popGrowth bb
   global Bx etax ddhx psix ksix
   global hfCalNo hfExpNo hExog
   global calNo

   v_check( fNo, 'i', [1,1], 0, 999 );
   if nargin < 3
      dbg = 0;
   end

   fn1 = cal_fn(fNo, bgpNo);
   calNo = fNo;

   % Set exogenous parameters
   cal_set(fNo, dbg);


% ************  LOAD  ************

   disp(' ')
   disp([ 'Setting calibration ', int2str(fNo) ]);
   disp([ 'Loading: ', fn1 ]);
   eval([ 'load ', fn1 ]);

   [rho, bb, sig, bequ, BEQUTYPE, hcAltruism] = v_split1(xHh, 1, dbg);
   [A, aa, ddk] = v_split1(xFirm, 1, dbg);
   [B, psi, ksi, eta, zeta, gg, hcInherit, ddh] = v_split1(xHc, 1, dbg);
   [yearsOfLife, iniAge, popGrowth, tb, hcAge, hhLife, yPerPd] = v_split1(xDem, 1, dbg);
   [Bx,etax,ddhx,tmp,psix,ksix] = v_split1(xHc1, 1, dbg);
   [hfCalNo,hfExpNo] = v_split1(xMisc, 1, dbg);

   % Make sure exogenous parameters were not changed
   cal_set(fNo, dbg);

   parachk;

% *** end function ***

