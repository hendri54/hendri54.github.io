function [K,L,U,grAnn,C,pol0,h,rAnn,wNet,H] = bgpchar2(calNoIn,calBgp,bgpNo, dbg);
% Compute characteristics of a bgp
% ---------------------------------------
%  Assumes that calibration has been loaded
% IN:
%   bgpNo
% OUT:
%   U       utility of date 1 hh
%   C       aggregate C
%   polV    policy vector in standard format
%   rAnn    net annual interest rate
%   wNet    net wage (before retirement)
%   grAnn   annual per capita gr
%   H       aggregate stock of hc (full utilization; incl retired!)


% AUTHOR: Lutz Hendricks, 1994-97
% ---------------------------------------

% *** GLOBALS ***

global UNDEFINED
global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
global yearsOfLife iniAge iniPop hhLife yPerPd T1
global hcInherit tb hcAge popGrowth
global ddk bb bequ
T = hhLife;

abort([ mfilename, ': Not updated' ]);

v_check( dbg, 'i', [1,1], 0, UNDEFINED );


% ********  Load  ********

    [K,L,gr,pol0, mu,phi, c, l, v, a, h, x, util,BT, phi0,...
    ax,hx,xx ] = bgpload(calNoIn, calBgp, bgpNo, dbg);
    pol0 = pol0';

    [tax0, kDeduct,xDeduct,xEarn, taxAdj0] = bsetting(bgpNo, dbg);
    [tw,tk,TrY,GY,tc,to,DY,sx,ts,RR,taxb,ssx,twx] = taxvec(pol0);


% *************  COMPUTATIONS  ***********

    if hx(1) == 0
        hx = h(1);
    end
    T = hhLife;


    % *** Growth rate ***
    gr = grrate(h, hx, dbg);
    grAnn = gr ^ (1/yPerPd);

    % Aggregate consumption at date 1
    C = aggregx(iniPop, popGrowth, gr, c);

    % Aggregate stock of hc at date 1
    % - measured as amount of hc available if all work full time (full utilization)
    % - this includes hc of the retired!
    H = aggregx(iniPop, popGrowth, gr, h);


    % *** Annual interest rate ***

    [ Y, MPK, MPL ] = prodfct(K,L);
    [rV,w, tl] = bgprw( MPK, MPL, tk,tw,ts,to, kDeduct, ddk,T1,T );
    r = rV(1);
    rAnn = (1+r)^(1/yPerPd) - 1;
    wNet = w(1);


    % ****  U  *****
    U = ulife(c,l,bb);
    if bequ > 0
        warnmsg('BgpChar2: Utility of bequest not computed')
    end


% *** end function ***
