function [dev, maxDev] = hhdev(c,l,v,h,x,  h1,a1,abil, w, r, tl,tc, Tr, mu,phiX,hAvg,...
    xDeduct,xEarn,sx, B1,tBequ,BT,tbP1,dV_da1,VPrime, vh1Child,phi0,switches,dbg);
% Deviatons for hh problem. BGP only
% ---------------------------------------
% TASK:
%   Deviatons for hh problem
%   h1 investment is checked in hhdev_h1
%   Bequest condition is checked in bgpchk

% IN:
%   c(t), l(t) for all t
%   x(t), v(t), h(t) for all t
%   h1, a1  = initial hc and asset holdings
%   abil    = ability parameter in G()
%   w, r    = net of tax factor prices
%   tl      = labor tax rate; including payroll taxes
%   Tr      = lump-sum transfers
%   mu      = mu * R / lambda
%   dV_da1  = derivative of value function
%   switches
%     (1) h endogenous/exog (1 or 0)?
%   Other inputs as in hhprob2

% OUT:
%   deviations to be set to zero

% CHANGE:
% - make completely independent of utility function
% AUTHOR: Lutz Hendricks, 1993-97
% ---------------------------------------

    global theta rho sig eta psi bb ddh popGrowth
    global ksi gg nu B bequ tb hcAge hcInherit
    global BEQUTYPE ALTRUISTIC NONALTRUISTIC hcAltruism hSpill
    % Everything smaller will be considered zero:
    RoundoffTol = 1e-4;
    ageDiff = tb - 1;


% ***** Process inputs *****

    T = size(c,2);
    hEndog = switches(1);

    if  any( [l,v,x,c] < 0 )
       warnmsg('Invalid inputs to HHDEV')
    end


% *****  AUXILIARY VARIABLES  ******

    T1idx = 1:T-1;
    T2idx = 2:T;
    % Discounts even date 1
    Ri   = cumprod(1+r);
    bbi  = seqm(bb, bb, T);
    tcP1 = 1 + tc;
    % ** Private cost of a unit of x
    cx2 = x_cost(tl, sx, xEarn, xDeduct);
    if any( cx2 < 0 )
       warnmsg('HhDev: Negative cx2')
    end

    % ** Truncate everything with too small x,v to avoid rounding errors
    xvPos = (x > RoundoffTol) .* (v > RoundoffTol);
    v = v .* xvPos;
    x = x .* xvPos;
    wt = 1 - l - v;
    % Avoid rounding errors:
    wt = wt .* ( abs(wt) > RoundoffTol );
    if  any( wt < 0 )
        warnmsg(sprintf( 'wt>=0 violated: %f', min(wt) ));
    end


% *********  check MULTIPLIERS  ***********************

    % mu* must be >=0 and (mu * wt = 0)
    if  any( mu<0 )
        warnmsg(sprintf( 'mu>=0 violated: %f', min(mu) ));
    end

    if  any( abs(mu.*wt) > RoundoffTol )
        disp( max( abs( mu .* wt )) )
        warnmsg('mu * wt = 0  violated')
    end

    % ** Date of last work
    lastWork = max( find( wt > 0 ) );
    wtIdx = 1:lastWork;

    % ** If work after t, then phiX(t) > 0  or  hc bequest
    if hEndog == 1
      for t = 1 : T-1
        if lastWork > t  &  phiX(t) <= 0
            disp(sprintf( 'phiX(%i) <= 0: %5.3f', t, phiX(t) ));
        elseif lastWork <= t  &  phiX(t) > RoundoffTol  &  vh1Child <= 0
            disp(sprintf( 'phiX(%i) > 0: %5.3f', t, phiX(t) ));
        end
      end
    end


% ===========================  CHECK  FOC  ====================================

    xOv = zeros(1,T);
    G  = zeros(1,T);
    Gh = zeros(1,T);
    Gv = zeros(1,T);
    Gx = zeros(1,T);
    Gz = Gx;

    % Ages at which investment in h takes place
    invIdx = find( (x.*v) > 0 );
    [ G(invIdx), Gv(invIdx), Gx(invIdx), Gh(invIdx), Gz(invIdx)] = ...
      gf( v(invIdx), x(invIdx), h(invIdx), hAvg(invIdx), abil );
    xOv(invIdx)  = x(invIdx) ./ v(invIdx);
    wstar = w.*h + mu;

    [ U, Uc, Ul ] = ufct( c, l );

    % **************  c, l  *******************

    devEE = max(abs(Uc./Ul .*wstar./tcP1 - 1));

    % **  EULER EQUATION

    dev = bb.*(1+r(T2idx)) .* Uc(T2idx) .* ...
        tcP1(T1idx)./tcP1(T2idx) ./ Uc(T1idx) - 1;
    devEE2 = max(abs( dev ));

    % Check utility function
    devUfct = max(abs(Ul ./ Uc - (c./l) .* rho));

    tmp = rho .* tcP1 ./ wstar;
    devUfct2 = max(abs(c.^(rho*(1-sig)-sig) ./ Uc .* tmp.^(rho*(1-sig)) - 1));

    % ** FOC for c and compuation of Lambda (untransformed, not lambda/R)
    Lambda = dV_da1;
    devLambda = max(abs( (bbi.*Uc./tcP1) ./ Lambda.*Ri - 1 ));



    % ********  x, v  ***********

    dev6 = max(abs( wstar(invIdx)./cx2(invIdx) .* eta./psi ./ xOv(invIdx) - 1 ));
    dev7 = max(abs( Gv(invIdx) ./ Gx(invIdx) ./ (wstar(invIdx)./cx2(invIdx)) - 1 ));
    dev8 = max(abs( Gv(invIdx) .* phiX(invIdx) ./ wstar(invIdx) - 1 ));


   % *******  LOM for phiX  **********
   % ** This is the FOC for h(t). It exists only for t=2...T
   % ** The case of hSpill.type == 2 is checked in bgpchk
   dev = zeros(1,T);
   if hEndog == 1
      if hSpill.type == 1  |  hcAltruism == 0
        for t = T : -1 : 2
           RHS = phiX(t).*( (1-ddh) + Gh(t) ) + w(t).*wt(t);
           if t == hcAge  &  hcAltruism == 1  &  hSpill.type == 1
              vh1Factor = vh1Child * Ri(hcAge);
              RHS = RHS + vh1Factor;
           end
           dev(t) = phiX(t-1) .* (1+r(t)) - RHS;
        end
      end
      devH(1) = max(abs( dev ));

      devH(2) = max(abs([ (h(T2idx) - ( (1-ddh).*h(T1idx) + G(T1idx) )), 0 ] .* xvPos));
   end


   % ** Budget constraint
   [PvExpend,PvIncome] = hhbc(c,wt,x,h, r,w,tl,xDeduct,xEarn,sx, tcP1,...
       Tr, a1*(1+r(1)), B1,tBequ,BT*tbP1, dbg );
   dev10 = PvExpend-PvIncome;


   dev = [ devEE, devEE2, devUfct, devUfct2, devLambda, dev6,dev7,dev8, devH, dev10 ];
   maxDev = max(abs( dev ));


%disp(mfilename)
%keyboard

% *** end function ***

