bgp1 = 6;
bgp2 = 42;

calNoV = [649, 729, 928, 929, 842, 845, 848, 922, 925, 642, 645, 648];
n = length(calNoV);

for i = 1 : n;
   calNo = calNoV(i);
   calibr( calNo, bgp1 );
   runbgp( calNo, bgp1, bgp2 );
end


% *** end function ***


