function hhsolve( dbg );
% Solve hh problem. No bequests, social security
% --------------------------------------
% TASK:
%  Solve the hh problem (partial analysis)
%  Load guesses from file
% IN:
%
% OUT:
%   values that can be used as initial guesses for the next run
% METHOD:

% AUTHOR: Lutz Hendricks, 1996
% ---------------------------------------


% *** GLOBALS ***

global bb sig rho bequ hExog
global A aa ddk
global B psi ddh eta zeta ksi
global popGrowth tb hcInherit yearsOfLife
global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
global tcAdjustsG toAdjustsG
% ** h1 Investment
global Bx etax psix ddhx
% ** Bequests
global BEQUTYPE ALTRUISTIC NONALTRUISTIC

% ** Globals for initial guesses
global phiG muG c1G phi0G valAbilG hInG
global hfCalNo hfExpNo

global outDir


% *******  SWITCHES  ****************************

   % Change w and/or r?
   changeW = 1;
   changeR = 0;

   % ** Effect of slope of h profile **
   Bsaved = B;
   if 1
      disp('** Adjusting B **');
      B = 0.7;
   end


% *******  INPUT CHECK  *************************

%    diaryon([ outDir, 'hhsolve' ]);
    disp(' ')
    disp('--- HHSOLVE: Start ---------------------------------');

   if nargin < 1
      dbg = 10;
   end

   if 1-eta-psi < 0.14
        abort('Invalid calibration')
   end

   if hfCalNo > 0  |  hfExpNo > 0
      disp('* h EXOGENOUS *');
      hEndog = 0;
      %hProfile = hprload(hfCalNo, hfExpNo);
      hProfile = hExog;
   else
      hEndog = 1;
      hProfile = 0;
   end


% ******** CONSTANTS  ************************

   % Plot styles
   style1 = 'yo';
   style2 = 'go';

    TOLERANCE = 1e-5;

    T   = 20;
    T1  = 15;
    hc1 = 1;
    a1  = 0;
    iniPop = 1;

    tw0     = 0.2;
    tk0     = 0.375;
    tc0     = 0.092;
    to0     = 0.25;
    sx0     = 0;
    ts0     = 0.12;
    RR0     = 1.1;
    taxb0   = 0.1;

    kDeduct = 1;
    xDeduct = 0;
    xEarn   = 0;

    if 0
       disp('** No social security **');
       ts0 = 0;
       to0 = 0;
    end


% ****************  INITIAL GUESSES  ******************
% Load these +++

    if isempty(c1G) | isempty(phiG) | isempty(muG)
        disp('T_HhPr2: Using default guesses');
        c1Ini = 0.1;
        muIni = [zeros(1,T1), 0.1.*ones(1,T-T1)];
        phiIni= linspace(1,0,T);
        hIn   = hc1 .* ones(1, T);
    else
        % Use inputs as guesses
        muIni   = muG;
        phiIni  = phiG;
        c1Ini   = c1G;
        phi0    = phi0G;
        valAbil = valAbilG;
        hIn     = hInG;
    end

% *******************   SWITCHES   **************************

    exper = 0;

    yPerPd = yearsOfLife / T;
    ageDiff = tb-1;
    % Bequest is received at BEGINNING of:
    tBequ  = T - tb + 1;

    % Tolerance for hh problem
    hhProbTol = 1e-5;

    % ** Max changes of updated variables
    chngUp = 1.2;
    chngDn = 0.8;
    % ** Max change of new guesses
    chngUpN = 4;
    chngDnN = 1/4;


% *******************  CONSTANTS  ***************************

    % ** Is there social security?
    if  ts0==0 & RR0==0
        NoSocialSec = 1;
    else
        NoSocialSec = 0;
    end




% *********************  POLICY VARIABLES  *************************

    tc = ones(1,T) .* tc0;
    tw = ones(1,T) .* tw0;
    tk = ones(1,T) .* tk0;
    ts = [ones(1,T1).*ts0, zeros(1,T-T1)];
    to = [zeros(1,T1), ones(1,T-T1) .* to0];
    tk = ones(1,T) .* tk0;

    Tr = 0.08 .* ones(1,T);

    SSI = zeros(1,T);


   % *********  BEQUEST  *********

     if bequ > 0
        B1 = 0.62;
        VPrime = 1.3;
    else
        B1 = 0;
        VPrime = 0;
    end



% ***************************  LOOP OVER INPUTS  ***************************

   % Begin with factor prices computed from K/L along bgp:
   k = 0.339;
   L = 1;
   K = k * L;
   [ Y, MPK, MPL ] = prodfct(K,L);
   % Lifecycle profiles of factor prices (1xT)
   [rBase,wBase, tl] = bgprw( MPK, MPL, tk0,tw0,ts0,to0, kDeduct, ddk,T1,T );

   % Percent changes in r or w to be tried
   rwChange = [0, 0.1];

   rChange = rwChange .* changeR;
   wChange = rwChange .* changeW;

   % No of experiments
   nExper = length( rwChange );

   % ** Storage for results
   %  each experiment is a row
   aM = zeros(nExper, T);
   hM = zeros(nExper, T);


for rCase = 1 : length( rChange )


   % ********************  PRICES  *****************************
   w = wBase .* (1 + wChange(rCase));
   r = rBase .* (1 + rChange(rCase));


   % ********  INITIAL GUESSES  *********

   hAvg = seqm(1, 1.05, T);

   % Is there a period of investment in h1?
   % (Yes if age1 > 1)
    age1  = 0;
    if age1 > 1
        hAvgx = seqm(0.9, 1.02, age1-1);
        Rx = 1 + r(1:age1);
        wx = seqa(0.3,0.02,age1-1);
        sxx = seqa(0.1,0.02,age1-1);
        if isempty(phi0G)
            phi0 = phiIni(1) * 1.1;
            valAbil = phi0;
        else
            phi0 = phi0G;
            valAbil = phi0;
        end
    else
        hAvgx = 0;
        Rx = 0;
        phi0 = 0;
        valAbil = 0;
        wx = 0;
        sxx = 0;
    end


     % *********** solve hh problem  *************

     disp('--- Inputs hh problem ---')
     tmp = sprintf('w: %7.3f .. %7.3f    r: %7.3f', w(1), w(T), r(1));
     disp(tmp);


   hhOpt = UNDEFINED .* ones(1,7);
   hhOpt(5) = 50;
   hhOpt(7) = hEndog;

   [c, l, v, a, h, x, c1, mu, phi, BT, Lambda,phi0,valAbil,ax,hx,xx,vhx] = ...
   hhprob(w, r, tl,tc,SSI,Tr, hc1,a1,B1,tBequ,1+taxb0, c1Ini,...
      muIni,phiIni,hProfile, hIn,hAvg,xDeduct, sx0,xEarn,VPrime,2,0,...
      hhProbTol, hhOpt, phi0,valAbil,age1,hAvgx,Rx,wx,sxx,T1, dbg);
   wt = 1 - l - v;

   % ** Save profiles of asset holdings
   aM(rCase, :) = a;
   hM(rCase, :) = h;


   % ** Save results to reuse as initial guesses
   hInG = h;
   phiG = phi;
   muG  = mu;
   c1G  = c1;
   phi0G = phi0;
   valAbilG = valAbil;

   phiIni = phi;
   muIni  = mu;
   c1Ini  = c1;
   tmp = sprintf('k: %7.3f    hT: %7.3f', k, h(T));
   disp(tmp);


end
% **********  end for  ********************

   % ** Show solution to hh problem
   Ri = cumprod([1, 1+r(2:T)]);
   hhshow(c,x,a,h,l,v, B1,BT,tBequ,taxb0, w,Ri,T1, ax,hx);


   % ***  Elasticity of savings  ***
   if 1
      % Percent change in asset holdings
      aChange = [0, aM(2, 2:T)./aM(1, 2:T)-1];
      hChange = [0, hM(2, 2:T)./hM(1, 2:T)-1];
      % Elasticities by age
      aElast  = aChange ./ rwChange(2);
      hElast  = hChange ./ rwChange(2);
      % Show
      plot( 1:T, aElast, style1,  1:T, hElast, style2 );
      title( 'Elasticities of a(t) and h(t)' );
      xlabel( 'Age' );
      pause2;
      close;
   end


   % ***  Elasticity of hc growth  ***
   % Average growth factor and period growth factor
   h = hM(1, 1:T);
   hGrowth1 = ( h(2:T) ./ h(1) ) .^ (1 ./ (1:T-1));
   hGrPd1   = h(2:T) ./ h(1:T-1);
   h = hM(2, 1:T);
   hGrowth2 = ( h(2:T) ./ h(1) ) .^ (1 ./ (1:T-1));
   hGrPd2   = h(2:T) ./ h(1:T-1);
   % Elasticities by age
   hElast   = (hGrowth2 ./ hGrowth1 - 1) ./ rwChange(2);
   hElastPd = (hGrPd2   ./ hGrPd1   - 1) ./ rwChange(2);

   % Show
   plot( 1:T-1, hElast, style1,  1:T-1, hElastPd, style2 );
   title( 'Elasticities of h growth' );
   xlabel( 'Age' );
   pause2;
   close;


%keyboard

   % Restore changed globals
   B = Bsaved;

diary off;
% *** end function ***

