function hh_sensit(calNo, bgpNo)
% Solve household problem.
% To test sensitivity.
% ---------------------------------------
% TASK:
%  Start with parameters and solution from loaded bgp

% IN:

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

global bb sig rho hEndowment aEndowment
global A aa ddk ddh
global B psi ddh eta zeta ksi gg h1Invest Bx
global popGrowth tb hcInherit yearsOfLife Tx iniAge yPerPd hhLife T1
global iniPop tBequ
global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
global tcAdjustsG toAdjustsG UNDEFINED
global bequ BEQUTYPE ALTRUISTIC NONALTRUISTIC NOBEQUEST hcAltruism
global hTarget bequTarget BxTarget calH calDdh ddhTarget calSig sigTarget
global calEta etaTarget calPsi psiTarget vTarget IYTarget grTarget
global hfCalNo hfExpNo hExog

   if nargin ~= 2
      disp(' ');
      disp('Usage:  hh_sensit(calNo, bgpNo)');
      return;
   end

   inFile.calNo  = calNo;
   inFile.calBgp = bgpNo;
   inFile.bgpNo  = bgpNo;
   dbg = 111;
   hhOpt = UNDEFINED;
   startTime = clock;

   disp(' ')
   disp('--- HHSOLVE: Start --------------------------');



% **********  EXPERIMENT SETTINGS  *****************

   % Load calibration
   paraload(inFile.calNo, inFile.calBgp, dbg);
   T = hhLife;
   ageDiff = tb-1;
   h1x = hEndowment;
   a1x = aEndowment;

   % Experiment settings
   [tax0, kDeduct,xDeduct,xEarn, taxAdj0] = bsetting(inFile.bgpNo, dbg);
   [tw0,tk0,TrY,GY,tc0,to0,DY,sx0,tmp,tmp,taxb0,sxx0,twx0] = taxvec(tax0);



% *******************   SWITCHES   **************************

    saveFreq  = 1.5;    % minutes
    showFreq  = 0.25;   % minutes
    checkFreq = 2;      % minutes
    dbgHigh   = 10;
    dbgLow    = 1;




% *******************  CONSTANTS  ***************************

    %   Total population
    totalPop = popsize( iniPop, popGrowth, T );
    %   The current generation is this fraction of the total population:
    populShare = iniPop / totalPop;
    %   Ratio of young/old generation = no of children per parent
    popRatio = popGrowth^ageDiff;



% *********  INITIAL GUESSES  *********************

   % *** Load initial guesses ***
   [priceS,agS,hhS,K,L, gr, pol0V, mu, phi, c,l,v,a,h,x,tmp,...
   BTIni,phi0,valAbil,vhx0,ax0,hx0,xx0,Xx0,vh1Child0,hT10 ] =...
       bgpload(inFile.calNo, inFile.calBgp, inFile.bgpNo, dbg);
   B1Ini  = hhS.B1;
   Lambda = hhS.Lambda;
   wt  = max(1-l-v, 0);
   c1  = c(1);

   % rescale
   K = K .* h1x .* iniPop;
   L = L .* h1x .* iniPop;
   k = K / L;

   % ** Use policy guess
   % Name of the endogenous policy variable
   if taxAdj0 == twAdjustsG
       endPolName = 'tw0';
   elseif taxAdj0 == tkAdjustsG
       endPolName = 'tk0';
   elseif taxAdj0 == DYAdjustsG
       endPolName = 'DY';
   elseif taxAdj0 == GYAdjustsG
       endPolName = 'GY';
   elseif taxAdj0 == TrYAdjustsG
       endPolName = 'TrY';
   elseif taxAdj0 == tcAdjustsG
       endPolName = 'tc0';
   else
       abort('Og1Bgp: Unknown endogenous policy name')
   end
   policyGuess = pol0V(taxAdj0);
   eval([ endPolName,'=policyGuess;' ]);

   % ** Bequest received
   B1 = B1Ini;
   BT = BTIni;
   BTN = BT;

   hAvg = agS.hAvg;
   hAvg = hAvg(1) .* gr.^(0:T-1);

   VPrime = hhS.VPrime;

   hEndog = 1;
   hProfile = UNDEFINED;



   grAggr = gr * popGrowth;

   % *** compute (w,r), output, per capita transfers ***
   tc = ones(1,T) .* tc0;
   tw = ones(1,T) .* tw0;



   done = 0;
   hhProbTol = 1e-5;


% ***********  EXPERIMENT SETTINGS  ***********
   experNo = 2;

   wageFactor = 1;

   if experNo == 1
      % *** Range of capital-labor ratios ***

      kV = [2.8, 2.93 : 0.01 : 2.98];
      n = length(kV);
      h25V = zeros(1, n);
      lV = zeros(1,n);

      %kV = fliplr(kV);
      nExper = length(kV);

   elseif experNo == 2
      % *** Labor supply elasticity ***
      wageFactorV = [1, 1.05];
      nExper = length(wageFactorV);

   else
      abort([ mfilename, ': Invalid experNo' ]);
   end


% ---------------------------------------------------------------------
for i = 1 : nExper;

   if experNo == 1
      k = kV(i);
   elseif experNo == 2
      wageFactor = wageFactorV(i);
   end

   % ** Factor prices and tax rates faced by the hh as a function of age
   K = k * L;
   [Y, MPK, MPL] = prodfct(K,L);
   Ynet = Y - ddk .* K;
   [r,w, tl] = bgprw( MPK, MPL, tk0,tw0,0,to0, kDeduct, ddk,T1,T );
   Ri = cumprod(1+r);

   if experNo == 2
      w = w .* wageFactor;
   end

   % ** Transfers
   % per capita transfer = total transfer * fraction of population
   Tr = TrY .* Ynet .* populShare .* gr.^(0:T-1);

   hAvgV = hAvg(1) .* gr .^ (0:T-1);

   % *********  INV. IN h1  ********
   h1Inv.Tstar = Tx;
   hAvgx = mseqend(hAvg(1)/gr, gr, Tx);
   h1Inv.rx = r(1);
   h1Inv.wx = MPL * (1-twx0);
   h1Inv.cx = x_cost(tl(1), sxx0, 0, 0);



   % ***************  HOUSEHOLD PROBLEM  ************************

   h1Inv.dV_da1 = Lambda;
   h1Inv.dV_dh1 = phi0;
   vh1Child = bequ * (bb * popGrowth)^(tb-1) * hcInherit * phi0 / gr^(sig*(tb-1));

   disp(' ');
   disp('-- Hh inputs --');
   disp(sprintf('w: %6.3f    r: %6.3f    Tr: %6.3f    hAvg: %6.3f', ...
      w(1) , r(1), Tr(1), hAvgV(1) ));

   [cN,lN,vN,aN,hN,xN, c1N,muN,phiN,BTN,valAbilN,hT1, h1Out] = ...
     hhprob(w, r, tl,tc,Tr, h1x,a1x,B1,tBequ,1+taxb0, c1,mu,phi,...
     hProfile,h,hAvgV,xDeduct,sx0,xEarn, VPrime,BT,vh1Child,hhProbTol,...
     hhOpt, valAbil,hAvgx,h1Inv,T1, dbg);


   % ******** Labor supply elasticity *********
   % ** Total hours worked
   tV = 1 : T1;      % age range
   totalHoursV(i) = iniPop * sum( (1-lN(tV)) ./ popGrowth.^(tV-1) );
   % ** Average wage
   totalEarnV(i)  = iniPop * sum( (1-lN(tV)-vN(tV)) .* hN(tV) .* w(tV) ./ popGrowth.^(tV-1) );
   avgWageV(i)    = totalEarnV(i) / totalHoursV(i);


   c1Dist   = abs( c1N/c1 - 1 );
   cDist    = max(abs( cN./c - 1 ));
   hDist    = max(abs( hN./h - 1 ));
   phiDist  = distance3(phiN, phi, 0.01, dbg);
   muDist   = distance2(muN, mu, 0.01, dbg);
   phi0Dist = abs( h1Out.dV_dh1 / phi0 - 1 );
   LambdaDist = ( h1Out.dV_da1 / Lambda - 1 );


   % ** Marginal value of bequest: bequ * VPrime
   if tBequ > 0
      % Parent and child overlap
      [tmp, muChild] = ufct( cN(tBequ)*gr^ageDiff, lN(tBequ) );
   elseif tBequ == 0
      % Child born one period after parent dies
      [tmp, muChild] = ufct( cN(1)*gr^ageDiff, lN(1) );
      muChild = muChild * bb * (1+r(1));
   else
      abort([ mfilename, ': Invalid tBequ' ]);
   end
   VPrimeN = bb^T * muChild / (1+tc0);
   dist_VPrime = VPrimeN / VPrime - 1;


   % *************** #Show results of iteration ***************
   disp('---- Distances: ');
   distV = [c1Dist, cDist, hDist, phiDist, phi0Dist, LambdaDist, dist_VPrime];
   dist  = max(abs( distV ));
   disp(sprintf( '  Max dist: %6f', dist ));
   disp(sprintf( '  c: %6f    h: %6f    phi0: %6f    phi: %6f    VPrime: %6f', ...
      cDist, hDist, phi0Dist, phiDist, dist_VPrime ));

   disp(' ');
   disp(sprintf( '  h(25): %6.3f    c(1): %6.3f    Lambda: %6.3f',  hN(25), cN(1), h1Out.dV_da1 ));

   if 0
      disp(' ');

      ageV = 1:T;
      subplot(2,2,1);
      plot(ageV, [aN; a]);
      title('Assets');

      subplot(2,2,2);
      plot(ageV, [hN; h]);
      title('h');

      subplot(2,2,3);
      plot(ageV, [cN; c]);
      title('c');

      subplot(2,2,4);
      plot(ageV, [lN; l]);
      title('l');

      pause_print(0);
   end

   h = hN;
   mu = muN;
   phi = phiN;
   c1 = c1N;

   h25V(i) = hN(25);
   lV(i) = mean(lN);
   % Labor is NOT in efficiency units!
   [KV(i), LV(i)] = aggreg(iniPop, popGrowth, gr, 1-lN-vN, aN, ones(size(hN)), DY*agS.Y, h1Out.ax,h1Out.vhx);

   %disp(mfilename);
   %keyboard

end %------------------------------------- whend ----------------------------------%



% *********************  RESULTS  ****************************
if experNo == 2
   disp(' ');
   LSelast = ( LV(2) - LV(1) ) / LV(1)   /   (wageFactorV(2)-1);
   disp(sprintf( '--- Labor supply elasticity: %f', LSelast ));

   %LSelast2 = ( (1-lV(2)) - (1-lV(1)) ) / (1-lV(1))   /   (wageFactorV(2)-1);
   %disp(sprintf( '--- Labor supply elasticity 2: %f', LSelast2 ));

   LSelast3 = (totalHoursV(2) / totalHoursV(1) - 1)  /  (avgWageV(2) / avgWageV(1) - 1);
   disp(sprintf( '--- Labor supply elasticity 3: %f', LSelast3 ));
   disp(sprintf( '    Hours:  %6.2f -> %6.2f    Earnings:  %6.2f -> %6.2f    Wages: %6.2f -> %6.2f', ...
      totalHoursV, totalEarnV, avgWageV ));
end


disp(mfilename);
keyboard


% *** end function ***

