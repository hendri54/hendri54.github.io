function dist = calibr(cNo, bgpNo);
% Calibrate Tax and growth model.
% ---------------------------------------
% IN:
%  cNo   no of calibration experiment. Defined in body of function.
%        mostly the same as number of a bgp
% ---------------------------------------

% AUTHOR: Lutz Hendricks, 1995-97
% ---------------------------------------

% ************  CONSTANTS  *************************************

   global yearsOfLife iniAge hcInherit calNo yPerPd iniPop
   global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
   global hcAltruism hEndog hExog h1Invest
   global tcAdjustsG toAdjustsG sxAdjustsG UNDEFINED
   global grTarget IYTarget vTarget hTarget
   global calDdh ddhTarget calSig sigTarget etaTarget
   dbg = 10;

   if nargin ~= 2
      disp(' ');
      disp('Usage:  calibr(cNo, bgpNo)');
      disp(' ');
      return
   end

   % **** Load settings ****
   % Load calibration
   paraload(cNo, bgpNo, dbg);
   % Set exogenous parameters again (just to make sure!)
   cal_set(cNo, dbg);
   % Save calibration to ensure correct exogenous values
   parasave(cNo, bgpNo);


% *******************************  SET TARGETS  ***********************************

   % *** Which targets to calibrate? ***
   % Adjust ddk to match I/Y
   calInvY    = 0;
   % Move Bx towards B?
   calBx      = 1;

   % *** if h exogenous: can't calibrate some things
   if h1Invest == 0
      calBx = 0;
   end



% ************  RUN BGP  ***************************************

   % ***  Construct inputs  ***
   calWhat = [1, 0, calInvY, 0, calBx];

   % ***  Run  ***
   bgpF.calNo  = cNo;
   bgpF.calBgp = bgpNo;
   bgpF.bgpNo  = bgpNo;

   dist = og1bgp(bgpF, bgpF, calWhat,dbg);


% *** end function ***
