function earn = netearn(wNet,h,wt, x,xEarn,tl,xDeduct)
% ---------------------------------------------------------------
% TASK: Compute net earnings of a household as a function of age
% IN:   Life-cycle profiles (1xT)
% ---------------------------------------------------------------

    earn = wNet.*h.*wt - x .* (xEarn.*(1-tl) - tl.*xDeduct.*(1-xEarn));
