function t_endopo
% Test endogpol()
% ---------------------------------------
% METHOD:
%   specify tax rates for all dates. Feed them into endogpol() and check
%   if it recovers the values computed before.
%   Does not test:
%   - investment in h1

% AUTHOR: Lutz Hendricks, 1993
% ---------------------------------------

% *** GLOBALS ***

global twAdjustsG tkAdjustsG GYAdjustsG TrYAdjustsG
global ddk outDir UNDEFINED
dbg = 50;
diaryon([outDir, 'test'])
clc

% ********  PATH OF K,L  *********

    T   = 20;
    T1  = 10;
    N   = 10;
    K1  = 1.1;
    L1  = 5.1 * K1;
    K   = seqa(K1, 1.2, N);
    L   = seqa(L1, 1.05, N);
    X   = seqa(0.5, 1.03, N);
    C   = seqa(0.33, 1.02, N);
    Xx  = zeros(1,N);
    % wtime * h
    wth = seqa(1, 1.01, N);

    Debt1 = 0;

% *****  CONSTRUCT REFERENCE PATH  *******************
%   construct a path of tax rates and debt for all dates

    TP  = 4;
    TPidx = 1:TP;
    kDeduct = 0.5;
    xDeduct = 0.3;
    xEarn = 0.4;
    tw  = seqa(0.15, 0.01, TP);
    tw  = [ tw, ones(1,N-TP).*tw(TP) ];
    to  = seqa(0.05, 0.01, TP);
    to  = [ to, ones(1,N-TP).*tw(TP) ];
    tc  = seqa(0.031, 0.01, TP);
    tc  = [ tc, ones(1,N-TP).*tw(TP) ];
    tk  = seqa(0.35, -0.02, TP);
    tk  = [ tk, ones(1,N-TP).*tk(TP) ];
    GY  = 0.05 .* ones(1,N);
    TrY = 0.03 .* ones(1,N);
    DY  = 0.3 .* ones(1,N);

    [ Y, MPK, MPL ] = prodfct(K,L);
    Ynet = Y - ddk .* K;
    k = K ./ L;
    r = rnet(k, tk, kDeduct, ddk);
    X = 0.05 .* Ynet;

    % ** Tax Bases
    earn = MPL .* wth;
    twTaxBase = ltxbase2(earn,X, xEarn,xDeduct);
    toTaxBase = twTaxBase ./ 2;
    tcTaxBase = C;
    tkTaxBase = ktaxbase(K, MPK, kDeduct, ddk);


    % *****  COMPUTE ONE POLICY ENDOGENOUSLY  ******

    Debt  = DY .* Y;
    Debt1 = [ Debt(2:N), Debt(N)/Debt(N-1)*Debt(N) ];

    taxAdjTP = GYAdjustsG;
    GY = [ zeros(1,TP), GY(TP+1:N) ];
    taxRev = tw.*twTaxBase + to.*toTaxBase + tc.*tcTaxBase...
         + tk.*tkTaxBase;
    Expend = GY .* Y + TrY .* Ynet + (1+r).*Debt - Debt1;
    tmp = (taxRev - Expend) ./ Ynet;
    GY(1:TP) = tmp(1:TP);

    taxAdj = twAdjustsG;
    tw = [ tw(1:TP), zeros(1,N-TP) ];
    taxRev = tw.*twTaxBase + to.*toTaxBase + tc.*tcTaxBase...
         + tk.*tkTaxBase;
    Expend = GY .* Y + TrY .* Ynet + (1+r).*Debt - Debt1;
    tmp = -(taxRev - Expend) ./ twTaxBase;
    tw(TP+1:N) = tmp(TP+1:N);

    taxRev = tw.*twTaxBase + to.*toTaxBase + tc.*tcTaxBase...
         + tk.*tkTaxBase;
    Expend = GY .* Y + TrY .* Ynet + (1+r).*Debt - Debt1;
    if notequal(taxRev, Expend, 1e-3)
        taxRev
        Expend
        disp('Difference:')
        (taxRev-Expend)
        abort('Invalid setup')
    end

    polOld = [tw, to, tc, tk, GY, TrY, DY];

    if 1
        G  = GY .* Y;
        Tr = TrY .* Ynet;
        tcRev = tc .* tcTaxBase;
        twRev = tw .* twTaxBase;
        toRev = to .* toTaxBase;
        tkRev = tk .* tkTaxBase;
        % ** Debt service
        DSpend= Debt  .* (1+r);

        Deficit = G + Tr + DSpend - tcRev - twRev - toRev - tkRev - Debt1;

        if  any(Deficit > 1e-4)
            warnmsg('T_Endopo: BUDGET NOT BALANCED')
            Deficit
        end
    end


    % *** Policies not implemented ***
    taxb  = zeros(1,N);
    sx    = zeros(1,N);
    ts    = zeros(1,N);
    RR    = zeros(1,N);
    sxx   = zeros(1,N);
    twx   = zeros(1,N);
    tbTaxBase = zeros(1,N);

    tax0  = [ tw(1);tk(1);TrY(1);GY(1);tc(1);to(1);DY(1);sx(1);ts(1);RR(1);taxb(1);sxx(1);twx(1) ];
    tax9  = [ tw(2:TP);tk(2:TP);TrY(2:TP);GY(2:TP);tc(2:TP);to(2:TP);DY(2:TP);sx(2:TP);ts(2:TP);RR(2:TP);....
            taxb(2:TP);sxx(2:TP);twx(2:TP) ];
    taxE  = [ tw(N);tk(N);TrY(N);GY(N);tc(N);to(N);DY(N);sx(N);ts(N);RR(N);taxb(N);sxx(N);twx(N) ];
    other = [ T; N; taxAdj; kDeduct; T1; xDeduct; xEarn; taxAdjTP; taxAdj ];


% *******  COMPUTE ENDOGENOUS DEBT AND TAXES  *********

    disp('Calling endopol...')

    [twN,toN,tcN,tkN,GYN,TrYN,DYN,sxN,taxbN] = endopol(...
      TP, Y,K,k,X, tw,tk,tc,to,GY,TrY,DY,sx,ddk,Debt(1), tax0,tax9,taxE,other, ...
      twTaxBase, toTaxBase, tcTaxBase, tkTaxBase,tbTaxBase,taxb, Xx,dbg);

    disp('Returned from endopol')

    polNew = [twN, toN, tcN, tkN, GYN, TrYN, DYN];


% ********  CHECK  **************

    disp('--- RESULTS ---')

    % ***** Are tax rates the same?  ******
    if notequal( polOld, polNew, 1e-3 )
        warnmsg('Policies differ')
        if notequal( tw, twN, 1e-3 )
            tw
            twN
            disp('Difference:')
            (tw-twN)
        end
        if notequal( tc, tcN, 1e-3 )
            tc
            tcN
            disp('Difference:')
            (tc-tcN)
        end
        if notequal( to, toN, 1e-3 )
            to
            toN
            disp('Difference:')
            (to-toN)
        end
        if notequal( tk, tkN, 1e-3 )
            tk
            tkN
            disp('Difference:')
            (tk-tkN)
        end
        if notequal( GY, GYN, 1e-3 )
            GY
            GYN
            disp('Difference:')
            (GY-GYN)
        end
        if notequal( TrY, TrYN, 1e-3 )
            TrY
            TrYN
            disp('Difference:')
            (TrY-TrYN)
        end
    else
        disp('Policies ok')
    end

diary off
% *** end function ***

