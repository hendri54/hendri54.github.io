% run_slides
% Run experiments used in slides


% *** Table for intro ***
if 01
   calibr(240,6);    runbgp(240,6,42);
   calibr(240,5);    runbgp(240,5,42);
   calibr(840,5);    runbgp(840,5,42);
end


% *** 5% tax changes ***
if 01
   calibr(240,6);    runbgp(240,6,44);
   calibr(240,5);    runbgp(240,5,45);
   calibr(840,5);    runbgp(840,5,45);
end

% *** Decomposition IH -> OLG ***

calibr(242,6);    runbgp(242,6,42);
calibr(240,6);    runbgp(240,6,42);
calibr(250,6);    runbgp(250,6,42);
%calibr(252,6);    runbgp(252,6,42);
calibr(253,6);    runbgp(253,6,42);
calibr(254,6);    runbgp(254,6,42);



% *** eof ***


