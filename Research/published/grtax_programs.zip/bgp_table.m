function bgp_table(tableNo, doCompute)
% Show a table with bgp results
% ---------------------------------------
% TASK:
%  Tax and growth paper.

% ---------------------------------------

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

% ************  CONSTANTS  *************************************

   global yearsOfLife hcInherit calNo yPerPd
   global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
   global ALTRUISTIC NONALTRUISTIC BEQUTYPE hcAltruism
   global tcAdjustsG toAdjustsG sxAdjustsG UNDEFINED
   dbg = 15;
   fName = mfilename;

   % ** Recompute everything before showing tables?
   %doCompute = 01;

   v_check( tableNo, 'i', [1,1], 1, 10 );
   v_check( doCompute, 'i', [1,1], 0, 1 );

% ******************  SET UP BGPS TO SHOW  **********************

if tableNo == 1     % First part of table
   calNoV  = [101, 210, 102, 191, 192, 186, 187, 182, 181, 131, 151, 152, 161, 198];
   % No of experiments
   n = length(calNoV);
   calBgpV = 5  .* ones(1, n);
   bgpNoV  = 42 .* ones(1, n);

elseif tableNo == 2
   calNoV  = [101, 101, 300, 101, 101];
   n = length(calNoV);
   calBgpV = [5,   6,   6,  6,  6];
   bgpNoV  = [43,  42,  42, 20  21];

elseif tableNo == 5        % First part of sensitivity analysis
   calNoV  = [101, 210, 102, 191, 192, 186, 187];
   n = length(calNoV);
   calBgpV = 5  .* ones(1, n);
   bgpNoV  = 42 .* ones(1, n);

elseif tableNo == 6        % Second part of sensitivity analysis
   calNoV = [198, 101, 151, 152, 162, 162, 131, 185, 182, 183, 101, 187, 101, 101];
   %               2                   6         8         10             13
   n = length(calNoV);
   calBgpV = 5  .* ones(1, n);
   bgpNoV  = 42 .* ones(1, n);
   bgpNoV(2)  = 43;
   calBgpV(6) = 7;
   calBgpV(11:15) = 6;
   bgpNoV(13) = 20;
   bgpNoV(14) = 21;

else
   abort([ mfilename, ': Invalid tableNo' ]);
end

% Show bgps from cal1 to cal2
cal1 = 1;
cal2 = n;

% No of experiments to show
nCal = cal2 - cal1 + 1;


% ***** Allocate result vectors *****
gr1V = zeros(1, nCal);
gr2V = zeros(1, nCal);
dgrV = zeros(1, nCal);

r1V  = zeros(1, nCal);
r2V  = zeros(1, nCal);
drV  = zeros(1, nCal);

dist1V = zeros(1, nCal);
dist2V = zeros(1, nCal);


% ******************  LOAD  *************************************

for i = cal1 : cal2

   cNo      = calNoV(i);
   calBgp   = calBgpV(i);
   bgpNo    = bgpNoV(i);

   if doCompute == 1
      calibr( cNo, calBgp );
      runbgp( cNo, calBgp, bgpNo );
   end

   paraload( cNo, calBgp );

   % Load initial bgp
   [priceS,agS,hhS, K,L,gr,pol0V, mu, phi, c, l, v, a, h, x,util,BT,phi0,valAbil,...
      vhx,ax,hx,xx,Xx,vh1Child,hT1,Lambda,dist,B1] = bgpload(cNo, calBgp, calBgp, dbg);

   gr1V(i) = (gr-1)*100;
   r1V(i)  = priceS.r(1)*100;
   dist1V(i) = dist;

   % Load alternate bgp
   [priceS,agS,hhS, K,L,gr,pol0V, mu, phi, c, l, v, a, h, x,util,BT,phi0,valAbil,...
      vhx,ax,hx,xx,Xx,vh1Child,hT1,Lambda,dist,B1 ] = bgpload(cNo, calBgp, bgpNo, dbg);

   gr2V(i) = (gr-1)*100;
   r2V(i)  = priceS.r(1)*100;
   dist2V(i) = dist;

   % *** Changes ***
   dgrV(i) = gr2V(i) - gr1V(i);
   drV(i)  = r2V(i)  - r1V(i);
end


% ******************  SHOW TABLE  *******************************

for i = cal1 : cal2
   cNo      = calNoV(i);
   calBgp   = calBgpV(i);
   bgpNo    = bgpNoV(i);

   disp(' ');
   disp('                 gr        r        dist');
   disp(sprintf( '%3i %3i %3i:  %5.2f    %5.2f    %6f',  ...
      cNo, calBgp, calBgp, gr1V(i), r1V(i), dist1V(i) ));
   disp(sprintf( '        %3i:  %5.2f    %5.2f    %6f',  ...
      bgpNo, gr2V(i), r2V(i), dist2V(i) ));
   disp(sprintf( '             (%5.2f)  (%5.2f)', dgrV(i), drV(i) ));
end

%keyboard

% *** end function ***
