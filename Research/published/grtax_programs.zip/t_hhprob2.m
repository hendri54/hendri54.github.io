function t_hhprob2
% Syntax test of hhprob2
% ---------------------------------------
% TASK:
%  Tax and growth paper.

% ---------------------------------------

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

% ************  CONSTANTS  *************************************

   global yearsOfLife hcInherit calNo yPerPd hhLife T1 tb h1Invest Tx
   global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
   global tcAdjustsG toAdjustsG sxAdjustsG UNDEFINED

   T = hhLife
   ageDiff = tb - 1;
   tBequ = T - ageDiff;
   fName = mfilename;
   dbg = 100;

% ********  INPUTS  ************

   w = ones(1, T);
   r = 0.1 .* ones(1, T);
   tl = 0.3 .* ones(1, T);
   tc = 0.1 .* ones(1, T);
   Tr = 2 .* ones(1, T);
   h1x = 2;
   a1x = 3;
   B1 = 4;
   tbP1 = 1;
   c1Ini = 0.4;
   muIni = linspace(2, 0, T);
   phiIni = linspace(3, 0, T);
   hIn = linspace(1, 2, T);
   hAvg = linspace(2, 1, T);

   xDeduct = 0.3;
   sx = 0.1;
   xEarn = 0.5;
   VPrime = 4;
   bequ = 0.3;
   BTold = 3;
   vh1Child = 4;

   TOLERANCE = 1e-2;
   options = 0.01;

   h1Inv.dV_dh1 = 2;
   h1Inv.dV_da1 = 3;
   h1Inv.Tstar  = Tx;
   h1Inv.cx     = 0.3;
   h1Inv.wx     = w(1);
   h1Inv.rx     = 0.15;

   valAbil = 0.1;
   hAvgx = linspace(0.5, 1, h1Inv.Tstar);



[c,l,v,a,h,x, c1,mu,phi, BT,valAbil,hT1, h1Out] = ...
    hhprob2(w,r, tl,tc,Tr, h1x,a1x,B1,tBequ,tbP1, c1Ini,muIni,phiIni,hIn,...
    hAvg,xDeduct, sx,xEarn,VPrime,bequ,BTold,vh1Child,TOLERANCE,options, ...
    h1Inv,valAbil,hAvgx,T1, dbg);


if h1Invest == 1
   disp(sprintf( 'h1Out.ax: %f -> %f', h1Out.ax(1), h1Out.ax(Tx+1) ));
end


% *** end function ***
