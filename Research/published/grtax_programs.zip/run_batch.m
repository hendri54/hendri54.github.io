function run_batch(tableNo)
% Run a batch of experiments
% ---------------------------------------
% TASK:
%  Tax and growth paper.
%  Each experiment is characterized by 3 numbers
%  (1) calNo (2) calBgp (3) bgpNo

% ---------------------------------------

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

dbg = 1;
fName = mfilename;
v_check( tableNo, 'i', [1,1], 1, 10 );
calBgp = 5;
bgpNo  = 42;

switch tableNo
   case 1
      calNoV  = [101, 151, 152, 161, 181, 182, 191, 192, 198, 201];
   case 5
      calNoV  = [101, 210, 191, 192, 186, 187, 183];
   case 6
      calNoV  = 101;

   case 7
      % Transform OLG -> IH
      calNoV  = [340, 370, 400, 430, 550];

   case 8
      % Transform OLG -> IH
      calNoV  = [341, 371, 401, 431, 551];

   case 9
      % Transform OLG -> IH
      calNoV  = [345, 375, 405, 435, 555, 595];

   case 10
      % Transform OLG -> IH
      calNoV  = [347, 377, 407, 437, 557, 597];

   otherwise
      abort([ fName, ': Invalid tableNo' ]);
end

% No of experiments
n = length(calNoV);
calBgpV = calBgp .* ones(1, n);
bgpNoV  = bgpNo  .* ones(1, n);


for i = 1 : n
   calibr( calNoV(i), calBgpV(i) );
   runbgp( calNoV(i), calBgpV(i), bgpNoV(i) );
end


% *** end function ***
