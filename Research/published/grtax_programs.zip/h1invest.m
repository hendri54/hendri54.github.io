function [h, a, v, x] = h1invest(h1x, a1x, Tstar, r, wx, cx, hAvg, dV_da1, dV_dh1, dbg);
% Optimal investment in h1, given shadow prices
% ---------------------------------------
% TASK:
%  Investment in h1

% IN:
%  h1x            endowment at beginning of life
%  a1x            asset holdings at beginning of life
%  Tstar          no of periods of investment in h1
%  r              interest rate
%  wx             cost of effective time input
%  cx             cost of goods input
%  hAvg(1:Tstar)  average h; input in h production function
%  dV_da1         marginal value of asset holdings at age 1
%  dV_dh1         ditto for h1

% OUT:
%  a, h           profiles of length Tstar+1; last values = endowments
%                 for new households entering model
%  v, x           profiles of inputs, length Tstar
% ---------------------------------------

% REM:
%  Assumes that a1 in household problem earns interest in period 1

% TEST:
%

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------

% ************  CONSTANTS  *************************************

   global yearsOfLife hcInherit calNo yPerPd
   global UNCHANGED UNDEFINED
   global ddhx etax psix Bx
   zetax = 1 - etax - psix;

   fName = mfilename;
   v_check( dbg, 'i', [1,1], 0, UNDEFINED );
   if dbg > 5
      v_check( wx, 'f', [1,1], 1e-5, UNDEFINED );
   end

% *****************  MAIN  **************************************

% ******  SOLVE FOR INPUTS  *********
% Depends on functional form: G*
phiStar = dV_dh1 .* (1-ddhx).^(Tstar-1 : -1 : 0);

Gv = dV_da1 .* wx .* (1+r).^(Tstar - (1:Tstar)) ./ phiStar;

denom = psix .* Bx .* hAvg.^zetax .* (etax./psix .* wx./cx).^etax;
v = (Gv ./ denom) .^ (1./(psix+etax-1));

x = v .* etax./psix .* wx./cx;

Gfct = Bx .* hAvg.^zetax .* v.^psix .* x.^etax;


% *******  SOLVE FOR ASSETS + H1  *********
h = zeros(1, Tstar+1);
h(1) = h1x;
a = zeros(1, Tstar+1);
a(1) = a1x;
for i = 1 : Tstar
   h(i+1) = (1-ddhx) .* h(i) + Gfct(i);
   a(i+1) = (1+r) * a(i) - wx * v(i) - cx * x(i);
end



% ***********  SELF TEST  **************
if dbg > 10
   v_check( h, 'f', [1,Tstar+1], 1e-5, UNDEFINED );
   % Cannot check whether a<a1x b/c of interest income
   v_check( a, 'f', [1,Tstar+1], UNDEFINED, UNDEFINED );
   v_check( v, 'f', [1,Tstar], 1e-10, UNDEFINED );
   v_check( x, 'f', [1,Tstar], 1e-10, UNDEFINED );
end

% *** end function ***
