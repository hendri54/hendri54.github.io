function t_hhpr2
% t_hhpr2: Test household problem (hhprob)
% IN:
%   optional initial guesses
% OUT:
%   values that can be used as initial guesses for the next run
% METHOD:
% - set up 2 input sets constructed such that solution of hh problem should
%   differ only along a few dimensions
% - run hhprob.m twice and compare

% AUTHOR: Lutz Hendricks, 1993
% ---------------------------------------


% *** GLOBALS ***

global baseDir outDir
global bb sig rho bequ
global A aa ddk
global B psi ddh eta zeta ksi gg
global popGrowth tb hcInherit yearsOfLife
global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED UNDEFINED
global tcAdjustsG toAdjustsG
% ** h1 Investment
global Bx etax psix ddhx
% ** Bequests
global BEQUTYPE ALTRUISTIC NONALTRUISTIC
% ** Globals for initial guesses
global phiG muG c1G phi0G valAbilG
global hfCalNo hfExpNo hExog


% *******  INPUT CHECK  *************************

   disp(' ')
   disp('--- T_HHPR2: Start ---------------------------------');
   parachk;


    if hfCalNo > 0  |  hfExpNo > 0
        hEndog = 0;
        hProfile = hExog;     % hprload(hfCalNo, hfExpNo);
    else
        hEndog = 1;
        hProfile = 0;
    end


% ******** CONSTANTS  ************************

    TOLERANCE = 1e-5;

    T   = 20;
    T1  = 15;
    hc1 = 1;
    a1  = 0;
    iniPop = 1;

    tw0     = 0.2;
    tk0     = 0.375;
    tc0     = 0.092;
    to0     = 0.25;
    sx0     = 0;
    ts0     = 0.12;
    RR0     = 1.1;
    taxb0   = 0.1;

    kDeduct = 1;
    xDeduct = 0;
    xEarn   = 0;


    if isempty(c1G) | isempty(phiG) | isempty(muG)
        disp('T_HhPr2: Using default guesses');
        c1Ini = 0.1;
        muIni = [zeros(1,T1), 0.1.*ones(1,T-T1)];
        phiIni= linspace(1,0,T);
    else
        % Use inputs as guesses
        muIni   = muG;
        phiIni  = phiG;
        c1Ini   = c1G;
        phi0    = phi0G;
        valAbil = valAbilG;
    end

% *******************   SWITCHES   **************************

    exper = 0;

    yPerPd = yearsOfLife / T;
    ageDiff = tb-1;
    % Bequest is received at BEGINNING of:
    tBequ  = T - tb + 1;

    % Tolerance for hh problem
    hhProbTol = 1e-5;

    % ** Max changes of updated variables
    chngUp = 1.2;
    chngDn = 0.8;
    % ** Max change of new guesses
    chngUpN = 4;
    chngDnN = 1/4;


% *******************  CONSTANTS  ***************************

    % ** Is there social security?
    if  ts0==0 & RR0==0
        NoSocialSec = 1;
    else
        NoSocialSec = 0;
    end




% *********************  POLICY VARIABLES  *************************

    tc = ones(1,T) .* tc0;
    tw = ones(1,T) .* tw0;
    tk = ones(1,T) .* tk0;
    ts = [ones(1,T1).*ts0, zeros(1,T-T1)];
    to = [zeros(1,T1), ones(1,T-T1) .* to0];
    tk = ones(1,T) .* tk0;

    Tr = 0.08 .* ones(1,T);

    SSI = zeros(1,T);



% ********************  PRICES  *****************************

    k = 0.39;

for k = 0.38 : 0.002 : 0.38
    L = 1;
    K = k * L;
    [Y, MPK, MPL] = prodfct(K,L);
    Ynet = Y - ddk .* K;
    [r,w, tl] = bgprw( MPK, MPL, tk0,tw0,ts0,to0, kDeduct, ddk,T1,T );


% *********  BEQUEST  *********

     if bequ > 0
        B1 = 0.62;
        VPrime = 1.3;
    else
        B1 = 0;
        VPrime = 0;
    end


% ********  INITIAL GUESSES  *********


    hAvg = seqm(0.5, 1.002, T);

    age1  = 0;
    if age1 > 1
        hAvgx = seqm(0.9, 1.02, age1-1);
        Rx = 1 + r(1:age1);
        wx = seqa(0.3,0.02,age1-1);
        sxx = seqa(0.1,0.02,age1-1);
        if isempty(phi0G)
            phi0 = phiIni(1) * 1.1;
            valAbil = phi0;
        else
            phi0 = phi0G;
            valAbil = phi0;
        end
    else
        hAvgx = 0;
        Rx = 0;
        phi0 = 0;
        valAbil = 0;
        wx = 0;
        sxx = 0;
    end


% *********  INPUT SET 1  *************

     % *********** solve hh problem  *************

     disp('--- Inputs hh problem ---')
     tmp = sprintf('w: %7.3f .. %7.3f    r: %7.3f', w(1), w(T), r(1));
     disp(tmp);


     hhOpt = UNDEFINED .* ones(1,7);
     hhOpt(5) = 50;

     [c, l, v, a, h, x, c1, mu, phi, BT, Lambda,phi0,valAbil,ax,hx,xx,vhx] = ...
     hhprob(w, r, tl,tc,SSI,Tr, hc1,a1,B1,tBequ,1+taxb0, c1Ini,...
         muIni,phiIni,hProfile,hAvg,xDeduct, sx0,xEarn,VPrime,2,...
         hhProbTol, hhOpt, phi0,valAbil,age1,hAvgx,Rx,wx,sxx, dbg);
     wt = 1 - l - v;

     % ** Save results to reuse as initial guesses
     phiG = phi;
     muG  = mu;
     c1G  = c1;
     phi0G = phi0;
     valAbilG = valAbil;

    phiIni = phi;
    muIni  = mu;
    c1Ini  = c1;
    tmp = sprintf('k: %7.3f    hT: %7.3f', k, h(T));
    disp(tmp);
end % for %

     Ri = cumprod([1, 1+r(2:T)]);
     hhshow(c,x,a,h,l,v, B1,BT,tBequ,taxb0, w,Ri,T1, ax,hx);



% *********  INPUT SET 2  *************

if exper == 0
    diary off
    return
elseif exper == 1
    if bequ <= 0  |  BEQUTYPE ~= ALTRUISTIC
        abort('Experiment 1 only for altruistic bequests.')
    end
    dB1 = 1;
    B1 = B1 + dB1;
else
    warnmsg('No experiment')
end

    % *********** solve hh problem  *************

    [c2, l2, v2, a2, h2, x2, c12, mu2, phi2, BT2, Lambda2] = ...
        hhprob(w, r, tl,tc,SSI,Tr, hc1,a1,B1,tBequ,1+taxb0, c1Ini,...
        muIni,phiIni,hProfile,hAvg,xDeduct, sx0,xEarn,VPrime,2,...
        hhProbTol, hhOpt, dbg);


% ******************  PROCESS SOLUTION  ********************

    rV = [ 0, r(2:T) ];     % for computation of present values
    Ri = cumprod(1+rV);

    disp(' ')
    disp(['--- Experiment ', int2str(exper), ' --------------------------------'])

if exper == 1
    disp(['B1 rises by ', num2str(dB1)])
    disp('Expected result: BT rises by the same amount in PV')
    disp(' ')

    PvBT = BT * (1+taxb0) / Ri(T);
    PvBT2 = BT2 * (1+taxb0) / Ri(T);
    PvdB1 = dB1 / Ri(tBequ);
    dPv = PvBT2 - PvBT - PvdB1;
    if abs(dPv) > TOLERANCE
        disp('Present values of BT differ')
        tmp = sprintf('PvBT2: %7.3f   PvBT: %7.3f   dB1: %7.3f   Diff.: %7.3f',...
            PvBT2, PvBT, PvdB1, dPv);
        disp(tmp)
    else
        disp('Present values of BT:  OK')
        tmp = sprintf('  Diff.: %7.3f', dPv);
        disp(tmp);
    end

    solDist = distance([c,l,v,x,h], [c2,l2,v2,x2,h2]);
    if solDist > TOLERANCE
        disp('Solutions differ:')
        disp(' Age    -dc-    -dl-    -dv-    -dx-    -dh-')
        for i = 1 : T
            tmp = sprintf('%4i %7.3f %7.3f %7.3f %7.3f %7.3f', ...
                c2(i)-c(i), l2(i)-l(i), v2(i)-v(i), x2(i)-x(i), h2(i)-h(i));
            disp(tmp)
        end
    else
        disp('Solutions:  OK')
        tmp = sprintf('  Diff.: %7.3f', solDist);
        disp(tmp);
    end
    disp(' ')

    % **** Plot both asset profiles ****
    plot( 1:T, [a; a2] );
    title('Asset Profiles');
    pause
    close
end


diary off;
% *** end function ***

