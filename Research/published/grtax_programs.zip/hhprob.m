function [c,l,v,a,h,x, c1,mu,phiX, BT,valAbil,hT1, h1Out] = ...
    hhprob(w,r, tl,tc,Tr, h1x,a1x,B1,tBequ,tbP1, c1Ini,muIni,phiXIni,...
    hProfile,hIn,hAvg,xDeduct,sx,xEarn,VPrime,BTold,vh1Child,TOLERANCE,hhOpt,...
    valAbil,hAvgx,h1Inv,T1, dbg);
% hhprob: Solve the hh problem, given (w,r)
% ---------------------------------------
% TASK:
%   Solve the hh problem, given (w,r). Model 11.93-2

% IN:
%  ** General Comments **
%   variables generally have length T, representing ages indepAge..yOfLife

%  w,r         row vector of factor prices; if scalar, interpret as constant
%  tl          all labor tax rates added
%  hIn         guess for h profile. Ignored if h exogenous, 1xT
%  hProfile    h profile if it is exogenous (1xT). Ignored if h endogenous
%  h1x      initial stock of hc at beginning of age 1
%  a1x      asset holdings at age indepAge excluding costs of investing in h1
%           (NOT a1*(1+r)!)

%  ** BEQUEST RELATED INPUTS **
%  vh1Child     defined in hhiter
%  B1       bequest received at age tBequ; PV = B1 / RR(tBequ)
%  tbP1     1+taxb; taxb = tax rate on bequests
%  VPrime   V'(BT); only for altruistic bequest
%  c1Ini, muIni, vIni
%       initial guesses; if empty or too short: use defaults
%       c(1), mu*
%  hAvg     = average h in the economy at each date
%  xDeduct
%  sx       = subsidy rate to x; scalar allowed
%  xEarn    = fraction of x bought through lower earnings
%  TOLERANCE= tolerance for convergence criterion
%   Tr          = vector of transfers

%  ** Investment in h1 **
%   valAbil     = ditto, but as ability
%   hAvgx       hAvg during period of inv. in h1
%   Rx          1+r  during that period
%   wx          cost of effective labor
%   sxx         subsidy rate for goods inputs

% Standard notation:
%   T1

% OUT:
%  solutions to hh problem (row vectors)
%  - h is an updated guess
%  length in general is T, i.e. covering independent life of hh
%  Note that a(t) is the stock of assets at the BEGINNING of period t.
% - BT:     = bequest left at END of age T
% - valAbil = updated value of valAbil
% - hx,ax   = vectors of a and h for periods before indepAge
% - xx,vhx  = inputs of goods and effective time for h1 investment
% - hT1     = h(T+1)

% TEST: t_hhprb.m

% REM:
%  Method:
%  - call hhprob2 twice (assuming that bequest motive is/isn't operative)

% AUTHOR: Lutz Hendricks, 1993 - 1996
% ---------------------------------------

   global rho sig bb bequ tb
   global UNDEFINED

   v_check( dbg, 'i', [1,1], 0, UNDEFINED );
   if dbg > 5
      v_check( h1x, 'f', [1,1], 0.01, UNDEFINED );
   end
   T = length(tl);
   bequOper = (bequ > 0);
   hEndog   = 1;
   hhOpt    = 0;  % not used


% ****************  HH PROBLEM  ****************

   if hEndog == 1
      % if h endogenous: use hIn as guess
      hGuess = hIn;
   else
      % otherwise: use exogenous profile
      hGuess = hProfile;
   end

   attempt = 1;
   done = 0;

while attempt < 3  &  done == 0
    % ** Run the hh problem assuming that bequest motive is operative
    % ** or not, depending on bequOper
    bequIn = bequ * bequOper;

    [c,l,v,a,h,x, c1,mu,phiX, BT,valAbil,hT1, h1Out] = ...
      hhprob2(w,r, tl,tc,Tr, h1x,a1x,B1,tBequ,tbP1, c1Ini,muIni,phiXIni,hGuess,...
      hAvg,xDeduct, sx,xEarn,VPrime,bequIn,BTold,vh1Child,TOLERANCE,hhOpt, ...
      h1Inv,valAbil,hAvgx,T1, dbg);

    if bequ <= 0
        % ** There is no bequest motive => no second round.
        done = 1;
    elseif bequIn > 0
        % ** It was assumed that bequ motive operative.
        % ** Check that BT > 0
        if BT >= 0
            done = 1;
        else
            % ** Switch bequOper
            bequOper = 0;
            disp('HHProb: Second attempt without bequest motive.')
        end
    else
        % ** It was assumed that bequ motive was NOT operative
        % ** Check FOC for BT
        [tmp, ucT] = ufct(c(T),l(T));
        MuRatio = (bb^T * ucT / (1+tc(T))) / (bequ*VPrime/tbP1);
        if MuRatio >= 1
            done = 1;
        else
            % ** Switch to operative bequ motive
            bequOper = 1;
            disp('HHProb: Second attempt with bequest motive.')
        end
    end

    attempt = attempt + 1;
end % while


if done == 0
   % ** Both tries were unsuccessful.
   abort('Cannot solve hh problem')
end


% **************  CHECK RETURN VALUES  *************

if dbg > 5
    % *******  Negative work time  ******
    %   wt = 1 - l - v;
    if any(1-l-v < -1e-4)
        warnmsg(['HHProb: Negative work times:  ', num2str(min(1-l-v)) ])
    end
end

% *** end function ***

