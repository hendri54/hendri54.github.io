function [tw,to,tc,tk,GY,TrY,DY,sx,taxb] = endopol(...
    TP, Y,K,k,X, tw,tk,tc,to,GY,TrY,DY,sx,ddk,Debt1, tax0,tax9,taxE,other,...
    twTaxBase, toTaxBase, tcTaxBase, tkTaxBase, tbTaxBase,taxb, Xx, dbg);
% endogpol: Path of endogenous policy variables
% ---------------------------------------
% TASK:
%   Path of endogenous policy variables
% IN:
%   TP
%   Tax bases (1xN):
%           twTaxBase, toTaxBase, tcTaxBase, tkTaxBase
%   k       1xN
%   ddk
%   Y       1xN
%   K       1xN
%   Paths for all policies (1xN):
%           tk, tw, to, tc, GY, TrY
%   Debt1
%       initial stock of debt at t=1
%   Xx      aggregate spending on h1 investment (goods inputs)
%   other, tax0, tax9, taxE
%       defined in expmt()
%       tax0 must contain the REALIZATION of the endogenous policy!
% OUT:
%   1xN paths of ALL policy variables

% REM:
%   Not implemented for tk or taxb being the endogenous tax rate
% ERRORS:
%
% TEST:
%   t_endopo
% AUTHOR: Lutz Hendricks, 1993
% ---------------------------------------

% *** GLOBALS ***

global tkAdjustsG twAdjustsG GYAdjustsG TrYAdjustsG DYAdjustsG tcAdjustsG
global UNCHANGED UNDEFINED toAdjustsG
global hhDebug iniAge h1Invest

v_check( dbg, 'i', [1,1], 0, UNDEFINED );

if h1Invest == 1
    abort('EndoPol: Not adapted for h1 investment')
    % Add: Handling of sxx, Xx
end
sxx = 0;


% ******  INPUT CHECK  ********

    T       = other(1);
    N       = other(2);
    taxAdjE = other(3);
    kDeduct = other(4);
    T1      = other(5);
    xDeduct = other(6);
    xEarn   = other(7);
    taxAdjTP= other(8);
    taxAdj0 = other(9);
    [tw0,tk0,TrY0,GY0,tc0,to0,DY0,sx0,ts0,RR0,taxb0,sxx0,twx0] = taxvec(tax0);
    [tw9,tk9,TrY9,GY9,tc9,to9,DY9,sx9,ts9,RR9,taxb9,sxx9,twx9] = taxvec(tax9);
    [twE,tkE,TrYE,GYE,tcE,toE,DYE,sxE,tsE,RRE,taxbE,sxxE,twxE] = taxvec(taxE);


    if 0
        if any(size(Debt1) ~= [1,1])
            abort('Invalid size of Debt1')
        end
        tmp = [tk; tw; to; tc; GY; TrY; X];
        if size(tmp,2) ~= N
            abort('Invalid size of policy inputs')
        end
        if isempty(ddk)
            abort('Empty ddk')
        end
        if any(Y<=0) | any(K<=0) | any(k<=0)
            abort('Negative Y,K,k')
        end
    end
    % Negative values for tw and tk tax bases are possible. During tran-
    % sition, investment in x may go up.
    if 0
        if any(toTaxBase <=0) | any(twTaxBase<=0) | any(tkTaxBase<=0)
            warnmsg('EndoPol: Negative tax bases')
            toTaxBase
            twTaxBase
            tkTaxBase
        end
    end


    if taxAdjE == tkAdjustsG | taxAdjE == DYAdjustsG | taxAdjTP == tkAdjustsG
        abort('Not implemented for tk or DY as adjusting tax rate')
    end



% *****  INITIALIZATION  ******

    Ynet = Y - ddk.*K;
    r1  = 1 + rnet(k, tk, kDeduct, ddk);
    TPidx = 1:TP;
    TPNidx = TP+1:N;


% ***************  TRANSITION PERIOD  ***************************

    % ******* Initialize policies that are specified to be UNCHANGED *****
    if  all( tw9 == UNCHANGED )
        tw(TPidx) = tw0 .* ones(1,TP);
    end
    if  all( tk9 == UNCHANGED )
        tk(TPidx) = tk0 .* ones(1,TP);
    end
    if  all( TrY9 == UNCHANGED )
        TrY(TPidx) = TrY0 .* ones(1,TP);
    end
    if  all( GY9 == UNCHANGED )
        GY(TPidx) = GY0 .* ones(1,TP);
    end
    if  all( tc9 == UNCHANGED )
        tc(TPidx) = tc0 .* ones(1,TP);
    end
    if  all( to9 == UNCHANGED )
        to(TPidx) = to0 .* ones(1,TP);
    end
    if  all( DY9 == UNCHANGED )
        DY(TPidx) = DY0 .* ones(1,TP);
    end
    if  all( sx9 == UNCHANGED )
        sx(TPidx) = sx0 .* ones(1,TP);
    end
    if  all( taxb9 == UNCHANGED )
        taxb(TPidx) = taxb0 .* ones(1,TP);
    end


    % **** Tax rates ****
    %   set the endogenous tax rate to zero for computation of revenue

    % ** Transition:
    if taxAdjTP == twAdjustsG
        taxBaseTP = twTaxBase;
        polNameTP = 'tw';
    elseif  taxAdjTP == GYAdjustsG
        taxBaseTP = -Ynet;
        polNameTP = 'GY';
    elseif  taxAdjTP == TrYAdjustsG
        taxBaseTP = -Ynet;
        polNameTP = 'TrY';
    elseif  taxAdjTP == DYAdjustsG
        taxBaseTP = [];
        polNameTP = 'DY';
    elseif  taxAdjTP == tcAdjustsG
        taxBaseTP = tcTaxBase;
        polNameTP = 'tc';
    else
        abort('Invalid taxAdjTP')
    end
    eval([ polNameTP, '(TPidx) = zeros(1,TP);' ]);



    % ** show name of endogenous policy
    if 0
        disp(['Adjusting until TP: ', polNameTP ])
    end

    % ** All tax and revenue components; excluding endogenous components
    % ** Valid only for 1:TP!
    G  = GY .* Y + sx.*(1-xEarn).*X;
    Tr = TrY .* Ynet;
    tcRev = tc .* tcTaxBase;
    twRev = tw .* twTaxBase;
    toRev = to .* toTaxBase;
    tkRev = tk .* tkTaxBase;
    tbRev = taxb .* tbTaxBase;


  if  taxAdjTP ~= DYAdjustsG
    % *******************  DEBT EXOGENOUS  ***************
    D = [ Debt1, DY(1:N-1).*Y(2:N) ];
    % ** D(t+1); value for N irrelevant here
    D1 = [ D(2:N), D(N) ];

    % ** Debt service
    DSpend = D .* r1;

    Deficit = G + Tr + DSpend - tcRev - twRev - toRev - tkRev - tbRev - D1;

    polTP = Deficit(TPidx) ./ taxBaseTP(TPidx);
    eval([ polNameTP, '(TPidx) = polTP;' ]);


  else  % ******************  DEBT ADJUSTS  ***********************

    D = zeros(1,TP);
    D(1) = Debt1;
    for t = 1 : TP
        D(t+1) = r1(t)*D(t) + G(t) + Tr(t) - tcRev(t) - twRev(t) - toRev(t)...
            - tkRev(t) - tbRev(t);
    end
    DY(TPidx) = D(2:TP+1) ./ Y(2:TP+1);

  end



% ************************  AFTER TRANSITION  **************************

    % ** Initialize policies that are specified to be UNCHANGED
    if  all( twE == UNCHANGED )
        tw(TPNidx) = tw(TP) .* ones(1,N-TP);
    end
    if  all( tkE == UNCHANGED )
        tk(TPNidx) = tk(TP) .* ones(1,N-TP);
    end
    if  all( TrYE == UNCHANGED )
        TrY(TPNidx) = TrY(TP) .* ones(1,N-TP);
    end
    if  all( GYE == UNCHANGED )
        GY(TPNidx) = GY(TP) .* ones(1,N-TP);
    end
    if  all( tcE == UNCHANGED )
        tc(TPNidx) = tc(TP) .* ones(1,N-TP);
    end
    if  all( toE == UNCHANGED )
        to(TPNidx) = to(TP) .* ones(1,N-TP);
    end
    if  all( DYE == UNCHANGED )
        DY(TPNidx) = DY(TP) .* ones(1,N-TP);
    end
    if  all( sxE == UNCHANGED )
        sx(TPNidx) = sx(TP) .* ones(1,N-TP);
    end
    if  all( taxbE == UNCHANGED )
        taxb(TPNidx) = taxb(TP) .* ones(1,N-TP);
    end


    % ****  RECOMPUTE THE DEFICIT  ******
    if taxAdjE == twAdjustsG
        taxBase = twTaxBase;
        polName = 'tw';
    elseif  taxAdjE == GYAdjustsG
        taxBase = -Ynet;
        polName = 'GY';
    elseif  taxAdjE == TrYAdjustsG
        taxBase = -Ynet;
        polName = 'TrY';
    elseif  taxAdjE == DYAdjustsG
        abort('DY cannot adjust after TP')
        taxBase = [];
        polName = 'DY';
    elseif taxAdjE == tcAdjustsG
        taxBase = tcTaxBase;
        polName = 'tc';
    else
        abort('Invalid taxAdjE')
    end
    eval([ polName, '(TPNidx) = zeros(1,N-TP);' ]);
    if 0
        disp(['Adjusting after TP: ', polName ])
    end


    D = [ Debt1, DY(1:N-1).*Y(2:N) ];
    % ** D(t+1); assumed to grow at a constant rate after N
    if D(N-1)~=0
        D1 = [ D(2:N), D(N)/D(N-1)*D(N) ];
    else
        D1 = [ D(2:N), D(N) ];
    end

    G  = GY .* Y + sx.*(1-xEarn).*X;
    Tr = TrY .* Ynet;
    tcRev = tc .* tcTaxBase;
    twRev = tw .* twTaxBase;
    toRev = to .* toTaxBase;
    tkRev = tk .* tkTaxBase;
    tbRev = taxb .* tbTaxBase;
    DSpend = D .* r1;

    Deficit = G + Tr + DSpend - tcRev - twRev - toRev - tkRev - tbRev - D1;


    % ****  ENDOGENOUS POLICY  *****
    polN  = Deficit(TPNidx) ./ taxBase(TPNidx);
    eval([ polName, '(TPNidx) = polN;' ]);


% ************  CHECK  *********

    if dbg > 0
        tcRev = tc .* tcTaxBase;
        twRev = tw .* twTaxBase;
        toRev = to .* toTaxBase;
        tkRev = tk .* tkTaxBase;
        tbRev = taxb .* tbTaxBase;
        taxRev = tcRev + twRev + toRev + tkRev + tbRev;

        Deficit = govdefic(GY,TrY,Y,Ynet,sx,xEarn,X,D,r1,taxRev,sxx,Xx);

        if  any(Deficit > 1e-4)
            warnmsg('ENDOPOL: BUDGET NOT BALANCED')
            Deficit
        end


        % ********  SHOW REVENUE SHARES  *********

        disp('EndoPol: Tax revenue shares in Ynet:');
        Y1 = Ynet(1);
        tmp = sprintf('tk: %6.3f   tw: %6.3f    tc: %6.3f   to: %6.3f', ...
            tkRev(1)./Y1, twRev(1)./Y1, tcRev(1)./Y1, toRev(1)./Y1);
        disp(tmp);
        tmp = sprintf('tb: %6.3f   sum: %6.3f', ...
            tbRev(1)./Y1, taxRev(1)./Y1);
        disp(tmp);

    end

    if any(D<0 )
        warnmsg('ENDOGPOL:  Negative debt')
    end

    % ** Consistency check
    if dbg > 0
        polchk(tw,to,tc,tk, zeros(1,N),zeros(1,N), DY,TrY,GY, N);
    end

    if 1
        disp('--- EndoPol: Returning...')
        tmp = sprintf('tw:   %5.3f - %5.3f - %5.3f', tw(1), tw(TP), tw(N));
        disp(tmp)
        tmp = sprintf('tk:   %5.3f - %5.3f - %5.3f', tk(1), tk(TP), tk(N));
        disp(tmp)
        tmp = sprintf('to:   %5.3f - %5.3f - %5.3f', to(1), to(TP), to(N));
        disp(tmp)
        tmp = sprintf('tc:   %5.3f - %5.3f - %5.3f', tc(1), tc(TP), tc(N));
        disp(tmp)
        tmp = sprintf('GY:   %5.3f - %5.3f - %5.3f', GY(1), GY(TP), GY(N));
        disp(tmp)
        tmp = sprintf('DY:   %5.3f - %5.3f - %5.3f', DY(1), DY(TP), DY(N));
        disp(tmp)
    end

% *** end function ***

