function [tax0, kDeduct,xDeduct,xEarn, taxAdj0] = bsetting(bgpNo, dbg);
% BSetting: BGP Experiment settings
% ---------------------------------------
% TASK:
%  BGP Experiment settings

% IN:
%   bgpNo   = experiment no.

% OUT:
%   tax policies on initial bgp:    tax0
%       taxAdj0 = which tax to adjust during initial bgp
%       sxx    subsidy rate on goods input in h1 investment
%       twx    tax rate (including possible subsidies) on effective labor input
%              in h1 investment; wx = MPL*(1+twx)
%   kDeduct

% REM:
%   DY:  Specified as a fraction of GDP (not NNP)
%        Note that this value depends on the length of a period => specify
%        DYAnnual!
%  Requires: calibration loaded

% AUTHOR: Lutz Hendricks, 1995-97
% ---------------------------------------

% ******  CONSTANTS  *******

    global yearsOfLife yPerPd iniAge calNo tb hhLife T1
    global twAdjustsG tkAdjustsG GYAdjustsG TrYAdjustsG DYAdjustsG UNCHANGED
    global UNDEFINED  tcAdjustsG



% *********  OTHER DEFAULTS  ********

    % ** Set to UNDEFINED to be able to check whether everything has been
    % ** initialized
    T = hhLife;
    DY0Annual = UNDEFINED;
    tw0 = UNDEFINED;
    tk0 = UNDEFINED;
    TrY0 = UNDEFINED;
    GY0 = UNDEFINED;
    tc0 = UNDEFINED;
    DY0 = UNDEFINED;
    to0 = UNDEFINED;
    sx0 = UNDEFINED;
    taxb0 = 0;
    sxx0 = UNDEFINED;
    twx0 = 0;
    taxAdj0 = UNDEFINED;


% ******  DEFAULTS  *******
% ** for base calibration

   tw0  = 0.3;
   tk0  = 0.375;
   to0  = 0.25;
   tc0  = 0.092;
   GY0  = 0.18;         % fraction of GNP
   DY0Annual = 0.37;   % fraction of GNP (not NNP!)
   TrY0     = 0.0694;  % Set this equal to TrY in base case
   TrY0Load = 0;       % Load from file? Set to bgpNo if yes.
   kDeduct  = 1;
   xDeduct  = 1;
   xEarn    = 1;
   sx0      = 0;
   sxx0     = 0.6;
   twx0     = 0.3;
   taxAdj0  = TrYAdjustsG;



% ====================== INDIVIDUAL EXPERIMENTS  ==========================


% *********  INITIAL TAX POLICIES  *****************

if bgpNo <= 40
   taxAdj0 = TrYAdjustsG;
   twx0    = tw0;    % Time cost is net of taxes

   if bgpNo == 6
      disp('--- Education inputs not deductible ---');
      xDeduct = 0;
      xEarn   = 0;

   elseif bgpNo == 7
      disp('--- No subsidy to schooling ---');
      sxx0 = 0;

   elseif bgpNo == 8
      disp('--- Policies for max. growth effect ---');
      xDeduct = 0;
      xEarn   = 0;
      sxx0 = 0;

   elseif bgpNo == 20
      disp('--- OJT subsidy ---');
      xEarn = 0;
      xDeduct = 0;
      sx0   = 0.25;

   elseif bgpNo == 21
      disp('--- OJT subsidy ---');
      xEarn = 0;
      xDeduct = 0;
      sx0 = 0.5;
   end


% *********  REDUCE GOVERNMENT  ********************

elseif bgpNo == 41
   disp('---- Cutting government in half ----')
   tw0     = 0.1;
   tk0     = tw0 + 0.1;
   to0     = 0.15;
   tc0     = 0.05;
   DY0Annual  = 0.37 / 2;     % fraction of GNP (not NNP!)
   GY0     = 0.09;        % fraction of GNP
   TrY0    = 3.5/100;
   taxAdj0 = TrYAdjustsG;
   kDeduct = 1;

elseif bgpNo == 42  |  bgpNo == 43
   disp('---- ELIMINATING GOVERNMENT ----')
   tw0     = 0;
   tk0     = 0;
   to0     = 0;
   tc0     = 0;
   DY0Annual  = 0;     % fraction of GNP (not NNP!)
   GY0     = 0;        % fraction of GNP
   TrY0    = 0;
   taxAdj0 = TrYAdjustsG;
   sxx0    = 0;
   twx0    = 0;
   kDeduct = 1;

   if bgpNo == 43
      disp('Exogenous retirement');
      to0  = 0.9;
   end

elseif bgpNo == 44  |  bgpNo == 45
   % *****  5% tax reduction  ********
   % financed by reducing lump-sum transfers
   taxChange = -0.05;
   tw0 = tw0 + taxChange;
   tk0 = tk0 + taxChange;
   tc0 = tc0 + taxChange;
   %to0 = to0 + taxChange;

   if bgpNo == 44    % Inputs not deductible
      xDeduct = 0;
      xEarn   = 0;
   elseif bgpNo == 45
      xDeduct = 1;   % Inputs fully deductible
      xEarn   = 1;
   end


% **************  EDUCATION SUBSIDIES  *******************

elseif bgpNo == 61
   disp('---- Education subsidy: 25% ----');
   sx   = 0.25;
   sxx0 = 0.25;



% ***************  TEST CASES: ONE TAX ONLY  ***************

elseif bgpNo > 800
   tw0     = 0;
   tk0     = 0;
   to0     = 0;
   tc0     = 0;
   DY0Annual  = 0;     % fraction of GNP (not NNP!)
   GY0     = 0;        % fraction of GNP
   TrY0    = 0;
   taxAdj0 = TrYAdjustsG;
   sxx0    = 0;
   twx0    = 0;
   kDeduct = 1;

   if bgpNo == 801
      tc0 = 0.2;
   end



else
   abort([ mfilename, ': Invalid bgpNo' ]);
end % switch bgpNo


% *********************  ASSEMBLE RETURN VECTORS  ***********************

    % *****  Load TrY0  ******
    if TrY0Load > 0
        abort([ mfilename, ': Must be updated!' ]);
        [priceS,agS,hhS, K,L,gr,polV0, mu, phi, c, l, v, a, h, x,util,BT,phi0,...
        ax,hx,xx ] = bgpload(TrY0Load);
        TrY0 = polV0(TrYAdjustsG);
        tmp = sprintf('TrY0 loaded from %i: %5.3f', TrY0Load, TrY0);
        disp(tmp);
    end


    % ** DY0 was specified as a fraction of ANNUAL GDP
    DY0 = DY0Annual / yPerPd;

    tax0 = [ tw0;tk0;TrY0;GY0;tc0;to0;DY0;sx0;0;0;taxb0;sxx0;twx0 ];


% *************  CHECK THAT EVERYTHING IS INITIALIZED  **************

    fehler = 0;
    if  any(tax0 == UNDEFINED)
       fehler = 1;
    end
    if  length(tax0) < 11
        fehler = 2;
    end
    if any([sxx0,twx0]) == UNDEFINED
        fehler = 3;
    end

    if fehler > 0
        fehler
        disp('tax0:')
        disp(tax0')
        DY0
        abort('Not all values were initialized')
    end



% *********************   OTHER CHECKS   *******************************


   tmp = [kDeduct,xDeduct,xEarn];
   if any(tmp) < 0  |  any(tmp) > 1
      kDeduct
      xDeduct
      xEarn
      abort([ mfilename, ':  Implausible kDeduct, xDeduct, xEarn.' ]);
   end


% *** end function ***
