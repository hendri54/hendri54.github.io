function  bgp_show(calibNo, calBgp, bgpNo, DoPrint)
% Compare results saved in bgp file with values to be matched
% ---------------------------------------
% TASK:
%  Show results of a saved bgp
% IN:
%  standard characterization of bgp file
%  DoPrint     1 => print graphs

% AUTHOR: Lutz Hendricks, 1995-97
% ---------------------------------------

global baseDir outDir
global calNo
global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
global yearsOfLife iniAge iniPop yPerPd hhLife T1 tBequ
global hcInherit tb popGrowth h1Invest
global ddk bb
global BEQUTYPE NOBEQUEST ALTRUISTIC bequ

if nargin ~= 4
   disp('Usage:  bgp_show(calibNo, calBgp, bgpNo, DoPrint) ');
   return;
end


% *** SWITCHES ***

   dbg          = 10;
   ShowAverages = 0;
   ShowAssets   = 0;
   % Show annual profiles in addition to averages?
   ShowProfiles = 1;
   % Show prices and shadow prices?
   ShowPrices = 01;
   % Show tables with hh problem? (to be pasted into excel)
   showTables = 02;
   % Print final output for paper?
   PrintFinal = 0;
   if nargin < 4
       DoPrint = 0;
   end


% *** CONSTANTS ***

   paraload(calibNo, calBgp, dbg);
   ageDiff = tb-1;
   T = hhLife;
   years = seqa(1, yPerPd, T);

   expId = [ int2str(calibNo), '-', int2str(bgpNo) ];
   disp(' ')
   disp(' ')
   disp(['---------  BGPSHOW  ', expId, ' -- ', date, '  ----------'])



% ***************  LOAD BGP RESULTS  ***************

   [priceS,agS,hhS,K,L,gr,endPol, mu,phiX, c, l, v, a, h, x, util,BT, phi0,valAbil,...
   vhx,ax,hx,xx,Xx,vh1Child,hT1,Lambda,dist,B1] = bgpload(calibNo, calBgp, bgpNo, dbg);

   % *****  Load settings  *****
   [tax0, kDeduct,xDeduct,xEarn, taxAdj] = bsetting(bgpNo, dbg);
   tax0(taxAdj) = endPol(taxAdj);


   % ***** Tax policy *****
   [tw,tk,TrY,GY,tc,to,DY,sx,tmp,tmp,taxb0,ssx0,twx0] = taxvec(tax0);



% ************ Compute properties of bgp ****************

    wt = 1 - l - v;
    k = K / L;

    [ Y, MPK, MPL ] = prodfct(K,L);
    Ynet = Y - ddk*K;
    Tr = TrY * Ynet;
    G = GY * Y;
    D = DY * Y;
    C = aggregx(iniPop, popGrowth, gr, c);
    X = aggregx(iniPop, popGrowth, gr, x);

    % Investment shares
    Inet = K * (gr * popGrowth - 1);
    Igr  = Inet + K * ddk;
    InetY = Inet / Ynet;
    IgrY  = Igr  / Ynet;

    % Observed GNP does not include x
    GNP = Y - X;
    NNP = Ynet - X;

    % Aggregate wealth at the beginning of t=1
    AggrWealth = (K+D);
    [rV,w, tl] = bgprw( MPK, MPL, tk,tw,0,to, kDeduct, ddk,T1,T );
    r = rV(1);
    Ri = cumprod([1, 1+rV(2:T)]);
    grn = gr * popGrowth;

    % ** Bequest received by generation 1 at date tBequ; per capita
    %    B1 = BT / grn^ageDiff;
    % ** Aggregate bequest received at 1; NOT received by generation 1 !!
    % ** discounted to beginning of t=1
    B1aggr = iniPop * BT / grn^T;

    % ** Net hh income
    netHhInc = hhincome(w,h,wt,tl, x,xEarn,xDeduct, a,rV, Tr);
    % ** Average annual (!) hh income
    avgAnnInc = sum(netHhInc) / yearsOfLife;

    % ** Growth rates are per PERIOD (not year)!
    if h1Invest == 1
       hEndowment = hx(1);
    else
       hEndowment = h(1);
    end
    gr = grrate([h,hT1], hEndowment, agS.hAvg, dbg);
    lShare = aggregx(1, popGrowth, 1,  l) ./ popsize( 1, popGrowth, T );
    cGrowth = ( c(T)/c(1) ) ^ (1/T);


    % ** Transform into annual growth rates
    expon = 1/yPerPd;
    cGrowth = (cGrowth^expon - 1) * 100;
    grAnn  = (gr^expon - 1) * 100;
    rGrAnn = ((1+MPK-ddk)^expon - 1) * 100;
    rAnn   = ((1+rV(1))^expon - 1) * 100;
    DYAnnual = DY * yPerPd;



% *************  SHOW FOR COMPARISON  ****************
   if 0
      % Shows tables with household variables
      hhshow(c,x,a,h,l,v, B1,BT,tBequ,taxb0, w,Ri,T1, ax,hx);
   end


% **************  RESULTS TO BE MATCHED  **************

    [grM, rGrM, lM] = matchval(dbg);

    % ** Transform into annual growth rates
    grM = (grM^expon - 1) * 100;
    rGrM = ((1+rGrM)^expon - 1) * 100;


% **************  SHOW THEM  ************************

    disp(' ')
    disp('--- Policies ---')
    disp(sprintf('tk:    %6.3f       tl: %6.3f to %6.3f %%', ...
        tk*100, tl(1)*100, tl(T)*100));
    disp(sprintf('tc:    %6.3f       to: %6.3f %%', tc*100, to*100));
    disp(sprintf('GY:    %6.3f      TrY: %6.3f     DY: %6.3f %%',...
            GY*100, TrY*100, DYAnnual*100));
    disp(sprintf('sx:    %6.3f    xEarn: %6.3f', sx, xEarn));



    % *********  HUMAN WEALTH  *********
    % ** Def.: Gross earnings minus goods inputs; present value at beginning
    % ** of t=1
    hWealth = 0;
    % Earnings before taxes
    grEarn = MPL.*h.*wt - x;
    for i = 1 : T-1
        idx = i:T;
        rvec  = r.*ones(1,length(idx));
        % human wealth of an agent aged i at t=1
        indHWealth = prvalue(grEarn(idx), rvec) / gr^(i-1);
        if i == 1
            hWealthGen1 = indHWealth;
        end
        hWealth = hWealth + indHWealth * iniPop / popGrowth^(i-1);
        if 0
            tmp = sprintf('age: %3i   indHWealth: %6.2f   hWealth: %6.2f',...
                i, indHWealth, hWealth);
            disp(tmp);
        end
    end
    % ** Generation T
    if grEarn(T) > 0
        hWealth = hWealth + iniPop * grEarn(T) / (gr*popGrowth)^(T-1) / (1+r);
    end


    tmp = sprintf('Terminal distance: %7.4f', dist);
    disp(tmp);




% *************  PRICES AND SHADOW PRICES  *********************

if ShowPrices == 1
   ageV = iniAge + (0 : T-1);

   subplot(2,2,1);
   plot( ageV, [w;rV] );
   title( ['w, r    ', expId] );
   xlabel( 'Age' );

   subplot(2,2,2);
   plot( ageV, phiX );
   title( 'phiX' );
   xlabel( 'Age' );

   subplot(2,2,3);
   plot( ageV, mu );
   title( 'Mu' );
   xlabel( 'Age' );

   subplot(2,2,4);
   plot( ageV, phiX .* Lambda ./ Ri );
   title( 'phi' );

   pause_print(DoPrint);
end



% **********************  PLOTS BY AGE  *************************
if ShowProfiles == 1
   ageV = iniAge + (0 : T-1);
   % Wages before taxes
   wage = MPL .* h .* wt ./ (1-l);
   % Earnings before taxes
   % - do not subtract x for plotting observed profiles!
   earn = MPL.*h.*wt;

   % *** Target values ***
   % Plot group average at group mid-points
   age2V   = [20, 30,   40,   50,   60];
   %wage2V  = [1,  1.63, 1.99, 2.17, 2.31];
   wage2V  = [1,  1.47, 1.63, 1.61, 1.55];
   hours2V = [1,  1.11, 1.17, 1.16, 0.79];
   earn2V  = wage2V .* hours2V;
   ojt2V   = [0.15, 0.1, 0.071, 0.028, 0.012];
   % ** Per capita asset holdings; cross-sectional
   % ** From Stat.Abstr.of U.S.
   aYears  = [ 35, 45, 55, 65, 75 ];
   a2V     = [ 0.16, 0.51, 0.98, 1, 0.95 ];
   % ** Wealth holdings from Huggett (1996)
   aYears  = 20 : 10 : 80;
   a2V     = [10       25      63      100     118     100  80];


   % *******  earnings, time allocation  *********************

   subplot(2,2,1);
   earnV  = earn ./ earn(1);
   earn2V = earn2V ./ earn2V(1);
   plot( ageV, earnV, 'b-',  age2V, earn2V, 'go-' );
   title( ['Earnings before tax  ', expId] );
   xlabel( 'Age' );

   subplot(2,2,2);
   ojtV = v ./ (1-l);
   plot( ageV, ojtV, 'b-',  age2V, ojt2V, 'go-' );
   title( 'OJT/Mk Time' );
   xlabel( 'Age' );

   subplot(2,2,3);
   % Match at the peaks
   [tmp, tmp, maxC] = maxidx( wage2V );
   maxAge = 1 + (age2V(maxC) - iniAge) / yPerPd;
   wageV  = wage./wage(maxAge);
   wage2V = wage2V./wage2V(maxC);
   plot( ageV, wageV, 'b-',  age2V, wage2V, 'go-' );
   title( 'Gross Wages' );
   xlabel( 'Age' );

   subplot(2,2,4);
   % Match at the peaks
   [tmp, tmp, maxC] = maxidx( hours2V );
   maxAge  = 1 + (age2V(maxC) - iniAge) / yPerPd;
   hoursV  = (1 - l)./(1-l(maxAge));
   hours2V = hours2V./hours2V(maxC);
   mkTimeV = (1 - l - v) ./ (1-l(maxAge)-v(maxAge));
   plot( ageV, hoursV, 'b-',  ageV, mkTimeV, 'r-',...
     age2V, hours2V, 'go-' );
   title( 'Hours' );
   xlabel( 'Age' );

   pause_print(DoPrint);


   % *******  ASSETS, x, leisure  *******
   subplot(2,2,1);
   % Match at the peaks
   [tmp, tmp, maxC] = maxidx( a2V );
   maxAge  = 1 + (aYears(maxC) - iniAge) / yPerPd;
   assetV  = a./a(maxAge);
   asset2V = a2V./a2V(maxC);
   plot(ageV, assetV, 'b-',  aYears, asset2V, 'go-');
   title(['Asset holdings  ', expId]);

   subplot(2,2,2);
   plot( ageV, x, 'b-' );
   title('Goods inputs');

   subplot(2,2,3);
   plot(ageV, [l; v; 1-l-v]);
   title('l, v, 1-l-v');

   subplot(2,2,4);
   plot(ageV, c);
   title('c');

   pause_print(DoPrint);



   % *************  GROWTH ADJUSTED PATHS  ******************
   subplot(2,2,1);
   plot( ageV, x ./ gr.^ageV );
   title('x  growth adjusted');

   subplot(2,2,2);
   plot( ageV, h );
   title('h unadjusted');

   pause_print(DoPrint);


    % **********  EXCEL TABLES  ************
    if showTables == 2
       % *** Show data table for Excel ***
       % Scaled variables
       disp('------  Model Data for Excel  ---------');
       disp([ ageV; earnV; ojtV; wageV; hoursV; assetV; x; mkTimeV ]');
    end

    if 0
       % *** Show data table for Excel ***
       disp('------  U.S. Data for Excel  ---------');
       disp([ age2V; earn2V; ojt2V; wage2V; hours2V]');
       disp(' ');
       disp('-- Assets --');
       disp([ aYears; asset2V ]');
    end

end % show profiles



% *****************  TABLE OF PROFILE DATA  *********************************
% Not scaled ==> allow comparison of two bgps

if showTables == 1
   disp(' ');
   disp('---- Age Profiles: Earnings, v/(1-l), h, (1-l-v), Assets, x ----');
   disp(' ');
   ageV = iniAge + (0:T-1);
   tV   = 1:T;
   tmp       = find( l < 1 );
   ojtV      = zeros(1, T);
   ojtV(tmp) = v(tmp)./(1-l(tmp));
   disp([ ageV; h.*wt; ojtV; h; wt; a; x ]');
end






% ************  MISCELLANEOUS  ********************

if 0
    disp(' ')
    tmp = sprintf('K(1): %5.3f     L(1): %5.3f   Y: %5.3f   Ynet: %5.3f', ...
        K(1), L(1), Y, Ynet);
    disp(tmp);
    tmp = sprintf('C:    %5.3f   C/Ynet:  %5.3f', C, C/Ynet);
    disp(tmp);
    if B1aggr > 0
        tmp = sprintf('Aggr. Bequest: %5.2f   Fraction of K+D: %5.2f (%%, annual)', ...
            B1aggr, B1aggr/(K(1)+D)*100/yPerPd);
        disp(tmp);
        tmp = sprintf('Bequ. rec. as fraction of annual income: %6.2f', ...
            B1/avgAnnInc);
        disp(tmp)
    end
end


% *****************  TABLE 2 IN PAPER  ***************************
if 1
   % ** Private net worth / Disposable income
   % Discounted to beginning of t=1
   % See Hubbard/Skinner/Zeldes (1993), flow of funds value
   AIratio = AggrWealth / (Ynet-G) * (1+r) * yPerPd;


   disp(' ');
   disp('----- Table 2 -----');
   disp(' ');
   disp('Data/Model');
   disp(' ');

   KYtarget = 2.5;
   IYtarget = KYtarget*(0.017+0.0124+0.05);
   CYtarget = 1 - IYtarget - GY;
   disp(sprintf( 'Cons / GNP:       %6.2f   %6.2f',  CYtarget,  C/GNP ));
   disp(sprintf( 'Inet / GNP:        %6.3f   %6.3f', KYtarget*(0.017+0.0124), Inet/GNP ));
   disp(sprintf( 'I    / GNP:       %6.2f   %6.2f',  IYtarget,  Igr/GNP ));
   disp(sprintf( 'G    / GNP:       %6.2f   %6.2f',  GY,  G/GNP ));
   disp(sprintf( 'K    / GNP:      %6.1f   %6.1f',   KYtarget, K/GNP*yPerPd ));
   %disp(sprintf( 'Assets/Income:    %6.2f   %6.2f',  4.64,   AIratio ));
   if BEQUTYPE ~= NOBEQUEST
      disp(sprintf( 'Bequ / Wealth:    %6.2f   %6.2f',  1.0,   100*B1aggr/AggrWealth ));
   end

   disp(' ');
   disp('------ Table 3 -------');
   disp(' ');
   disp(sprintf( 'X / GNP:               %6.2f', X/GNP ));
   disp(sprintf( 'Leisure share:         %6.2f', lShare ));
   disp(sprintf( 'Interest (hh):         %6.2f', rAnn ));
   disp(sprintf( 'Int. (pre-tax):        %6.2f', rGrAnn ));
   disp(sprintf( 'Growth rate:           %6.2f', grAnn ));
   disp(sprintf( 'Human/nonhuman wealth: %6.2f', hWealth/AggrWealth));
end


disp(mfilename);
keyboard

% *** end function ***

