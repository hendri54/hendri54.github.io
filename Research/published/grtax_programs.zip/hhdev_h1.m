function [maxDev, dev] = hhdev_h1(ax, hx, vhx, xx, wx, cxx, hAvgx, r, dV_da1, dV_dh1, a1, h1);
% Deviatons for hh problem for investment in h1
% ---------------------------------------
% TASK:
%  This directly checks the analytical FOCs and
%  the laws of motion.

% IN:
%  Standard notation; also as in h1invest.m
%  ax       1:Tx+1; last element is a1
%  hx       1:Tx+1; last element is h1
%  wx       scalar
%  cxx      scalar

% OUT:
%  dev      deviations to be set to zero; absolute values
%  maxDev   max(dev)

% AUTHOR: Lutz Hendricks, 1997
% ---------------------------------------


% *** CONSTANTS ***

global Bx ddhx etax psix h1Invest UNDEFINED Tx
zetax = 1 - psix - etax;
fName = mfilename;
% Everything smaller will be considered zero:
RoundoffTol = 1e-4;
dbg = 100;

v_check( ax, 'f',  [1,Tx+1], UNDEFINED, UNDEFINED );
v_check( hx, 'f',  [1,Tx+1], 0, UNDEFINED );
v_check( vhx, 'f', [1,Tx], 0, 1 );
v_check( xx, 'f',  [1,Tx], 0, UNDEFINED );
v_check( wx, 'f',  [1,1],  0, UNDEFINED );
v_check( cxx, 'f', [1,1],  0, UNDEFINED );
v_check( hAvgx, 'f', [1,Tx], 0, UNDEFINED );


% *****  AUXILIARY VARIABLES  ******

% Production
G  = Bx .* vhx.^psix .* xx.^etax .* hAvgx.^zetax;
Gv = psix .* G ./ vhx;
Gx = etax .* G ./ xx;

% Vector of factors to compute future values
fvVec = (1+r).^(Tx-(1:Tx));

phiStar = dV_dh1 .* (1-ddhx).^(Tx-1 : -1 : 0);


% ===========================  CHECK  FOC  ====================================

dev = zeros(1,8);

% Law of motion for h
dev(1) = max(abs( hx(2:Tx+1) ./ ((1-ddhx) .* hx(1:Tx) + G) - 1 ));

% Computation of h1
dev(2) = abs( h1 ./ hx(Tx+1) - 1 );

% Compuation of a1
% Flow expenditure
expend = wx .* vhx + cxx .* xx;
dev(3) = abs( a1 + sum( fvVec .* expend ) );

% FOC for v and x
dev(4) = max(abs( Gv .* phiStar - dV_da1 .* wx  .* fvVec ));

dev(5) = max(abs( Gx .* phiStar - dV_da1 .* cxx .* fvVec ));

% LOM for phiStar
dev(6) = max(abs( phiStar(2:Tx) .* (1-ddhx) ./ phiStar(1:Tx-1) - 1 ));

% LOM for assets
dev(7) = max(abs( ax(2:Tx+1) - (ax(1:Tx).*(1+r) - expend) ));

dev(8) = abs( ax(Tx+1) - a1 );

maxDev = max(dev);

%mfilename
%keyboard


% *** end function ***

