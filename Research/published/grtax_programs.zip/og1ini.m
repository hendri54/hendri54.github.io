% OG1INI.M
% TASK: Initialization of globals for OG1 Project
% This file initializes everything that is strictly constant, i.e., that
% does not depend on any experiment settings.

global baseDir outDir calDir bgpDir
baseDir = 'c:\econ\olg\grtax1';
outDir  = [ baseDir, '\out\' ];
calDir  = [ baseDir, '\cal\' ];
bgpDir  = [ baseDir, '\bgp\' ];
jmrDir  = 'c:\econ\matlab\jmr\';
addpath([ baseDir, '\shared' ]);

global bequ bb sig rho nu
global A aa
global B psi eta ksi zeta gg ddh ddk
global yearsOfLife hcInherit yPerPd hhLife
global sigMin


% ************  DEMOGRAPHICS  **************
global hcAge tb iniAge popGrowth T1
global tbYear tBequ


% ************  Hc technology for investing in h1  ***************
global Bx etax ddhx Tx psix ksix

%   *****  Globals holding hh problem results  ********
global llG mustarG
global lG cG vG hG
global KG LG



% ******  NAMED CONSTANTS  ********

    global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
    global tcAdjustsG toAdjustsG sxAdjustsG UNDEFINED

    % ** These indexes must follow the standard sequence of policy variables
    % ** defines in expmt.m
    twAdjustsG  = 1;
    tkAdjustsG  = 2;
    TrYAdjustsG = 3;
    GYAdjustsG  = 4;
    tcAdjustsG  = 5;
    toAdjustsG  = 6;
    DYAdjustsG  = 7;
    sxAdjustsG  = 8;

    % When is an exponent too large?
    global LargeExpG
    LargeExpG = 6;
    % Specifies that somethings stays unchanged:
    UNCHANGED = - 11;
    UNDEFINED = -999;

    % ** What type of bequest?
    global ALTRUISTIC NONALTRUISTIC NOBEQUEST BEQUTYPE hcAltruism
    ALTRUISTIC = 1;
    NONALTRUISTIC = 2;
    NOBEQUEST = 3;
    %FULLBEQUEST = 4;
    BEQUTYPE = ALTRUISTIC;
    % ** Do parents take into account that they bequeath hc?
    hcAltruism = 0;

    % ********* Loaded h profiles  ************
    % ** calibration and experiment from which to load h profile
    % ** if h endogenous: set both to zero
    global hfCalNo hfExpNo hExog
    hfCalNo = 0;
    hfExpNo = 0;
    hExog = UNDEFINED;


% *** end function ***
