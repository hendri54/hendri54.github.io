function cx = x_cost(tl, sx, xEarn, xDeduct);
% Cost of x to household after taxes
% IN:
%  policies in standard notation
% -------------------------------------------------

cx = (1 - (1-xEarn).*(sx + tl.*xDeduct) - tl.*xEarn);

% *** end function ***
