function  bgpcmp(calNoIn, bgp1, bgp2, doPrint);
% Compare 2 bgp files
% ---------------------------------------
% IN:
%   calNoIn    calibration to use
%   bgp1       expNo for base bgp
%   bgp2       bgp to be compared with base
% OUT:
%

% AUTHOR: Lutz Hendricks, 1993-97
% ---------------------------------------

% *** SWITCHES ***

dbg = 10;
if nargin ~= 4
   disp(' ');
   disp('Usage: bgpcmp(calNo, bgp1, bgp2, doPrint)');
   disp(' ');
   return
end

% Show plots with age profiles?
showProfiles = 0;
% Show tables for Excel?
ShowTables = 0;


% *** CONSTANTS ***

global baseDir outDir
global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
global yearsOfLife iniAge iniPop T1 hhLife yPerPd
global hcInherit tb popGrowth
global ddk bb sig
global calNo
style1 = 'k-';
style2 = 'ko-';
style3 = 'kx-';
style4 = 'kd-';
expId = sprintf('%i-%i-%i', calNo, bgp1, bgp2);

paraload(calNoIn, bgp1, dbg);
ageDiff = tb-1;
T = hhLife;
years = seqa(1, yPerPd, T);


% ***************  LOAD BGP 1  ***************

   [priceS,agS,hhS,K_,L_,gr_,polV1, mu, phi, c, l_1, v_1, a_1, h_1, x_1,util,BT,phi0,valAbil,...
   vhx,ax,hx,xx,Xx,vh1Child,hT1,Lambda,dist,B1 ] = bgpload(calNoIn,bgp1,bgp1,dbg);

   %[gr_,C_,polV1_,h_,r_,wNet_,HStock1] = bgpchar2(calNoIn,bgp1,bgp1, dbg);

   gr1 = agS.gr;
   K1  = agS.K;
   L1  = agS.L;
   Y1  = agS.Y;
   k1  = agS.k;
   C1  = agS.C;
   X1  = agS.X;
   Ynet1 = Y1 - ddk.*K1;
   CY1 = agS.C / Ynet1;

   GNP1 = Y1 - X1;
   I1 = K1 * (gr1 * popGrowth - (1-ddk));

   r1 = priceS.r(1);
   wNet1 = priceS.w(1);

   h1 = hhS.h;
   wt_1 = 1 - l_1 - v_1;

   % ***** Tax policy *****
   [tw1,tk1,TrY1,GY1,tc1,to1,DY1,sx1,tmp,tmp,taxb1,ssx1,twx1] = ...
      taxvec(polV1');



% ***************  LOAD BGP 2  ***************

   [priceS2, agS2, hhS2, K_,L_,gr_,polV2, mu, phi, c, l_2, v_2, a_2, h_2, x_2,util,BT,phi0,valAbil,...
   vhx,ax,hx,xx2,Xx,vh1Child,hT1,Lambda,dist,B1 ] = bgpload(calNoIn,bgp1,bgp2,dbg);

   %[K2,L2,U2,gr2,C2,polV2,h2,r2,wNet2,HStock2] = bgpchar2(calNoIn,bgp1,bgp2, dbg);

   k2 = agS2.k;
   K2 = agS2.K;
   L2 = agS2.L;
   Y2 = agS2.Y;
   C2 = agS2.C;
   gr2 = agS2.gr;
   Ynet2 = Y2 - ddk.*K2;
   CY2 = C2 / Ynet2;
   X2 = agS2.X;

   GNP2 = Y2 - X2;
   I2 = K2 * (gr2 * popGrowth - (1-ddk));

   r2 = priceS2.r(1);
   wNet2 = priceS2.w(1);

   h2 = hhS2.h;
   wt_2 = 1 - l_2 - v_2;

   % ***** Tax policy *****
   [tw2,tk2,TrY2,GY2,tc2,to2,DY2,sx2,tmp,tmp,taxb2,ssx2,twx2] = ...
      taxvec(polV2');



% **************  SHOW THEM  ************************

   %diaryon([ outDir, 'cm', int2str(calNo), '_' ], bgp2);
   disp(['---------  BgpCmp  ', int2str(calNo), '_', int2str(bgp2), ...
        ' -- ', date, '  ----------'])
   disp(sprintf('Comparing bgp %i and %i', bgp1, bgp2));
   disp(' ')
   parashow;

   disp(' ')
   disp('--- PERCENT CHANGES ---')

   s_compar( 'Growth rate', (gr1-1)*100, (gr2-1)*100, 'a' );
   s_compar( 'Net wage', wNet1, wNet2, 'p' );

   disp(sprintf('Ynet:    %6.3f -> %6.3f  =  %6.3f', ...
        Ynet1, Ynet2, (Ynet2/Ynet1-1)*100));

%    s_compar( 'H-Stock', HStock1, HStock2, 'p' );


   disp(' ')
   disp('--- Policy changes ---')
   polNo = length(polV1);
   for i = 1 : polNo
       if abs(polV1(i) - polV2(i)) > 1e-3
           tmp = sprintf('%3i:  %6.3f -> %6.3f', i, polV1(i), polV2(i));
           disp(tmp);
       end
   end


   % *********  TABLE FOR PAPER  *************
   disp(' ');
   disp('---- Table for paper ----');
   disp(' ');
   s_compar( 'GNP', GNP1, GNP2, 'p' );
   s_compar( 'K', K1, K2, 'p' );
   s_compar( 'L', L1, L2, 'p' );
   s_compar( 'C', C1, C2, 'p' );
   s_compar( 'r', r1, r2, 'a' );

   disp(' ');
   s_compar( 'K/Y', K1/GNP1, K2/GNP2, 'p' );
   s_compar( 'K/L', k1, k2, 'p' );
   s_compar( 'X/Y', X1/GNP1, X2/GNP2, 'p' );
   s_compar( 'I/Y', I1/GNP1, I2/GNP2, 'p' );
   s_compar( 'w',   wNet1,   wNet2,   'p' );



% *******************  HH PROFILES  ******************************************

if showProfiles == 1
   tV = 1 : T1;
   ageV = tV+iniAge-1;

   % **********  OJT Time  *****************
   subplot(2,2,1);
   plot( tV+iniAge-1, v_1(tV)./(1 - l_1(tV)), style1,  ...
      tV+iniAge-1, v_2(tV)./(1 - l_2(tV)), style2 );
   title([ 'OJT / Market Time  ', expId ]);

   subplot(2,2,2);
   plot( tV+iniAge-1, [ v_1(tV); v_2(tV) ] );
   title( 'OJT Time' );

   subplot(2,2,3);
   plot( tV+iniAge-1, [ (1-l_1(tV)); (1-l_2(tV)) ] );
   title( 'Market Time' );

   subplot(2,2,4);
   plot( ageV, x_1(tV), style1,   ageV, x_2(tV), style2 );
   title( 'Goods inputs' );

   pause2;
   if doPrint > 0
      print -dwin
   end
   close;
end

if showProfiles == 1
   subplot(2,2,1);
   % **********  ASSET HOLDINGS  ***********
   plot( 1:T, a_1, style1,  1:T, a_2, style2 );
   title([ 'Asset holdings  ', expId ]);

   % **********  a CHANGE  ***********
   subplot(2,2,3);
   aChange = zeros(1, T);
   idxPos = find( (a_1 > 0.1)  &  (a_2 > 0.1) );
   aChange(idxPos) = a_2(idxPos)./a_1(idxPos)-1;
   plot( 1:T, aChange, style1 );
   title( 'Change in a(t)' );

   % **********  HC PROFILES  ***********
   subplot(2,2,2);
   plot( 1:T, h_1, style1,  1:T, h_2, style2 );
   title( 'Hc Profiles' );

   % **********  HC CHANGE  ***********
   subplot(2,2,4);
   plot( 1:T, h_2./h_1-1, style1 );
   title( 'Change in h(t)' );


   pause2;
   if doPrint > 0
      print -dwin
   end
   close;
end


if 0
   subplot(2,2,1);
   % **********  HC GROWTH  ***********
   subplot(2,2,1);
   % Average growth of h by age
   h1Gr = ( h_1(1:T-1)./h_1(1) ) .^ (1 ./ (1:T-1)) - 1;
   h2Gr = ( h_2(1:T-1)./h_2(1) ) .^ (1 ./ (1:T-1)) - 1;
   plot( 1:T-1, h1Gr, style1,   1:T-1, h2Gr, style2 );
   title([ 'Average Growth of h(t)  ', expId ]);

   % **********  HC GROWTH - CHANGE  ***********
   subplot(2,2,3);
   % Change of h growth across paths by age
   plot( 1:T-1, h2Gr./h1Gr-1, style1 );
   title( 'Change in h-growth' );


   % **********  LS GROWTH  ***********
   subplot(2,2,2);
   plot( 1:T, wt_1, style1,   1:T, wt_2, style2,   1:T, wt_2-wt_1, style3 );
   title( 'Raw Work time' );

   % **********  HC GROWTH - CHANGE  ***********
   subplot(2,2,4);
   wtEff_1 = wt_1.*h_1;
   wtEff_2 = wt_2.*h_2;
   plot( 1:T, wtEff_1, style1,   1:T, wtEff_2, style2,   1:T, wtEff_2-wtEff_1, style3 );
   title( 'Effective Work time' );


   pause2;
   if doPrint > 0
      print -dwin
   end
   close;
end


% *********  H-PROFILES REQUIRED FOR GIVEN GROWTH EFFECTS  *********************
% Q: Which h-profile would produce a given growth effect?
% Compute h(t) as h0(t) * gr^t, where h0 is the h profile of the first bgp
if showProfiles == 1
   % Growth effects
   tV = 1 : T1;
   ageV = iniAge + tV - 1;
   dGr = [0.01, 0.02] + gr1;
   hV1 = (dGr(1) / gr1).^ageDiff .* h_1(tV);
   hV2 = (dGr(2) / gr1).^ageDiff .* h_1(tV);
   plot( ageV, hV1, style1,   ageV, hV2, style2,   ageV, h_2(tV)./h_2(1), style3,  ...
      ageV, h_1(tV)./h_1(1), style4 );
   title( 'H Profiles needed for growth effects' );

   pause2;
   close;

   if ShowTables == 1
      disp(' ');
      disp('--- h profiles for 1 and 2 percent growth effect ---');
      disp([ ageV; hV1; hV2 ]');
   end
end



if max(agS.dist, agS2.dist) > 5e-5
   warnmsg([ mfilename, ':  Convergence failed!' ]);
end
disp(sprintf('    Distances: %6f   %6f', agS.dist, agS2.dist));
%keyboard

% *** end function ***

