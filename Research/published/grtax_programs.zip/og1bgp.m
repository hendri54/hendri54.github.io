function dist = og1bgp(inFile, outFile, calWhat, dbg);
% OG1BGP: Solve for bgp
% ---------------------------------------
% TASK:
%   Solve for bgp.

% IN:
%  inFile
%     structure with info for file with initial guesses
%  outFile
%     structure with information for result file
%  * For calibration *
%     calWhat

% OUT:
%  terminal distance

% CHANGE:
% - when using a file as initial guess: don't use the endogenous policy guess
% - make updating of guesses more logical

% AUTHOR: Lutz Hendricks, 1993-97
% ---------------------------------------

global bb sig rho hEndowment aEndowment
global A aa ddk ddh
global B psi ddh eta zeta ksi gg h1Invest Bx
global popGrowth tb hcAge hcInherit yearsOfLife Tx iniAge yPerPd hhLife T1
global iniPop tBequ
global twAdjustsG tkAdjustsG DYAdjustsG TrYAdjustsG GYAdjustsG UNCHANGED
global tcAdjustsG toAdjustsG UNDEFINED
global bequ BEQUTYPE ALTRUISTIC NONALTRUISTIC NOBEQUEST hcAltruism
global hTarget bequTarget BxTarget calH calDdh ddhTarget calSig sigTarget calBeta
global calEta calRho etaTarget calPsi psiTarget vTarget IYTarget grTarget
global hfCalNo hfExpNo hExog
hProfile = UNDEFINED;

   v_check( dbg, 'i', [1,1], 0, UNDEFINED );
   tmpFile = outFile;
   hhOpt   = UNDEFINED;
   startTime = clock;

   disp(' ')
   disp('===========  OG1BGP: Start  ============================================');


% *******************   SWITCHES   **************************

    saveFreq  = 2;    % minutes
    showFreq  = 0.3;   % minutes
    checkFreq = 2;      % minutes
    dbgHigh   = 10;
    dbgLow    = 1;

    % Convergence tolerance
    convDist = 1e-5;
    maxIter  = 9500;
    minIter  = 10;
    maxTime  = 60;     % minutes

    % Gauss-Seidel weight
    gsw = 0.04;
    % Max changes of updated variables
    chngUp = 1.1;
    chngDn = 0.9;
    % Max change of new guesses
    chngUpN = 4;
    chngDnN = 1/4;


% **********  EXPERIMENT SETTINGS  *****************

   % Load calibration
   paraload(inFile.calNo, inFile.calBgp, dbg);
   T = hhLife;
   ageDiff = tb-1;
   h1x = hEndowment;
   a1x = aEndowment;

   % Experiment settings
   [tax0, kDeduct,xDeduct,xEarn, taxAdj0] = bsetting(inFile.bgpNo, dbg);
   [tw0,tk0,TrY,GY,tc0,to0,DY,sx0,tmp,tmp,taxb0,sxx0,twx0] = taxvec(tax0);


   if calWhat(1) ~= 1
      % Do not calibrate anything
      doCalib    = 0;
      calInvY    = 0;
      calBx      = 0;
   else
      % Calibrate some parameters
      doCalib = 1;

      calInvY    = calWhat(3);
      calBx      = calWhat(5);
      if calInvY == 1
         % Bounds on ddk
         ddkMin = 1 - (1-0.03) ^ yPerPd;
         ddkMax = 1 - (1-0.1)  ^ yPerPd;
      end
   end


   % ** Exogenous Parameters **
   if calEta == 1
      etaStep = (etaTarget - eta) / 500;
   end
   if calDdh == 1
      %ddhStep = (ddhTarget - ddh) / 700;
      if ddhTarget > ddh
         ddhStep = 0.00025;
      else
         ddhStep = -0.00025;
      end
   end
   if calSig == 1
      if sigTarget > sig
         sigStep = 0.005;
      else
         sigStep = -0.005;
      end
   end
   if calPsi == 1
      psiStep = (psiTarget - psi) / 700;
   end
   if bequTarget.calBequ == 1
      if bequTarget.bequ > bequ
         bequStep = 0.002;
      else
         bequStep = -0.002;
      end
   end
   if calBeta.calType == 2
      if calBeta.bbTarget > bb
         betaStep = 0.001;
      else
         betaStep = -0.001;
      end
   end
   if calRho.calType == 2
      if calRho.rhoTarget > rho
         rhoStep = 0.002;
      else
         rhoStep = -0.002;
      end
   end


% *******************  CONSTANTS  ***************************

   %   Total population
   totalPop = popsize( iniPop, popGrowth, T );
   %   The current generation is this fraction of the total population:
   populShare = iniPop / totalPop;
   %   Ratio of young/old generation = no of children per parent
   popRatio = popGrowth^ageDiff;


   %   Find bounds on K/L that yield reasonable interest rates
   rMin = 1.025 ^ yPerPd - 1;
   rMax = 1.15 ^ yPerPd - 1;
   [ kMin, kMax ] = kbounds(rMin, rMax, tk0,kDeduct,ddk);

   %   Bounds on growth rates
   %   Make them relatively wide because they are used for grN
   grMin = 1.01 ^ yPerPd;
   grMax = 1.09  ^ yPerPd;


   % ** Name of the endogenous policy variable
   if taxAdj0 == twAdjustsG
       endPolName = 'tw0';
   elseif taxAdj0 == tkAdjustsG
       endPolName = 'tk0';
   elseif taxAdj0 == DYAdjustsG
       endPolName = 'DY';
   elseif taxAdj0 == GYAdjustsG
       endPolName = 'GY';
   elseif taxAdj0 == TrYAdjustsG
       endPolName = 'TrY';
   elseif taxAdj0 == tcAdjustsG
       endPolName = 'tc0';
   else
       abort('Og1Bgp: Unknown endogenous policy name')
   end


% *********  INITIAL GUESSES  *********************

   % *** Load initial guesses ***
   [priceS,agS,hhS,K,L, gr, pol0V, mu, phiX, c,l,v,a,h,x,tmp,...
   BT,phi0,valAbil,vhx0,ax0,hx0,xx0,Xx0,vh1Child0,hT10,Lambda,dist0,B1 ] =...
       bgpload(inFile.calNo, inFile.calBgp, inFile.bgpNo, dbg);


   % +++ should be loaded/saved
   if 01
      VPrime = hhS.VPrime;
      hAvg = agS.hAvg(1);
      X    = agS.X;
      C    = agS.C;
      k    = agS.k;
      L    = agS.L;
      K    = agS.L;
      Lold = agS.Lold;
      Xold = agS.Xold;
      Xx   = agS.Xx;
      B1  = hhS.B1;
      BT  = hhS.BT;
      Lambda = hhS.Lambda;
   else
      if tBequ > 0
         % ** Marginal value of bequest: bequ * VPrime
         % Parent and child overlap
         [tmp, muChild] = ufct( c(tBequ)*gr^ageDiff, l(tBequ) );
      elseif tBequ == 0
         % Child born one period after parent dies
         [tmp, muChild] = ufct( c(1)*gr^ageDiff, l(1) );
         muChild = muChild * bb * (1+priceS.r);
      else
         abort([ mfilename, ': Invalid tBequ' ]);
      end
      VPrime = bb^T * muChild / (1+tc0);

      hAvg(1) = aggregx(iniPop, popGrowth, gr, h) ./ totalPop;

      X = aggregx(iniPop, popGrowth, gr, x);
      k = K / L;
   end

   wt = max(1-l-v, 0);
   c1 = c(1);

   % ** Use policy guess
   policyGuess = pol0V(taxAdj0);
   eval([ endPolName,'=policyGuess;' ]);



% ********  SETTINGS  *****************************

    disp(' ')
    disp('----------------  Og1Bgp: Settings  ------------------');
    disp(sprintf('tk:   %5.3f    tw:   %5.3f', tk0,tw0));
    disp(sprintf('tc:   %5.3f    to:   %5.3f', tc0,to0));
    disp(sprintf('G/Y:  %5.3f    Tr/Y: %5.3f    D/Y:  %5.3f    sx: %5.3f', ...
        GY, TrY, DY, sx0));
    disp(sprintf('T1:   %5i   Tx: %5i', T1, Tx));

    disp([ 'Tolerance: ', num2str(convDist) ])
    disp([ 'Endogenous: ', endPolName] );
    if BEQUTYPE ~= NOBEQUEST
        disp([ 'Bequest received at age ', int2str(tBequ) ])
    else
        disp('No bequest.')
    end



% *********************  MAIN LOOP  *************************

   dist_beta  = 0;
   dist_B     = 0;
   dist_Bx    = 0;
   dist_bequ  = 0;
   dist_IY    = 0;
   dist_rho   = 0;
   dist_psi   = 0;
   dist_hcInherit = 0;
   polDist = 0;

   dist = 99999;
   minDist = dist;
   done = 0;
   iter = 0;
   tStart    = clock;
   showTime  = tStart;
   checkTime = tStart;
   saveTime  = tStart;

   % ** Initial guess for endogenous policy
   eval(['Pol=', endPolName, ';']);




% ---------------------------------------------------------------------
while  done == 0
   tNow = clock;

   iter = iter + 1;
   if etime(tNow, showTime)/60 > showFreq  |  iter == 1
     showNow = 1;
     showTime = tNow;
     disp('----------------------------------------')
     disp([ 'OG1BGP: Iteration ', int2str(iter) ])
   else
      showNow = 0;
   end
   if etime(tNow, checkTime)/60 > checkFreq  |  iter == 2
     checkNow = 1;
     checkTime = tNow;
     dbg = dbgHigh;
     disp('Checking...');
   else
     checkNow = 0;
     dbg = dbgLow;
   end
   if etime(tNow, saveTime)/60 > saveFreq
      saveNow = 1;
      saveTime = tNow;
   else
      saveNow = 0;
   end

   %if rem(iter,20) == 0
   %   dbg = 222;
   %end


   grAggr = gr * popGrowth;

   % *** compute (w,r), output, per capita transfers ***
   tc = ones(1,T) .* tc0;
   tw = ones(1,T) .* tw0;

   % ** Factor prices and tax rates faced by the hh as a function of age
   K = k * L;
   [Y, MPK, MPL] = prodfct(K,L);
   Ynet = Y - ddk .* K;
   [r,w, tl] = bgprw( MPK, MPL, tk0,tw0,0,to0, kDeduct, ddk,T1,T );
   Ri = cumprod(1+r);

   % ** Transfers
   % per capita transfer = total transfer * fraction of population
   Tr = TrY .* Ynet .* populShare .* gr.^(0:T-1);

   % *********  INV. IN h1  ********
   h1Inv.Tstar = Tx;
   hAvgx = mseqend(hAvg(1)/gr, gr, Tx);
   h1Inv.rx = r(1);
   h1Inv.wx = MPL * (1-twx0);
   h1Inv.cx = x_cost(tl(1), sxx0, 0, 0);



   % ***************  HOUSEHOLD PROBLEM  ************************

   hhProbTol = max(min( 0.0001, dist * 0.1 ),  convDist*0.1);
   h1Inv.dV_da1 = Lambda;
   h1Inv.dV_dh1 = phi0;
   vh1Child = bequ * (bb * popGrowth)^(tb-1) * hcInherit * phi0 / gr^(sig*(tb-1));
   hAvgV = hAvg(1) .* gr.^(0:T-1);

   [cN,l,v,a,hN,x, c1N,muN,phiXN,BTN,valAbilN,hT1, h1Out] = ...
      hhprob(w, r, tl,tc,Tr, h1x,a1x,B1,tBequ,1+taxb0, c1,mu,phiX,...
      hProfile,h,hAvgV,xDeduct,sx0,xEarn, VPrime,BT,vh1Child,hhProbTol,...
      hhOpt, valAbil,hAvgx,h1Inv,T1, dbg);

   wt = 1 - l - v;
   c1Dist   = abs( c1N/c1 - 1 );
   cDist    = max(abs( cN./c - 1 ));
   hDist    = max(abs( hN./h - 1 ));
   phiDist  = distance3(phiXN, phiX, 0.01, dbg);
   muDist   = distance2(muN, mu, 0.01, dbg);
   dist_phi0  = abs( h1Out.dV_dh1 / phi0 - 1 );
   LambdaDist = ( h1Out.dV_da1 / Lambda - 1 );


   % ** Marginal value of bequest: bequ * VPrime
   if tBequ > 0
      % Parent and child overlap
      [tmp, muChild] = ufct( cN(tBequ)*gr^ageDiff, l(tBequ) );
   elseif tBequ == 0
      % Child born one period after parent dies
      [tmp, muChild] = ufct( cN(1)*gr^ageDiff, l(1) );
      muChild = muChild * bb * (1+r(1));
   else
      abort([ mfilename, ': Invalid tBequ' ]);
   end
   VPrimeN = bb^T * muChild / (1+tc0);
   dist_VPrime = VPrimeN / VPrime - 1;



   % ***********************  #CALIBRATION  *****************************
   if doCalib == 1

      if calBeta.calType > 0
         KY = K / (Y-X);   % X not included in observed output

         if calBeta.calType == 2  &  dist < 0.25      % Move to target value
            if betaStep > 0
               bb = min(calBeta.bbTarget, bb+betaStep);
            else
               bb = max(calBeta.bbTarget, bb+betaStep);
            end
         elseif calBeta.calType == 1                  % Match K/Y
            bbN = bb * (calBeta.KYTarget / KY);
            dist_beta = bbN / bb - 1;
            bbN = max(min( bbN, 1.05 ), 0.95);
            bb = update( bbN, bb, 0.05*gsw, 1.005, 0.995, dbg );
         end

         if showNow == 1
            disp(sprintf( 'bb:  %6.3f    K/Y: %6.3f', bb, KY ));
         end
      end


      if calRho.calType == 0
         rho = calRho.rhoTarget;
      else
         % Actual leisure share
         lShare = aggregx(iniPop, popGrowth, 1,  l) / totalPop;
         if calRho.calType == 1
            % Raise rho if leisure share < calRho.lTarget
            % New guess for rho
            rhoN = rho * (1 + calRho.lTarget - lShare) ^ 0.5;
            % Distance and update rho
            % Leisure share not calibrated to full precision (takes very long)
            dist_rho = 0.01 * ( calRho.lTarget - lShare );
            rhoN = min(max( rhoN, 0.4 ), 4);
            rho = update(rhoN, rho, 0.35*gsw, 1.01,0.99);
         elseif calRho.calType == 2
            if dist < 0.25
               if rhoStep > 0
                  rho = min( calRho.rhoTarget, rho + rhoStep );
               else
                  rho = max( calRho.rhoTarget, rho + rhoStep );
               end
            end
            rhoN = rho;
         end
         if showNow == 1
            disp(sprintf( 'rho: %6.3f -> %6.3f    lShare: %6.3f', rho, rhoN, lShare ));
         end
      end

      if calPsi == 1
         % Raise the share of time in hc if v is too low
         % Bad adjustment. Alternative?
         psiN = psi / ( mean(v) / vTarget ) ^ 0.5;
         % Distance and update psi
         dist_psi = (mean(v)/vTarget - 1);
         psi = update(psiN, psi, 0.5*gsw, 1.05,0.95);
         % Perhaps one should keep ksi = psi. Then adjust other coefficients as well.
      end

      if calBx == 1
         if BxTarget.hGrowth == UNDEFINED
            % Move Bx towards B
            BxN = B;
         else
            % Raise Bx, if growth of hx too small
            hxGrowth = h1Out.hx(end) / h1Out.hx(1);
            BxN = Bx * ( BxTarget.hGrowth / hxGrowth );
         end
         dist_Bx = BxN/Bx-1;
         Bx = update(BxN, Bx, gsw, 1.05,0.95);
      end

      % *** Calibrate Inv/Y ***
      if calInvY == 1
         Inv = K * (gr*popGrowth - 1 + ddk);
         ddkN = ddk * (IYTarget / (Inv/Y)) ^ 0.5;
         dist_IY = IYTarget / (Inv/Y) - 1;
         % Bounds on ddk. Must be annual
         ddkN = min( max(ddkN, ddkMin), ddkMax );
         ddk = update(ddkN, ddk, 0.8*gsw, 1.05,0.95);
      end

   end % if doCalib

   if calEta == 1  &  dist < 0.25
      if etaStep > 0
         eta = min(etaTarget, eta+etaStep);
      else
         eta = max(etaTarget, eta+etaStep);
      end
      ksi = 1 - eta - zeta;
   end

   if calDdh == 1   &  dist < 0.25
      if ddhStep > 0
         ddh = min(ddhTarget, ddh+ddhStep);
      else
         ddh = max(ddhTarget, ddh+ddhStep);
      end
      if showNow == 1  &  ddh ~= ddhTarget
         disp(sprintf( 'ddh: %6.4f', ddh ));
      end
   end

   if calSig == 1   &  dist < 0.25
      if sigStep > 0
         sig = min(sigTarget, sig+sigStep);
      else
         sig = max(sigTarget, sig+sigStep);
      end
      if showNow == 1  &  sig ~= sigTarget
         disp(sprintf( 'sig: %6.4f', sig ));
      end
   end




   % ***********  Growth rate  ***************
   % 1 + growth rate:
   grN = grrate([hN, hT1], h1x, hAvg, dbg);

   if doCalib == 1
      if calH.calB == 1
         % *** Raise hcInherit, if growth rate < grTarget
         hcInheritN = hcInherit * (grTarget / grN) ^ 0.6;

         % *** Raise B, if h is not sufficiently peaked
         % Compute growth between two ages
         if hTarget.type == 'e'
            % Replicate earnings profile (not wages)
            earnV = hN .* (1-l-v);
            earnGrowth = earnV(hTarget.age2) / earnV(hTarget.age1);
            BN = B * ( hTarget.hGrowth / max(0.6, earnGrowth) ) ^ 0.5;
         elseif hTarget.type == 'h';
            hGrowth = hN(hTarget.age2) / hN(hTarget.age1);
            BN = B * ( hTarget.hGrowth / hGrowth ) ^ 0.5;
         elseif hTarget.type == 'w';
            wageV = w .* hN .* (1-l-v) ./ (1-l);
            wageGrowth = wageV(hTarget.age2) / wageV(hTarget.age1);
            BN = B * ( hTarget.hGrowth / max(0.6, wageGrowth) ) ^ 0.5;
         else
            abort([ mfilename, ': Invalid hTarget.type' ]);
         end

         dist_B = BN/B-1;
         B = update(BN, B, 0.2*gsw, chngUp,chngDn);

      elseif calH.calB == 2
         % *** B matches growth rate
         BN = B * ( grTarget / grN ) ^ 0.5;
         dist_B = BN/B-1;
         B = update(BN, B, 0.2*gsw, 1.01,0.99);

         % *** hcInherit exogenous
         hcInheritN = calH.hcInherit;

      else
         abort([ mfilename, ': Invalid calH.calB' ]);
      end

      dist_hcInherit = hcInheritN / hcInherit - 1;
      if hcAltruism == 0
         % Higher GS weight. Otherwise hcInherit is adjusted very slowly
         hcInherit = update(hcInheritN, hcInherit, 0.25, chngUp,chngDn);
      else
         hcInherit = update(hcInheritN, hcInherit, 0.4*gsw, 1.01,0.99);
      end
      grN = grTarget;
   end
   grDist = grN / gr - 1;



   % *******************  AGGREGATES  ***********************

   [KN, LN] = aggreg(iniPop, popGrowth, gr, wt, a, h, DY*Y, h1Out.ax,h1Out.vhx);
   kN = KN ./ LN;

   Ldist  = max(abs(LN ./ L - 1));
   dist_k = distance(kN, k, dbg);
   LN = min(chngUpN*L, LN);
   LN = max(chngDnN*L, LN);

   if kN<kMin  |  kN>kMax
      disp(sprintf( '>>>>>  kN out of range: %f', kN ));
      if kN < kMin
         kN = kMin;
      else
         kN = kMax;
      end
      KN = LN * kN;
   end


   hAvgN = aggregx(iniPop, popGrowth, gr, hN) ./ totalPop;
   dist_hAvg = hAvgN / hAvg - 1;

   XN = aggregx(iniPop, popGrowth, gr, x);
   % more logical: compute from cN
   CN = aggregx(iniPop, popGrowth, gr, c);
   % ** Labor supply of the old only
   % more logical to use hN here
   tmp  = [ zeros(1,T1), wt(T1+1:T).*h(T1+1:T) ];
   LoldN = aggregx(iniPop, popGrowth, gr, tmp);
   % ** Education of the old only
   tmp  = [ zeros(1,T1), x(T1+1:T) ];
   XoldN = aggregx(iniPop, popGrowth, gr, tmp);
   % ** Goods used in h1 production
   % ** Adjust for the fact that this takes place before t=1
   if h1Invest == 1
     XxN = aggregx(iniPop, popGrowth, gr, h1Out.xx) .* grAggr^(Tx-1);
   else
     XxN = 0;
   end


   % **********************  #BEQUEST SECTION  *************************
   if BEQUTYPE ~= NOBEQUEST
      % Aggregate bequest
      % only gen. of age T-1 leaves bequest at date 1
      BTaggr = iniPop * BT / (gr * popGrowth)^(T-1);

      % Compute household net worth
      hhNetWorth = K + DY * Y;

      % GS weight for BT; may be higher in some cases
      gsw_BT = 0.5*gsw;

      % *** Calibrate bequ ***
      if doCalib == 1
         if bequTarget.calBequ == 2
            % Raise bequ, if (bequ flow)/(net worth) small
            % New aggregate bequest
            BTaggrN = iniPop * BTN / grAggr^(T-1);
            bequN   = bequ * (bequTarget.Flow / (BTaggrN/hhNetWorth))^0.5;
            bequN   = min(bequN, 1);

            % Set new guess to target level
            BTN = hhNetWorth * bequTarget.Flow / iniPop * grAggr^(T-1);
            gsw_BT = gsw;

            dist_bequ = bequN / bequ - 1;
            bequ = update(bequN, bequ, gsw, 1.01,0.99);

         % This alternative updating scheme is numerically unstable. Why?
         %elseif 0
         %   rTarget = bequ^(-1/ageDiff) * gr^sig / bb - 1;
         %   % Depends on functional form: f_fct   and   tk policies
         %   kTarget = ((rTarget + (1 - kDeduct * tk0) * ddk) / (1-tk0) / aa / A) ^ (1/(aa-1));
         %
         %   if showNow == 1
         %      disp(sprintf( 'rTarget: %6.3f    kTarget: %6.3f', rTarget, kTarget ));
         %   end
         %
         %   % Use kN to update BT
         %   BTN = BT * (kTarget / kN);
         %   gsw_BT = gsw;
         %   k  = kTarget;
         %   dist_bequ = distance2( BTN, BT, 0.01, dbg );

         elseif  bequTarget.calBequ == 1
            % Slowly move bequest towards target
            tmp = max(abs([dist_k, Ldist, dist_phi0, dist_VPrime, polDist, dist_rho]));
            if tmp < 0.25
               if bequStep > 0
                  bequ = min(bequTarget.bequ, bequ+bequStep);
               else
                  bequ = max(bequTarget.bequ, bequ+bequStep);
               end
            end
         end
      end

      bequDist = distance2(BTN, BT, 0.001, dbg);
      if BT > 0.01
         BT = update(BTN,BT, gsw_BT, chngUp,chngDn);
      else
         BT = (BTN + BT) / 2;
      end
      B1 = BT / (gr*popGrowth)^ageDiff;

   else     % No bequest motive
      bequDist = 0;
      BTaggr = 0;
      BTN = 0;
      BT  = 0;
      B1  = 0;
   end % *** Bequest section ***



   % *********  UPDATE ENDOGENOUS POLICIES  ************
   PolN = bgppolcy(KN,tk0,ddk,kDeduct, tc0,CN, LN,XN,tw0,LoldN,XoldN,to0,...
      xDeduct,xEarn,sx0, grAggr,DY,GY,TrY, taxAdj0, BTaggr,taxb0, Xx,sxx0, dbg);
   if Pol < 0.01
      polDist = abs(PolN-Pol);
   else
      polDist = abs(PolN/Pol - 1);
   end
   if Pol * PolN > 0
      Pol = update(PolN, Pol, gsw, 1.2, 0.8, dbg);
   else
      % Don't use update: policy changed signs
      Pol = PolN * gsw + Pol * (1-gsw);
   end
   eval([ endPolName, '=Pol;' ]);




   % *********  CHECK CONVERGENCE  ***********

   calDistV(1:5)  = abs([dist_rho, dist_psi, dist_Bx, dist_B, dist_hcInherit]);
   calDistV(6:10) = abs([dist_bequ, dist_IY, dist_beta,0,0]);
   calDist = max(abs( calDistV ));

   % Currently muDist not included
   dist0V(1:5)   = abs([polDist, dist_k, Ldist, grDist, bequDist]);
   dist0V(6:10)  = abs([dist_phi0, 0, phiDist, hDist, cDist]);
   dist0V(11:15) = abs([c1Dist, LambdaDist, dist_VPrime,0,0]);
   dist0 = max(dist0V);

   dist     = max([calDist, dist0]);
   minDist  = min(dist, minDist);
   if dist < convDist  &  iter >= minIter
      done = 1;
   elseif  iter > maxIter  |  etime(tNow, tStart)/60 > maxTime
      done = 2;
   end

   % *************** UPDATE gsw ***************
   if 1
      if dist < 0.0001
         gsw = 0.14;
      elseif dist < 0.001
         gsw = 0.12;
      elseif dist < 0.01
         gsw = 0.09;
      elseif dist < 0.05
         gsw = 0.08;
      elseif dist < 0.15
         gsw = 0.06;
      elseif dist < 0.3
         gsw = 0.05;
      else
         gsw = 0.04;
      end
   end


   % *************** #Show results of iteration ***************
   if showNow == 1
      disp(sprintf('Time: %5.1f min', etime(clock,startTime)/60));
      [maxDev, maxR, maxC] = maxidx( dist0V );
      disp(sprintf('         Distance %2i:    %f', maxC, dist0));
      if doCalib == 1
         [maxDev, maxR, maxC] = maxidx( abs(calDistV) );
         disp(sprintf('          CalDist %2i:    %f',  maxC, calDist ));
         disp(sprintf('B: %6.3f    hcInherit: %6.3f',   B, hcInherit ));
         %disp([ 'B  bequ  hcInherit  rho:  ',  ...
         %   sprintf('%6f    ', [dist_B, dist_bequ, dist_hcInherit, dist_rho]) ]);
      end

      disp(sprintf( 'k: %6f   bequ: %6f   pol: %6f   phi0: %6f   VPrime: %6f',  ...
         [dist_k, bequDist, polDist, dist_phi0, dist_VPrime] ));

      %disp(sprintf('%s:   %7.3f -> %7.3f   (%f)', endPolName, Pol, PolN,  polDist ));
      %disp(sprintf( 'Tr: %7.3f    hAvg: %7.3f', Tr(1), hAvg ));
      disp(sprintf('k: %7.3f -> %7.3f    hN(25): %6.2f     r: %6.3f %%   gr: %6.3f %%', ...
         k, kN, hN(25), r(1)*100, (gr-1)*100));
      %disp(sprintf('K: %7.3f -> %7.3f    L: %7.3f -> %7.3f', K, KN, L, LN));
      disp(sprintf('phi0:  %8.3f -> %8.3f    VPrime: %8.3f -> %8.3f    Lambda: %8.3f', ...
         phi0, h1Out.dV_dh1, VPrime, VPrimeN, Lambda));

      if BEQUTYPE ~= NOBEQUEST
         if doCalib == 1  &  bequTarget.calBequ == 2
            disp(sprintf('B / (net worth): %5.3f', BTaggrN/hhNetWorth ));
         end
         disp(sprintf('BT: %6.3f    BTN: %6.3f    bequ: %6.3f', BT, BTN, bequ));
         if 0
            [tmp, muParent] = ufct( c(T), l(T) );
            cParent = c(T);
            lParent = l(T);
            if tBequ == 0
               cChild = c(1) * gr^ageDiff;
               lChild = l(1);
               [tmp, muChild]  = ufct( cChild, lChild );
               muChild = bb*(1+r(1))*muChild;
            else
               cChild = c(tBequ) * gr^ageDiff;
               lChild = l(tBequ);
               [tmp, muChild]  = ufct( cChild, lChild );
            end
            disp(sprintf( 'MU(%6.3f,%6.3f) parent: %6.3f    MU(%6.3f,%6.3f) child: %6.3f', ...
               cParent, lParent, muParent,  cChild, lChild, muChild ));
         end
      end
      if h1Invest == 1
          disp(sprintf('ax: %6.3f .. %6.3f', h1Out.ax(1), h1Out.ax(end) ));
          disp(sprintf('hx: %6.3f .. %6.3f', h1Out.hx(1), h1Out.hx(end) ));
      end

      pause(1);     % Let windows recover from Matlab's misbehavior
   end


   % *************  SAVE  ********************************
   if saveNow == 1  |  done ~= 0
      if dist < 0.1  |  done ~= 0
         tmpFile.bgpNo = outFile.bgpNo;
         if doCalib == 1
            disp([ mfilename, ':  Saving parameters...' ]);
            parasave( outFile.calNo, outFile.calBgp );
         end
      else
         % Save intermediate results under temp file name
         tmpFile.bgpNo = 0;
      end
      priceS.r = r;
      priceS.w = w;
      priceS.cx = h1Inv.cx;

      agS.hAvg = hAvg(1);
      agS.X = X;
      agS.C = C;
      agS.Xx = Xx;
      agS.Lold = Lold;
      agS.Xold = Xold;
      agS.K    = K;
      agS.L    = L;
      agS.Y    = Y;
      agS.k    = k;
      agS.gr   = gr;
      agS.dist = dist;
      agS.Pol  = Pol;
      agS.tax  = tax0;

      hhS.valAbil = valAbil;
      hhS.vh1Child = vh1Child;
      hhS.VPrime = VPrime;
      hhS.phi0   = phi0;
      hhS.Lambda = Lambda;
      hhS.B1     = B1;
      hhS.BT     = BT;

      hhS.c = c;
      hhS.l = l;
      hhS.v = v;
      hhS.a = a;
      hhS.h = h;
      hhS.x = x;
      hhS.mu = mu;
      hhS.phiX = phiX;
      hhS.hT1 = hT1;


      bgpsave(gr, K,L, Pol, mu, phiX, c,l,v,a,h,x, tax0,taxAdj0,BT,...
         phi0,valAbil,h1Out.vhx,h1Out.ax,h1Out.hx,h1Out.xx,Xx,phi0,hT1,Lambda,dist,B1,...
         priceS, agS, hhS, tmpFile, dbg);
   end


   % ***************  #UPDATE GUESSES  ***************************
   grN = min(max(grN,grMin), grMax);
   gr = update(grN, gr, 0.1*gsw, 1.01,0.99);
   k  = update(kN,  k, 0.1*gsw, 1.01,0.99);

   % ** HH results
   % The weight here has to be quite high, as experiments show.
   % Hh converges to the same values anyway -- these are only initial guesses
   gswHh = 2*gsw;
   phiX = phiXN .* gswHh  +  phiX .* (1-gswHh);
   mu  = muN  .* gswHh  +  mu  .* (1-gswHh);
   h   = hN   .* gswHh  +  h   .* (1-gswHh);
   c1  = c1N  .* gswHh  +  c1  .* (1-gswHh);
   Lambda = h1Out.dV_da1 .* gswHh  +  Lambda .* (1-gswHh);

   % Update c slowly b/c used to compute VPrime of child
   % Not an input to hh problem
   c = update(cN, c, gsw, chngUp, chngDn);

   % Fast updating here induces oscillations in kN
   % - but update fast when no bequest/no hcAltruism
   if hcAltruism == 0
      phi0 = update(h1Out.dV_dh1, phi0, 2*gsw, chngUp, chngDn);
   else
      % Slow updating: it's value of the child (hh problem is solved conditionally
      % on that)
      phi0 = update(h1Out.dV_dh1, phi0, 0.1*gsw, chngUp,chngDn);
      %phi0 = update(h1Out.dV_dh1, phi0, gsw, chngUp,chngDn);
   end
   VPrime = update(VPrimeN, VPrime, 0.9*gsw,chngUp,chngDn);

   valAbil = update(valAbilN, valAbil, 0.2, chngUp, chngDn);

   hAvg = update(hAvgN, hAvg, 0.5*gsw, chngUp,chngDn);
   L    = update(LN, L, gsw, chngUp,chngDn);
   X    = update(XN, X, gsw, chngUp,chngDn);
   C    = update(CN, C, gsw, chngUp,chngDn);
   Lold = update(LoldN, Lold, gsw, chngUp,chngDn);
   Xold = update(XoldN, Xold, gsw, chngUp,chngDn);
   Xx   = update(XxN, Xx, gsw, chngUp,chngDn);



   % ***************  CONSISTENCY CHECK  ****************
   if checkNow == 1
      v_check( hN, 'f', [1,T], 1e-3, UNDEFINED );
   end

end %------------------------------------- whend ----------------------------------%


% ******************  PROCESS SOLUTION  ********************

   BTaggr = iniPop * BT / grAggr^(T-1);
   TaxY = taxrev(MPK,K,tk0,ddk,kDeduct, tc0,C, MPL,L,X,tw0, Lold,Xold,...
      to0,xDeduct,xEarn,sx0, BTaggr,taxb0,Xx,sxx0) ./ Ynet;
   DSY = DY * (r(1) - gr+1 - popGrowth+1);
   TrYN = TaxY - (GY + DSY)*Y/Ynet;



% *******************  Solution display  *****************************************

if 0
    disp('-- Terminal values --')
    disp([ 'Net r:     ', num2str(((1+r(1))^(1/yPerPd)-1)*100) ])
    disp([ 'Annual gr: ', num2str( (gr^(1/yPerPd)-1)*100 ) ])
    disp([ 'Avg. hc:   ', num2str(hAvg) ]);
    if bequ > 0
        disp([ 'B1 = ', num2str(B1) ]);
        disp([ 'BT = ', num2str(BT) ]);
    end
end
if 0
    disp(' ')
    disp('Income shares (%):')
    disp([ 'Tax revenue:      ', num2str(TaxY*100) ])
    disp([ 'Governm.spending: ', num2str(GY*100)   ])
    disp([ 'Transfers/Ynet:   ', num2str(TrY*100)  ])
    disp([ 'Debt/Y:           ', num2str(DY*100)])
    disp([ 'Debt service/Y    ', num2str(DSY*100)  ])
    disp(' ')
end


% ************************  CONSISTENCY CHECK  **************************************

if dbg > 0
   bgpchk( outFile.calNo, outFile.calBgp, outFile.bgpNo );

    if bequ > 0  &  BEQUTYPE ~= NOBEQUEST
        disp(' ')
        disp('--- CONSISTENCY CHECK ----------------------')

        % ** Do bequests grow at the right rate?
        B1child = BT/popGrowth^ageDiff;
        bequGrowth = (B1child/B1)^(1/ageDiff);
        if distance(bequGrowth, gr) > convDist
            disp(' ')
            disp('--- Bequest growth ---')
            bequGrowth
            gr
        end
    end
end



% *** end function ***

