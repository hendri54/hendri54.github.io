function mAge = model_age( age );
% Compute a model age from a physical age
% Rounded
% ---------------------------------------

global iniAge yPerPd

mAge = 1 + round( (age - iniAge) / yPerPd );

% *** end function ***
